#=============================================================================
# Extract adult (≥20 yr) per-pair, per-group n for Table 3
#=============================================================================
source("00_config.R")
library(data.table)

demo_clean     <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
var_file_index <- readRDS(file.path(CACHE_DIR, "variable_file_index.rds"))
results_cs     <- readRDS(file.path(CACHE_DIR, "exwas_results_common_scale.rds"))

demo_clean$SEQN <- as.double(demo_clean$SEQN)
demo_adult <- demo_clean[demo_clean$age >= 20, ]
demo_slim <- demo_adult[, c("SEQN","survey_cycle","race_ethnicity",
                             "female","age","age_sq","education",
                             "income_poverty_ratio","wt_mec","psu","strata")]

load_var <- function(var_name, index) {
  vf <- index[index$var_name == var_name, ]
  if (nrow(vf) == 0) return(NULL)
  chunks <- list()
  for (i in seq_len(nrow(vf))) {
    df <- tryCatch(haven::read_xpt(vf$file_path[i]), error = function(e) NULL)
    if (is.null(df)) next
    col <- vf$actual_colname[i]
    if (!col %in% names(df) || !"SEQN" %in% names(df)) next
    chunks[[length(chunks)+1]] <- data.frame(SEQN=as.double(df[["SEQN"]]),
      val=as.numeric(df[[col]]), survey_cycle=vf$survey_cycle[i])
  }
  if (length(chunks)==0) return(NULL)
  out <- do.call(rbind, chunks)
  out <- out[!duplicated(out[,c("SEQN","survey_cycle")]),]
  out <- out[!is.na(out$val),]
  names(out)[2] <- var_name
  out
}

# Table 3 strict P-ranked top 10
pairs <- data.frame(
  exposure  = c("LBXTHG","LBXCOT","LBXCOT","LBXCOT","LBXSIR",
                "URXUCS","LBXSIR","LBXCOT","LBXBPB","LBXBCD"),
  phenotype = c("BMXARML","BMXBMI","BMXWT","BMXWAIST","LBXHCT",
                "URXUCR","LBXHGB","BMXARML","BMXHT","BMXBMI"),
  stringsAsFactors = FALSE
)

actual_races <- c("NHW","NHB","MA","OH","OTH")
all_results <- list()
k <- 0

for (i in 1:nrow(pairs)) {
  ename <- pairs$exposure[i]
  pname <- pairs$phenotype[i]
  cat(sprintf("%d/10: %s -> %s\n", i, ename, pname))
  
  edata <- load_var(ename, var_file_index)
  pdata <- load_var(pname, var_file_index)
  if (is.null(edata) || is.null(pdata)) { cat("  SKIP\n"); next }
  
  m <- merge(demo_slim, edata, by=c("SEQN","survey_cycle"))
  m <- merge(m, pdata, by=c("SEQN","survey_cycle"))
  m <- m[!is.na(m[[ename]]) & !is.na(m[[pname]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$age) & !is.na(m$female), ]
  
  for (rg in c("ALL", actual_races)) {
    d <- if (rg == "ALL") m else m[m$race_ethnicity == rg, ]
    k <- k + 1
    all_results[[k]] <- data.frame(
      rank = i, exposure = ename, phenotype = pname,
      group = rg, n_adult = nrow(d),
      stringsAsFactors = FALSE
    )
    cat(sprintf("  %s: n = %d\n", rg, nrow(d)))
  }
}

result_df <- do.call(rbind, all_results)
fwrite(result_df, file.path(OUTPUT_DIR, "table3_adult_n.csv"))
cat("\n=== SAVED: table3_adult_n.csv ===\n")

# Print formatted for easy copy
cat("\n=== Table 3 Adult n Summary ===\n")
cat(sprintf("%-4s %-10s %-10s %8s %8s %8s %8s %8s %8s\n",
            "Rank","Exposure","Phenotype","ALL","NHW","NHB","MA","OH","OTH"))
cat(paste(rep("-",80),collapse=""),"\n")

for (i in 1:10) {
  r <- result_df[result_df$rank == i, ]
  cat(sprintf("%2d   %-10s %-10s %8s %8s %8s %8s %8s %8s\n",
    i, r$exposure[1], r$phenotype[1],
    format(r$n_adult[r$group=="ALL"], big.mark=","),
    format(r$n_adult[r$group=="NHW"], big.mark=","),
    format(r$n_adult[r$group=="NHB"], big.mark=","),
    format(r$n_adult[r$group=="MA"],  big.mark=","),
    format(r$n_adult[r$group=="OH"],  big.mark=","),
    format(r$n_adult[r$group=="OTH"], big.mark=",")))
}
