#=============================================================================
# phase2_demographics_table.R
# 生成基线人口学特征表 (Supplementary Table S0 / Table S8)
#=============================================================================

source("00_config.R")
library(survey)
library(data.table)

cat("\n[加载数据]\n")
demo_clean <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
demo_clean$SEQN <- as.double(demo_clean$SEQN)

actual_races <- c("NHW", "NHB", "MA", "OH", "OTH")

cat(sprintf("  总样本: %d\n", nrow(demo_clean)))

# ============================================================
# 按种族分组计算人口学特征
# ============================================================

results <- list()

for (rg in c("ALL", actual_races)) {
  d <- if (rg == "ALL") demo_clean else demo_clean[demo_clean$race_ethnicity == rg, ]
  
  n_total <- nrow(d)
  
  # 年龄
  age_mean <- round(mean(d$age, na.rm = TRUE), 1)
  age_sd   <- round(sd(d$age, na.rm = TRUE), 1)
  age_med  <- round(median(d$age, na.rm = TRUE), 0)
  age_iqr  <- round(quantile(d$age, c(0.25, 0.75), na.rm = TRUE), 0)
  
  # 性别
  n_female   <- sum(d$female == 1, na.rm = TRUE)
  pct_female <- round(100 * n_female / n_total, 1)
  
  # 年龄分组
  n_child  <- sum(d$age < 20, na.rm = TRUE)
  n_adult  <- sum(d$age >= 20, na.rm = TRUE)
  pct_child <- round(100 * n_child / n_total, 1)
  
  # 教育（仅成人≥20）
  d_adult <- d[d$age >= 20, ]
  edu_below_hs <- sum(d_adult$education == 1, na.rm = TRUE)
  edu_hs       <- sum(d_adult$education == 2, na.rm = TRUE)
  edu_above_hs <- sum(d_adult$education == 3, na.rm = TRUE)
  edu_total    <- sum(!is.na(d_adult$education))
  pct_below_hs <- if (edu_total > 0) round(100 * edu_below_hs / edu_total, 1) else NA
  pct_hs       <- if (edu_total > 0) round(100 * edu_hs / edu_total, 1) else NA
  pct_above_hs <- if (edu_total > 0) round(100 * edu_above_hs / edu_total, 1) else NA
  
  # 收入贫困比
  pir_med    <- round(median(d$income_poverty_ratio, na.rm = TRUE), 2)
  pir_iqr    <- round(quantile(d$income_poverty_ratio, c(0.25, 0.75), na.rm = TRUE), 2)
  pir_mean   <- round(mean(d$income_poverty_ratio, na.rm = TRUE), 2)
  pir_miss   <- sum(is.na(d$income_poverty_ratio))
  pir_miss_pct <- round(100 * pir_miss / n_total, 1)
  
  # 调查波次数
  n_cycles <- length(unique(d$survey_cycle))
  
  results[[rg]] <- data.frame(
    group = rg,
    n = n_total,
    age_mean_sd = paste0(age_mean, " (", age_sd, ")"),
    age_median_iqr = paste0(age_med, " (", age_iqr[1], "–", age_iqr[2], ")"),
    n_under20 = n_child,
    pct_under20 = pct_child,
    female_n = n_female,
    female_pct = pct_female,
    edu_below_hs_pct = pct_below_hs,
    edu_hs_pct = pct_hs,
    edu_above_hs_pct = pct_above_hs,
    pir_median = pir_med,
    pir_iqr = paste0(pir_iqr[1], "–", pir_iqr[2]),
    pir_mean = pir_mean,
    pir_missing_pct = pir_miss_pct,
    survey_cycles = n_cycles,
    stringsAsFactors = FALSE
  )
}

demo_table <- do.call(rbind, results)

# ============================================================
# 打印
# ============================================================

cat("\n═══════════════════════════════════════════════════════════════════════════════════\n")
cat("  Supplementary Table: Baseline demographic characteristics by race/ethnicity\n")
cat("═══════════════════════════════════════════════════════════════════════════════════\n\n")

cat(sprintf("%-6s %7s %15s %17s %8s %8s %9s %9s %9s %8s %10s\n",
            "Group", "n", "Age mean(SD)", "Age med(IQR)", "<20yr%", "Female%",
            "<HS%", "HS%", ">HS%", "PIR med", "PIR IQR"))
cat(paste(rep("─", 110), collapse = ""), "\n")

for (i in seq_len(nrow(demo_table))) {
  r <- demo_table[i, ]
  cat(sprintf("%-6s %7s %15s %17s %7.1f%% %7.1f%% %8.1f%% %8.1f%% %8.1f%% %8.2f %10s\n",
              r$group,
              format(r$n, big.mark = ","),
              r$age_mean_sd,
              r$age_median_iqr,
              r$pct_under20,
              r$female_pct,
              r$edu_below_hs_pct,
              r$edu_hs_pct,
              r$edu_above_hs_pct,
              r$pir_median,
              r$pir_iqr))
}

cat("\n  PIR = income-to-poverty ratio. Education: adults ≥20 years only.\n")
cat(sprintf("  PIR missing: ALL=%.1f%%\n", demo_table$pir_missing_pct[demo_table$group == "ALL"]))

# ============================================================
# 保存
# ============================================================
fwrite(demo_table, file.path(OUTPUT_DIR, "table_demographics_baseline.csv"))
cat("\n  → table_demographics_baseline.csv 已保存\n")

# 验证正文中引用的数字
cat("\n═══ 正文数字验证 ═══\n")
cat(sprintf("  PIR: MA median = %.2f, NHW median = %.2f\n",
            demo_table$pir_median[demo_table$group == "MA"],
            demo_table$pir_median[demo_table$group == "NHW"]))
cat(sprintf("  Education below HS: NHW = %.1f%%, MA = %.1f%%\n",
            demo_table$edu_below_hs_pct[demo_table$group == "NHW"],
            demo_table$edu_below_hs_pct[demo_table$group == "MA"]))
cat("  正文声称: PIR 1.3(MA)–3.2(NHW), edu<HS 12%(NHW)–50%(MA)\n")
cat("  ↑ 对比以上真实值，确认是否一致\n")
