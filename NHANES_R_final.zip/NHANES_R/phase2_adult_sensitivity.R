#=============================================================================
# phase2_adult_sensitivity.R
# 成人限定（≥20岁）敏感性分析：Top交互对
#=============================================================================
# 目的: 验证主分析中的Top交互效应在限定≥20岁后是否保持
# 使用: setwd("E:/NHANES_R"); source("phase2_adult_sensitivity.R")
# 前提: phase2_common_scale.R 已运行
#=============================================================================

source("00_config.R")
log_info("===== 成人限定敏感性分析 =====")

library(survey)
library(data.table)
library(ggplot2)

# ============================================================
# PART 0: 加载数据
# ============================================================
cat("\n[PART 0] 加载数据...\n")

demo_clean     <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
full_catalog   <- readRDS(file.path(CACHE_DIR, "variable_catalog.rds"))
var_file_index <- readRDS(file.path(CACHE_DIR, "variable_file_index.rds"))
interaction_cs <- readRDS(file.path(CACHE_DIR, "interaction_results_common_scale.rds"))

demo_clean$SEQN <- as.double(demo_clean$SEQN)

# ★ 成人限定: ≥20岁 ★
demo_adult <- demo_clean[demo_clean$age >= 20, ]

demo_slim <- demo_adult[, c("SEQN", "survey_cycle", "race_ethnicity",
                             "female", "age", "age_sq",
                             "education", "income_poverty_ratio",
                             "wt_mec", "psu", "strata")]

cat(sprintf("  全样本: %d 人\n", nrow(demo_clean)))
cat(sprintf("  成人(≥20岁): %d 人 (%.1f%%)\n",
            nrow(demo_adult), 100 * nrow(demo_adult) / nrow(demo_clean)))
cat(sprintf("  education 非缺失率: %.1f%%\n",
            100 * mean(!is.na(demo_slim$education))))

# 复用 load_var
load_var <- function(var_name, index) {
  vf <- index[index$var_name == var_name, ]
  if (nrow(vf) == 0) return(NULL)
  chunks <- vector("list", nrow(vf))
  for (i in seq_len(nrow(vf))) {
    df <- tryCatch(haven::read_xpt(vf$file_path[i]), error = function(e) NULL)
    if (is.null(df)) next
    col <- vf$actual_colname[i]
    if (!col %in% names(df) || !"SEQN" %in% names(df)) next
    chunks[[i]] <- data.frame(SEQN = as.double(df[["SEQN"]]),
                               val = as.numeric(df[[col]]),
                               survey_cycle = vf$survey_cycle[i],
                               stringsAsFactors = FALSE)
  }
  chunks <- chunks[!sapply(chunks, is.null)]
  if (length(chunks) == 0) return(NULL)
  out <- do.call(rbind, chunks)
  out <- out[!duplicated(out[, c("SEQN", "survey_cycle")]), ]
  out <- out[!is.na(out$val), ]
  names(out)[2] <- var_name
  return(out)
}

# ============================================================
# PART 1: 确定要检验的对（按P值排序的Top 15）
# ============================================================
cat("\n[PART 1] 确定Top交互对...\n")

top_pairs <- interaction_cs[order(interaction_cs$p_interaction), ]
top_pairs <- head(top_pairs[, c("exposure", "phenotype", "p_interaction",
                                 "p_fdr_int", "n_obs")], 15)

cat("  将对以下15对进行成人限定敏感性:\n")
for (i in seq_len(nrow(top_pairs))) {
  cat(sprintf("    %2d. %s → %s (原始P=%.2e, n=%d)\n",
              i, top_pairs$exposure[i], top_pairs$phenotype[i],
              top_pairs$p_interaction[i], top_pairs$n_obs[i]))
}

# ============================================================
# PART 2: 成人限定交互模型
# ============================================================
cat("\n[PART 2] 运行成人限定交互模型...\n")

run_int_adult <- function(exp_data, phe_data, demo, exp_name, phe_name) {
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$race_ethnicity) & !is.na(m$age) & !is.na(m$female), ]
  if (nrow(m) < 500) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x > 0], na.rm = TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm = TRUE) == 0) return(NULL)
  m$P_raw <- m[[phe_name]]
  
  nc <- length(unique(m$survey_cycle))
  m$wt_adj <- m$wt_mec / nc
  m$race_f <- droplevels(factor(m$race_ethnicity, levels = c("NHW","NHB","MA","OH","OTH")))
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  # ★ 成人模型: education 总是纳入（成人≥20岁应该都有） ★
  fml_str <- "P_raw ~ E_log10 * race_f + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nrow(m) * 0.3)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nrow(m) * 0.3)
    fml_str <- paste(fml_str, "+ education")
  
  des <- tryCatch(
    svydesign(id = ~psu, strata = ~strata, weights = ~wt_adj, data = m, nest = TRUE),
    error = function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str), design = des), error = function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  int_terms <- grep("^E_log10:race_f", rownames(co), value = TRUE)
  if (length(int_terms) == 0) return(NULL)
  
  p_int <- tryCatch({regTermTest(fit, "E_log10:race_f")$p},
                    error = function(e) min(co[int_terms, "Pr(>|t|)"], na.rm = TRUE))
  
  data.frame(exposure = exp_name, phenotype = phe_name,
             p_interaction_adult = p_int, n_obs_adult = nrow(m),
             stringsAsFactors = FALSE)
}

# 分层回归（成人限定）
run_reg_adult <- function(exp_data, phe_data, demo, exp_name, phe_name, race_grp = NULL) {
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  if (!is.null(race_grp)) m <- m[m$race_ethnicity == race_grp, ]
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$age) & !is.na(m$female), ]
  
  nn <- nrow(m); nc <- length(unique(m$survey_cycle))
  if (nn < 200 || nc < MIN_SURVEY_WAVES) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x > 0], na.rm = TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm = TRUE) == 0) return(NULL)
  m$P_raw <- m[[phe_name]]
  
  m$wt_adj <- m$wt_mec / nc
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_raw ~ E_log10 + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nn * 0.3)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nn * 0.3)
    fml_str <- paste(fml_str, "+ education")
  if (is.null(race_grp)) {
    m$race_f <- droplevels(factor(m$race_ethnicity))
    if (nlevels(m$race_f) > 1) fml_str <- paste(fml_str, "+ race_f")
  }
  
  des <- tryCatch(svydesign(id=~psu, strata=~strata, weights=~wt_adj, data=m, nest=TRUE),
                  error=function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str), design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  if (!"E_log10" %in% rownames(co)) return(NULL)
  
  data.frame(exposure=exp_name, phenotype=phe_name,
             race_group=ifelse(is.null(race_grp),"ALL",race_grp),
             n_obs_adult=nn, beta_adult=co["E_log10","Estimate"],
             se_adult=co["E_log10","Std. Error"],
             p_adult=co["E_log10","Pr(>|t|)"],
             stringsAsFactors=FALSE)
}

# 执行
actual_races <- c("NHW","NHB","MA","OH","OTH")
int_results <- list()
strat_results <- list()
ii <- 0; si <- 0

for (k in seq_len(nrow(top_pairs))) {
  ename <- top_pairs$exposure[k]
  pname <- top_pairs$phenotype[k]
  cat(sprintf("  %d/%d: %s → %s\n", k, nrow(top_pairs), ename, pname))
  
  edata <- load_var(ename, var_file_index)
  pdata <- load_var(pname, var_file_index)
  if (is.null(edata) || is.null(pdata)) next
  
  # 交互
  ir <- tryCatch(run_int_adult(edata, pdata, demo_slim, ename, pname),
                 error = function(e) NULL)
  if (!is.null(ir)) { ii <- ii + 1; int_results[[ii]] <- ir }
  
  # 分层
  for (rg in c("ALL", actual_races)) {
    rarg <- if (rg == "ALL") NULL else rg
    sr <- tryCatch(run_reg_adult(edata, pdata, demo_slim, ename, pname, rarg),
                   error = function(e) NULL)
    if (!is.null(sr)) { si <- si + 1; strat_results[[si]] <- sr }
  }
}

int_adult_df <- if (ii > 0) do.call(rbind, int_results[1:ii]) else data.frame()
strat_adult_df <- if (si > 0) do.call(rbind, strat_results[1:si]) else data.frame()

# ============================================================
# PART 3: 对比汇总
# ============================================================
cat("\n[PART 3] 成人限定 vs 全年龄 对比...\n")

if (nrow(int_adult_df) > 0) {
  comp <- merge(top_pairs[, c("exposure", "phenotype", "p_interaction", "n_obs")],
                int_adult_df,
                by = c("exposure", "phenotype"), all.x = TRUE)
  
  comp$p_ratio <- comp$p_interaction_adult / comp$p_interaction
  comp$n_retained_pct <- comp$n_obs_adult / comp$n_obs * 100
  comp$still_sig <- comp$p_interaction_adult < 0.05 / nrow(comp)  # Bonferroni for 15 tests
  
  cat("\n  ══════════════════════════════════════════════════════════════════════════\n")
  cat(sprintf("  %-4s %-10s %-10s %8s %8s %10s %10s %6s %5s\n",
              "Rank", "Exposure", "Phenotype", "n_all", "n_adult", "P_all", "P_adult", "%kept", "Sig?"))
  cat("  ──────────────────────────────────────────────────────────────────────────\n")
  
  for (i in seq_len(nrow(comp))) {
    r <- comp[i, ]
    sig_mark <- if (!is.na(r$still_sig) && r$still_sig) "  ✓" else "  ✗"
    cat(sprintf("  %2d   %-10s %-10s %8d %8d %10.2e %10.2e %5.1f%% %s\n",
                i, r$exposure, r$phenotype,
                r$n_obs, ifelse(is.na(r$n_obs_adult), 0, r$n_obs_adult),
                r$p_interaction,
                ifelse(is.na(r$p_interaction_adult), NA, r$p_interaction_adult),
                ifelse(is.na(r$n_retained_pct), 0, r$n_retained_pct),
                sig_mark))
  }
  
  cat("\n  注: Sig? = 是否在 Bonferroni (α=0.05/15=0.0033) 下仍显著\n")
}

# ============================================================
# PART 4: 分层β对比
# ============================================================
cat("\n[PART 4] 分层β对比（成人 vs 全年龄）...\n")

# 加载全年龄结果
results_cs <- readRDS(file.path(CACHE_DIR, "exwas_results_common_scale.rds"))

if (nrow(strat_adult_df) > 0) {
  # 合并
  beta_comp <- merge(
    strat_adult_df[, c("exposure","phenotype","race_group","n_obs_adult","beta_adult","se_adult")],
    results_cs[, c("exposure","phenotype","race_group","n_obs","beta","se")],
    by = c("exposure","phenotype","race_group"),
    suffixes = c("_adult", "_all")
  )
  
  beta_comp$same_dir <- sign(beta_comp$beta_adult) == sign(beta_comp$beta)
  beta_comp$beta_change_pct <- abs(beta_comp$beta_adult - beta_comp$beta) /
                                abs(beta_comp$beta) * 100
  
  cat(sprintf("  方向一致率: %.1f%% (%d/%d)\n",
              100 * mean(beta_comp$same_dir, na.rm = TRUE),
              sum(beta_comp$same_dir, na.rm = TRUE), nrow(beta_comp)))
  cat(sprintf("  β变化中位数: %.1f%%\n",
              median(beta_comp$beta_change_pct, na.rm = TRUE)))
  
  # 保存
  fwrite(as.data.table(beta_comp),
         file.path(OUTPUT_DIR, "sensitivity_adult_only_beta_comparison.csv"))
}

# ============================================================
# PART 5: 保存
# ============================================================
cat("\n[PART 5] 保存...\n")

if (nrow(int_adult_df) > 0)
  fwrite(as.data.table(int_adult_df),
         file.path(OUTPUT_DIR, "sensitivity_adult_only_interaction.csv"))
if (nrow(strat_adult_df) > 0)
  fwrite(as.data.table(strat_adult_df),
         file.path(OUTPUT_DIR, "sensitivity_adult_only_stratified.csv"))

# ============================================================
cat("\n╔═══════════════════════════════════════════════════════╗\n")
cat("║  成人限定敏感性分析完成!                              ║\n")
cat("║  输出:                                                ║\n")
cat("║    sensitivity_adult_only_interaction.csv              ║\n")
cat("║    sensitivity_adult_only_stratified.csv               ║\n")
cat("║    sensitivity_adult_only_beta_comparison.csv          ║\n")
cat("╚═══════════════════════════════════════════════════════╝\n")
log_info("成人限定敏感性分析完成")
