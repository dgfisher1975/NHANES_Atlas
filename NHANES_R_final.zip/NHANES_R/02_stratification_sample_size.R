#=============================================================================
# 脚本 02: 种族/民族分层与样本量评估
#=============================================================================
# 功能:
#   1. 按种族/民族对人口统计学特征进行描述性统计
#   2. 评估每个种族-暴露-表型组合的样本量
#   3. 确定可纳入分析的有效组合
#   4. 统计检验效能分析
#   5. 生成Phase 1汇总报告
#=============================================================================

source("00_config.R")
log_info("===== 脚本02: 种族分层与样本量评估 =====")

library(ggplot2)
library(patchwork)
library(scales)
library(pwr)
library(gt)

# 加载缓存数据
demo_clean    <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
full_catalog  <- readRDS(file.path(CACHE_DIR, "variable_catalog.rds"))

# 尝试加载变量可用性数据
avail_file <- file.path(CACHE_DIR, "variable_availability.rds")
has_availability <- file.exists(avail_file)
if (has_availability) {
  availability_df <- readRDS(avail_file)
}

# ============================================================
# PART 1: 人口统计学特征描述统计（按种族分层）
# ============================================================
cat("\n[PART 1] 人口统计学特征描述统计（按种族分层）...\n")

# ---- 1.1 总体与分层样本量 ----
sample_overview <- demo_clean %>%
  group_by(race_ethnicity, race_label) %>%
  summarise(
    n_total   = n(),
    n_male    = sum(sex == "Male", na.rm = TRUE),
    n_female  = sum(sex == "Female", na.rm = TRUE),
    pct_male  = round(100 * n_male / n_total, 1),
    age_mean  = round(mean(age, na.rm = TRUE), 1),
    age_sd    = round(sd(age, na.rm = TRUE), 1),
    age_median = median(age, na.rm = TRUE),
    age_q25   = quantile(age, 0.25, na.rm = TRUE),
    age_q75   = quantile(age, 0.75, na.rm = TRUE),
    ipr_mean  = round(mean(income_poverty_ratio, na.rm = TRUE), 2),
    ipr_sd    = round(sd(income_poverty_ratio, na.rm = TRUE), 2),
    ipr_median = round(median(income_poverty_ratio, na.rm = TRUE), 2),
    n_edu_below_hs = sum(education == 1, na.rm = TRUE),
    n_edu_hs       = sum(education == 2, na.rm = TRUE),
    n_edu_above_hs = sum(education == 3, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    pct_edu_below_hs = round(100 * n_edu_below_hs / n_total, 1),
    pct_edu_hs       = round(100 * n_edu_hs / n_total, 1),
    pct_edu_above_hs = round(100 * n_edu_above_hs / n_total, 1)
  )

cat("\n  ===== 各种族/民族群体概况 =====\n\n")
for (i in seq_len(nrow(sample_overview))) {
  row <- sample_overview[i, ]
  cat(sprintf("  [%s] %s\n", row$race_ethnicity, row$race_label))
  cat(sprintf("    总样本量: %s | 男性: %s (%.1f%%)\n", 
              format(row$n_total, big.mark = ","), 
              format(row$n_male, big.mark = ","), row$pct_male))
  cat(sprintf("    年龄: %.1f ± %.1f (中位: %.0f, IQR: %.0f-%.0f)\n",
              row$age_mean, row$age_sd, row$age_median, row$age_q25, row$age_q75))
  cat(sprintf("    收入贫困比: %.2f ± %.2f (中位: %.2f)\n",
              row$ipr_mean, row$ipr_sd, row$ipr_median))
  cat(sprintf("    教育: <HS %.1f%% | HS %.1f%% | >HS %.1f%%\n\n",
              row$pct_edu_below_hs, row$pct_edu_hs, row$pct_edu_above_hs))
}

# ---- 1.2 各波次各种族样本量 ----
cycle_race_n <- demo_clean %>%
  count(survey_cycle, race_ethnicity) %>%
  pivot_wider(names_from = race_ethnicity, values_from = n, values_fill = 0) %>%
  arrange(survey_cycle) %>%
  mutate(Total = NHW + NHB + MA + OH + OTH)

cat("\n  ===== 各波次×种族样本量矩阵 =====\n")
print(as.data.frame(cycle_race_n))

# 保存描述统计
saveRDS(sample_overview, file.path(CACHE_DIR, "sample_overview.rds"))
write.csv(cycle_race_n, file.path(TABLE_DIR, "cycle_race_sample_size.csv"), row.names = FALSE)

# ============================================================
# PART 2: 各种族-暴露-表型组合的样本量评估
# ============================================================
cat("\n[PART 2] 评估种族-暴露-表型组合的样本量...\n")

if (has_availability) {
  
  # 确保种族列存在
  race_cols <- c("NHW", "NHB", "MA", "OH", "OTH")
  missing_race_cols <- setdiff(race_cols, names(availability_df))
  for (col in missing_race_cols) {
    availability_df[[col]] <- 0L
  }
  
  # ---- 2.1 计算各变量在各种族中的累积样本量 ----
  var_race_summary <- availability_df %>%
    group_by(var_name) %>%
    summarise(
      n_cycles    = n(),
      total_n     = sum(total_n, na.rm = TRUE),
      NHW_total   = sum(NHW, na.rm = TRUE),
      NHB_total   = sum(NHB, na.rm = TRUE),
      MA_total    = sum(MA, na.rm = TRUE),
      OH_total    = sum(OH, na.rm = TRUE),
      OTH_total   = sum(OTH, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    left_join(full_catalog %>% select(var_name, description, category, var_type),
              by = "var_name")
  
  cat("  变量级别样本量汇总:\n")
  cat("    暴露变量:", sum(var_race_summary$var_type == "exposure", na.rm = TRUE), "个\n")
  cat("    表型变量:", sum(var_race_summary$var_type == "phenotype", na.rm = TRUE), "个\n")
  
  # ---- 2.2 判断哪些变量在各种族中满足最低样本量 ----
  var_race_eligible <- var_race_summary %>%
    mutate(
      NHW_eligible = NHW_total >= MIN_SAMPLE_SIZE & n_cycles >= MIN_SURVEY_WAVES,
      NHB_eligible = NHB_total >= MIN_SAMPLE_SIZE & n_cycles >= MIN_SURVEY_WAVES,
      MA_eligible  = MA_total  >= MIN_SAMPLE_SIZE & n_cycles >= MIN_SURVEY_WAVES,
      OH_eligible  = OH_total  >= MIN_SAMPLE_SIZE & n_cycles >= MIN_SURVEY_WAVES,
      OTH_eligible = OTH_total >= MIN_SAMPLE_SIZE & n_cycles >= MIN_SURVEY_WAVES,
      n_races_eligible = NHW_eligible + NHB_eligible + MA_eligible + 
                         OH_eligible + OTH_eligible
    )
  
  # 汇总
  eligibility_summary <- var_race_eligible %>%
    group_by(var_type) %>%
    summarise(
      total_vars     = n(),
      NHW_eligible_n = sum(NHW_eligible),
      NHB_eligible_n = sum(NHB_eligible),
      MA_eligible_n  = sum(MA_eligible),
      OH_eligible_n  = sum(OH_eligible),
      OTH_eligible_n = sum(OTH_eligible),
      all5_eligible  = sum(n_races_eligible == 5),
      ge3_eligible   = sum(n_races_eligible >= 3),
      .groups = "drop"
    )
  
  cat("\n  ===== 变量在各种族中的可分析性 =====\n")
  cat("  (最低样本量:", MIN_SAMPLE_SIZE, ", 最少波次:", MIN_SURVEY_WAVES, ")\n\n")
  print(as.data.frame(eligibility_summary))
  
  # 保存
  saveRDS(var_race_eligible, file.path(CACHE_DIR, "var_race_eligible.rds"))
  write.csv(var_race_eligible, file.path(TABLE_DIR, "var_race_eligibility.csv"), row.names = FALSE)
  
} else {
  cat("  [跳过] 变量可用性数据未生成，将使用估算方法\n")
}

# ============================================================
# PART 3: 暴露×表型组合的可行性矩阵
# ============================================================
cat("\n[PART 3] 构建暴露×表型可行性矩阵...\n")

if (has_availability) {
  
  exposures  <- var_race_eligible %>% filter(var_type == "exposure")
  phenotypes <- var_race_eligible %>% filter(var_type == "phenotype")
  
  # 对每个种族，计算可测试的暴露×表型组合数
  feasibility_by_race <- tibble(
    race_group = c("NHW", "NHB", "MA", "OH", "OTH"),
    race_label = c("Non-Hispanic White", "Non-Hispanic Black", 
                   "Mexican American", "Other Hispanic", "Other/Multi-Racial")
  )
  
  for (rg in feasibility_by_race$race_group) {
    eligible_col <- paste0(rg, "_eligible")
    n_exp <- sum(exposures[[eligible_col]], na.rm = TRUE)
    n_phe <- sum(phenotypes[[eligible_col]], na.rm = TRUE)
    n_pairs <- n_exp * n_phe
    
    feasibility_by_race <- feasibility_by_race %>%
      mutate(
        !!paste0(rg, "_n_exposures")  := ifelse(race_group == rg, n_exp, NA),
        !!paste0(rg, "_n_phenotypes") := ifelse(race_group == rg, n_phe, NA),
        !!paste0(rg, "_n_pairs")      := ifelse(race_group == rg, n_pairs, NA)
      )
    
    # 直接赋值方式
    feasibility_by_race$n_exposures[feasibility_by_race$race_group == rg] <- n_exp
    feasibility_by_race$n_phenotypes[feasibility_by_race$race_group == rg] <- n_phe
    feasibility_by_race$n_pairs[feasibility_by_race$race_group == rg] <- n_pairs
  }
  
  # 简化输出
  feasibility_simple <- tibble(race_group = character(), race_label = character(),
                               n_exposures = integer(), n_phenotypes = integer(),
                               n_pairs = integer())
  for (rg in c("NHW", "NHB", "MA", "OH", "OTH")) {
    eligible_col <- paste0(rg, "_eligible")
    n_exp <- sum(exposures[[eligible_col]], na.rm = TRUE)
    n_phe <- sum(phenotypes[[eligible_col]], na.rm = TRUE)
    feasibility_simple <- bind_rows(feasibility_simple, tibble(
      race_group = rg,
      race_label = RACE_GROUPS[[rg]]$label,
      n_exposures = n_exp,
      n_phenotypes = n_phe,
      n_pairs = n_exp * n_phe
    ))
  }
  
  cat("\n  ===== 各种族可测试的暴露×表型组合 =====\n")
  print(as.data.frame(feasibility_simple))
  
  # 总检验数（用于Bonferroni校正）
  total_tests <- sum(feasibility_simple$n_pairs)
  bonferroni_threshold <- BONFERRONI_ALPHA / total_tests
  cat(sprintf("\n  总检验数: %s\n", format(total_tests, big.mark = ",")))
  cat(sprintf("  Bonferroni校正阈值: %.2e\n", bonferroni_threshold))
  
  write.csv(feasibility_simple, file.path(TABLE_DIR, "feasibility_by_race.csv"), row.names = FALSE)
  
} else {
  # 基于DEMO数据的估算
  cat("  基于DEMO数据进行估算...\n")
  
  race_totals <- demo_clean %>%
    count(race_ethnicity, name = "total_n") %>%
    arrange(desc(total_n))
  
  cat("\n  各种族总样本量（10波次合计）:\n")
  print(as.data.frame(race_totals))
  
  # 粗略估算：假设约60-80%的变量在大样本种族中可用
  cat("\n  [估算] 假设核心变量覆盖率:\n")
  cat("    NHW: ~90% 暴露变量可分析\n")
  cat("    NHB: ~85% 暴露变量可分析\n")
  cat("    MA:  ~80% 暴露变量可分析\n")
  cat("    OH:  ~60% 暴露变量可分析（样本量较小）\n")
  cat("    OTH: ~50% 暴露变量可分析（样本量最小）\n")
}

# ============================================================
# PART 4: 统计检验效能分析
# ============================================================
cat("\n[PART 4] 统计检验效能分析...\n")

#' 计算给定样本量下可检测的最小R²
#' @param n 样本量
#' @param alpha 显著性水平
#' @param power 目标检验效能
#' @param n_covariates 协变量数量
#' @return 最小可检测R²
min_detectable_r2 <- function(n, alpha = 1e-5, power = 0.80, n_covariates = 7) {
  # 使用F检验的效应量 f² = R²/(1-R²)
  # 分子自由度 = 1 (单暴露), 分母自由度 = n - n_covariates - 2
  df_denom <- n - n_covariates - 2
  if (df_denom <= 0) return(NA)
  
  tryCatch({
    # 通过pwr包计算
    result <- pwr::pwr.f2.test(
      u = 1,           # 检验的自由度（单变量暴露）
      v = df_denom,    # 残差自由度
      f2 = NULL,       # 要求解的效应量
      sig.level = alpha,
      power = power
    )
    # f² = R²_change / (1 - R²_full) ≈ R²_change（当R²较小时）
    return(result$f2)
  }, error = function(e) {
    return(NA)
  })
}

# 各种族的典型样本量与可检测R²
if (has_availability) {
  race_sample_sizes <- var_race_eligible %>%
    filter(var_type == "exposure") %>%
    summarise(
      NHW_median = median(NHW_total, na.rm = TRUE),
      NHB_median = median(NHB_total, na.rm = TRUE),
      MA_median  = median(MA_total, na.rm = TRUE),
      OH_median  = median(OH_total, na.rm = TRUE),
      OTH_median = median(OTH_total, na.rm = TRUE)
    )
} else {
  # 使用DEMO数据估算
  race_sample_sizes <- tibble(
    NHW_median = as.numeric(demo_clean %>% filter(race_ethnicity == "NHW") %>% nrow() * 0.3),
    NHB_median = as.numeric(demo_clean %>% filter(race_ethnicity == "NHB") %>% nrow() * 0.3),
    MA_median  = as.numeric(demo_clean %>% filter(race_ethnicity == "MA") %>% nrow() * 0.3),
    OH_median  = as.numeric(demo_clean %>% filter(race_ethnicity == "OH") %>% nrow() * 0.3),
    OTH_median = as.numeric(demo_clean %>% filter(race_ethnicity == "OTH") %>% nrow() * 0.3)
  )
}

# 计算各种族的检验效能
power_table <- tibble(
  race_group = c("NHW", "NHB", "MA", "OH", "OTH"),
  race_label = c("Non-Hispanic White", "Non-Hispanic Black", 
                 "Mexican American", "Other Hispanic", "Other/Multi-Racial")
)

power_table$median_n <- c(
  race_sample_sizes$NHW_median,
  race_sample_sizes$NHB_median,
  race_sample_sizes$MA_median,
  race_sample_sizes$OH_median,
  race_sample_sizes$OTH_median
)

# 在不同alpha水平下的最小可检测R²
for (a_level in c(0.05, 1e-3, 1e-5, 1e-7)) {
  col_name <- paste0("min_R2_alpha_", formatC(a_level, format = "e", digits = 0))
  power_table[[col_name]] <- sapply(power_table$median_n, function(n) {
    r2 <- min_detectable_r2(n, alpha = a_level)
    if (is.na(r2)) return(NA)
    round(r2 * 100, 3)  # 转为百分比
  })
}

cat("\n  ===== 各种族检验效能分析 =====\n")
cat("  (目标效能: 80%, 协变量: 7个)\n\n")
cat("  最小可检测R² (%):\n")
print(as.data.frame(power_table))

# 保存
write.csv(power_table, file.path(TABLE_DIR, "power_analysis.csv"), row.names = FALSE)

# ---- 效能曲线图 ----
cat("\n  生成检验效能曲线图...\n")

sample_range <- seq(300, 40000, by = 100)
power_curves <- expand.grid(
  n = sample_range,
  alpha = c(0.05, 1e-3, 1e-5, 1e-7)
) %>%
  as_tibble() %>%
  mutate(
    min_r2 = mapply(min_detectable_r2, n, alpha),
    alpha_label = paste0("α = ", formatC(alpha, format = "e", digits = 0))
  )

p_power <- ggplot(power_curves, aes(x = n, y = min_r2 * 100, color = alpha_label)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(labels = comma) +
  scale_y_log10(breaks = c(0.01, 0.05, 0.1, 0.5, 1, 5)) +
  labs(
    title = "各样本量下的最小可检测R²",
    subtitle = "检验效能=80%, 协变量=7个",
    x = "样本量 (n)",
    y = "最小可检测 R² (%)",
    color = "显著性水平"
  ) +
  # 添加各种族的中位样本量标记
  geom_vline(xintercept = power_table$median_n, linetype = "dashed", alpha = 0.5) +
  annotate("text", x = power_table$median_n, y = 5, 
           label = power_table$race_group, angle = 90, vjust = -0.5, size = 3) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(file.path(FIGURE_DIR, "power_analysis_curves.pdf"), p_power, 
       width = 10, height = 7, dpi = 300)
ggsave(file.path(FIGURE_DIR, "power_analysis_curves.png"), p_power,
       width = 10, height = 7, dpi = 300)

# ============================================================
# PART 5: 人口统计学特征可视化
# ============================================================
cat("\n[PART 5] 生成人口统计学可视化...\n")

# 定义种族颜色方案
race_colors <- c(
  "NHW" = "#4E79A7", "NHB" = "#E15759", "MA" = "#76B7B2",
  "OH"  = "#F28E2B", "OTH" = "#B07AA1"
)

# ---- 5.1 各波次各种族样本量柱状图 ----
p_sample_by_cycle <- demo_clean %>%
  count(survey_cycle, race_ethnicity) %>%
  ggplot(aes(x = survey_cycle, y = n, fill = race_ethnicity)) +
  geom_col(position = "dodge", width = 0.7) +
  scale_fill_manual(values = race_colors, name = "种族/民族") +
  scale_y_continuous(labels = comma) +
  labs(title = "各NHANES波次的种族/民族样本量分布",
       x = "调查波次", y = "样本量") +
  theme_minimal(base_size = 11) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "bottom")

# ---- 5.2 年龄分布 ----
p_age_dist <- demo_clean %>%
  ggplot(aes(x = age, fill = race_ethnicity, color = race_ethnicity)) +
  geom_density(alpha = 0.3, linewidth = 0.8) +
  scale_fill_manual(values = race_colors, name = "种族/民族") +
  scale_color_manual(values = race_colors, guide = "none") +
  labs(title = "各种族/民族的年龄分布",
       x = "年龄 (岁)", y = "密度") +
  theme_minimal(base_size = 11) +
  theme(legend.position = "bottom")

# ---- 5.3 收入贫困比分布 ----
p_income_dist <- demo_clean %>%
  filter(!is.na(income_poverty_ratio)) %>%
  ggplot(aes(x = race_ethnicity, y = income_poverty_ratio, fill = race_ethnicity)) +
  geom_boxplot(alpha = 0.7, outlier.size = 0.5) +
  scale_fill_manual(values = race_colors, guide = "none") +
  labs(title = "各种族/民族的收入-贫困比分布",
       x = "种族/民族", y = "收入-贫困比") +
  theme_minimal(base_size = 11)

# ---- 5.4 教育水平分布 ----
p_edu_dist <- demo_clean %>%
  filter(!is.na(education_label)) %>%
  count(race_ethnicity, education_label) %>%
  group_by(race_ethnicity) %>%
  mutate(pct = n / sum(n) * 100) %>%
  ggplot(aes(x = race_ethnicity, y = pct, fill = education_label)) +
  geom_col(position = "fill") +
  scale_y_continuous(labels = percent) +
  scale_fill_brewer(palette = "Set2", name = "教育水平") +
  labs(title = "各种族/民族的教育水平构成",
       x = "种族/民族", y = "比例") +
  theme_minimal(base_size = 11) +
  theme(legend.position = "bottom")

# 拼接图形
p_combined <- (p_sample_by_cycle + p_age_dist) / (p_income_dist + p_edu_dist) +
  plot_annotation(
    title = "NHANES 1999-2018 种族/民族分层人口统计学概况",
    theme = theme(plot.title = element_text(size = 14, face = "bold"))
  )

ggsave(file.path(FIGURE_DIR, "demographics_overview.pdf"), p_combined,
       width = 16, height = 12, dpi = 300)
ggsave(file.path(FIGURE_DIR, "demographics_overview.png"), p_combined,
       width = 16, height = 12, dpi = 300)

cat("  图形已保存至:", FIGURE_DIR, "\n")

# ============================================================
# PART 6: Phase 1 汇总报告
# ============================================================
cat("\n[PART 6] 生成Phase 1汇总报告...\n")

report_lines <- c(
  "================================================================",
  "  Phase 1 汇总报告: 数据准备、群体分层、样本量评估",
  sprintf("  生成时间: %s", Sys.time()),
  "================================================================",
  "",
  "1. 数据概况",
  sprintf("   NHANES波次数: %d", n_distinct(demo_clean$survey_cycle)),
  sprintf("   总参与者数: %s", format(nrow(demo_clean), big.mark = ",")),
  sprintf("   暴露变量目录: %d 个", sum(full_catalog$var_type == "exposure")),
  sprintf("   表型变量目录: %d 个", sum(full_catalog$var_type == "phenotype")),
  "",
  "2. 种族/民族分层样本量",
  sprintf("   NHW (非西裔白人):    %s", format(sum(demo_clean$race_ethnicity == "NHW"), big.mark = ",")),
  sprintf("   NHB (非西裔黑人):    %s", format(sum(demo_clean$race_ethnicity == "NHB"), big.mark = ",")),
  sprintf("   MA  (墨西哥裔):      %s", format(sum(demo_clean$race_ethnicity == "MA"), big.mark = ",")),
  sprintf("   OH  (其他西裔):      %s", format(sum(demo_clean$race_ethnicity == "OH"), big.mark = ",")),
  sprintf("   OTH (其他/多种族):   %s", format(sum(demo_clean$race_ethnicity == "OTH"), big.mark = ",")),
  "",
  "3. 检验效能 (α=1e-5, Power=80%)",
  sprintf("   NHW 最小可检测R²: %.3f%%", power_table$`min_R2_alpha_1e-05`[1]),
  sprintf("   NHB 最小可检测R²: %.3f%%", power_table$`min_R2_alpha_1e-05`[2]),
  sprintf("   MA  最小可检测R²: %.3f%%", power_table$`min_R2_alpha_1e-05`[3]),
  sprintf("   OH  最小可检测R²: %.3f%%", power_table$`min_R2_alpha_1e-05`[4]),
  sprintf("   OTH 最小可检测R²: %.3f%%", power_table$`min_R2_alpha_1e-05`[5]),
  ""
)

if (has_availability) {
  report_lines <- c(report_lines,
    "4. 可分析变量数",
    sprintf("   成功检测到的变量: %d", n_distinct(availability_df$var_name)),
    ""
  )
}

report_lines <- c(report_lines,
  "5. 输出文件",
  sprintf("   缓存目录: %s", CACHE_DIR),
  sprintf("   表格目录: %s", TABLE_DIR),
  sprintf("   图形目录: %s", FIGURE_DIR),
  "",
  "6. 后续步骤 (Phase 2)",
  "   - 运行分层ExWAS: 对每个种族独立执行暴露-表型关联分析",
  "   - 暴露×种族交互效应检验",
  "   - 多重检验校正与复现率评估",
  "================================================================"
)

# 打印到控制台
cat("\n")
cat(paste(report_lines, collapse = "\n"))
cat("\n")

# 保存报告
writeLines(report_lines, file.path(OUTPUT_DIR, "phase1_report.txt"))
log_info("Phase 1 报告已保存至: {file.path(OUTPUT_DIR, 'phase1_report.txt')}")

cat("\n[Phase 1 全部完成]\n")
cat("下一步: 运行 03_data_merge.R 合并暴露-表型数据用于Phase 2分析\n")
