#=============================================================================
# run_phase2.R — Full Phase 2 Pipeline
#=============================================================================
# Execution order:
#   1. 01b_build_variable_index.R  → scan XPT column headers, build index
#   2. phase2_v3.R                 → within-group z-score ExWAS + Figures 1-4
#   3. phase2_common_scale.R       → common dose scale reanalysis
#   4. Sensitivity analyses
#   5. Supplementary data
#   6. Final figures (5 & 6)
#
# Prerequisite: Phase 1 completed (run_phase1.R)
# Usage: setwd("E:/NHANES_R"); source("run_phase2.R")
#=============================================================================

cat("
+----------------------------------------------------------+
|  Phase 2: Race/Ethnicity-Stratified ExWAS Full Pipeline  |
+----------------------------------------------------------+
\n")

start_time <- Sys.time()
source("00_config.R")

# Check Phase 1 cache
required <- c("demo_clean.rds", "variable_catalog.rds")
missing <- required[!file.exists(file.path(CACHE_DIR, required))]
if (length(missing) > 0) {
  stop("Phase 1 cache missing: ", paste(missing, collapse = ", "),
       "\nRun source('run_phase1.R') first")
}
cat("[OK] Phase 1 data verified\n\n")

# ---- Step 1: Variable file index ----
cat("=== Step 1/6: Variable file index ===\n")
index_path <- file.path(CACHE_DIR, "variable_file_index.rds")
if (file.exists(index_path)) {
  cat("  [SKIP] Index exists, loading...\n")
  idx <- readRDS(index_path)
  cat(sprintf("  %d mappings for %d variables\n\n",
              nrow(idx), length(unique(idx$var_name))))
} else {
  source("01b_build_variable_index.R")
  cat("[OK] Index built\n\n")
}

# ---- Step 2: Core ExWAS (within-group z-score) ----
cat("=== Step 2/6: Core stratified ExWAS (phase2_v3.R) ===\n")
cat("  Produces: Table 1, Table 2, Figures 1-4\n")
cat("  Expected time: 60-180 minutes\n\n")
source("phase2_v3.R")

# ---- Step 3: Common dose scale reanalysis ----
cat("\n=== Step 3/6: Common dose scale (phase2_common_scale.R) ===\n")
cat("  Produces: Table 3 data, Figure 5/6 data\n")
cat("  Expected time: 60-180 minutes\n\n")
source("phase2_common_scale.R")

# ---- Step 4: Sensitivity analyses ----
cat("\n=== Step 4/6: Sensitivity analyses ===\n")

cat("  4a: Adult-only restriction...\n")
source("phase2_adult_sensitivity.R")

cat("  4b: Extra confounder adjustment (BMI + cotinine)...\n")
source("phase2_extra_confounder_top10.R")

cat("  4c: Below-LOD proportions & sensitivity summary...\n")
source("phase2_supplement_final_v2.R")

# ---- Step 5: Supplementary data ----
cat("\n=== Step 5/6: Supplementary tables ===\n")

cat("  5a: Demographics table...\n")
source("phase2_demographics_table.R")

cat("  5b: Robustness package (log-outcome etc.)...\n")
source("phase2_robustness_package.R")

# ---- Step 6: Final figures ----
cat("\n=== Step 6/6: Final figures ===\n")

cat("  6a: Figure 5 (interaction volcano)...\n")
source("fig5_interaction_volcano_final.R")

cat("  6b: Figure 6 (forest plot)...\n")
source("fig6_forest_final_v2.R")

# ---- Done ----
elapsed <- difftime(Sys.time(), start_time, units = "mins")
cat(sprintf("\n
+----------------------------------------------------------+
|  Phase 2 COMPLETE  |  Total time: %.1f minutes
+----------------------------------------------------------+
|  Outputs:
|    %s/output/    (CSV results)
|    %s/figures/   (PNG figures)
|    %s/cache/     (RDS intermediates)
+----------------------------------------------------------+
\n", as.numeric(elapsed), PROJECT_DIR, PROJECT_DIR, PROJECT_DIR))
