# Biomarker-Measured Exposure–Phenome Atlas
# Stratified by Self-Identified Race/Ethnicity
# ============================================================

## Overview

Analytic code for a race/ethnicity-stratified exposome–phenome-wide
association study (P-ExWAS) using NHANES 1999–2018 data. The pipeline
links 71 exposure biomarkers with 48 quantitative clinical phenotypes
across five racial/ethnic groups and a pooled sample, tests for
exposure × race/ethnicity interaction effects on a common dose scale,
and conducts comprehensive sensitivity analyses.

Based on: Patel CJ, Ioannidis JPA, Manrai AK. An atlas of exposome–
phenome associations in health and disease risk. Nat Med 2026.
DOI: 10.1038/s41591-026-04266-0

## Data Requirements

- NHANES 1999–2018 public-use XPT files (10 cycles)
- Directory: `C:/NHANES/NHANES/` (modify in `00_config.R`)
- Structure: `{cycle}/Demographics/demo.xpt`, `{cycle}/Laboratory/...`, etc.

## Quick Start

```r
setwd("E:/NHANES_R")          # your script directory

# Phase 1: Data preparation (~30 min)
source("run_phase1.R")

# Phase 2: Full analysis pipeline (~5-8 hours)
source("run_phase2.R")
```

## File Inventory (16 scripts)

### Phase 1: Data Preparation
| Script | Purpose | Output |
|--------|---------|--------|
| `00_config.R` | Global paths, parameters, packages | — |
| `01_data_loading.R` | Load NHANES XPT files, catalogue variables | `variable_catalog.rds` |
| `01b_build_variable_index.R` | Scan column headers across 1,609 XPT files | `variable_file_index.rds` |
| `02_stratification_sample_size.R` | Race/ethnicity stratification, power analysis | `demo_clean.rds` |
| `03_data_merge.R` | Merge demographics with exposure/phenotype data | merged datasets |
| `run_phase1.R` | One-click Phase 1 runner | — |

### Phase 2: Core Analysis
| Script | Purpose | Output |
|--------|---------|--------|
| `phase2_v3.R` | Within-group z-score ExWAS (20,448 regressions) | Table 1, Table 2, Figures 1–4 |
| `phase2_common_scale.R` | Common dose scale reanalysis (log₁₀, unstandardised) | Table 3 data, interaction results |
| `run_phase2.R` | One-click full Phase 2 pipeline | — |

### Sensitivity Analyses
| Script | Purpose | Output |
|--------|---------|--------|
| `phase2_adult_sensitivity.R` | Adult-only (≥20 yr) restriction | Table S1 |
| `phase2_extra_confounder_top10.R` | +BMI +cotinine adjustment for top 10 | Table S6 |
| `phase2_supplement_final_v2.R` | Below-LOD proportions, sensitivity summary | Tables S2, S4 |
| `phase2_robustness_package.R` | Log-outcome, additional robustness checks | Table S7 data |

### Figures & Supplementary
| Script | Purpose | Output |
|--------|---------|--------|
| `fig5_interaction_volcano_final.R` | Interaction volcano plot (common scale) | Figure 5 |
| `fig6_forest_final_v2.R` | Forest plot, P-ranked top 10 interactions | Figure 6 |
| `phase2_demographics_table.R` | Baseline demographic characteristics | Table S5 |

## Script → Manuscript Output Mapping

### Main Text
| Item | Source Script | Notes |
|------|-------------|-------|
| Table 1 | `phase2_v3.R` | Within-group z-score summary |
| Table 2 | `phase2_v3.R` | Pairwise β correlations |
| Table 3 | `phase2_common_scale.R` | Top 10 interactions (P-ranked, common scale) |
| Figure 1 | `phase2_v3.R` | P-value distribution |
| Figure 2 | `phase2_v3.R` | Significant association counts |
| Figure 3 | `phase2_v3.R` | Cross-race β scatter |
| Figure 4 | `phase2_v3.R` | R² distribution |
| Figure 5 | `fig5_interaction_volcano_final.R` | 244/3,127 FDR < 0.05 |
| Figure 6 | `fig6_forest_final_v2.R` | Matches Table 3 exactly |

### Supplementary
| Item | Source Script |
|------|-------------|
| Table S1 | `phase2_adult_sensitivity.R` |
| Table S2 | `phase2_supplement_final_v2.R` |
| Table S3 | Static (in manuscript) |
| Table S4 | `phase2_supplement_final_v2.R` |
| Table S5 | `phase2_demographics_table.R` |
| Table S6 | `phase2_extra_confounder_top10.R` |
| Table S7 | `phase2_robustness_package.R` |

## Two Exposure Scales

| Scale | Used for | β interpretation |
|-------|----------|-----------------|
| Within-group z-score | Table 1, 2; Figures 1–4; pairwise correlations | Phenotype change per 1-SD within-group |
| Common dose (log₁₀) | Table 3; Figures 5–6; all sensitivity analyses | Phenotype change per 10-fold exposure increase |

## Key Configuration (00_config.R)

| Parameter | Default | Description |
|-----------|---------|-------------|
| `NHANES_DATA_DIR` | `C:/NHANES/NHANES` | Path to NHANES XPT files |
| `PROJECT_DIR` | `E:/NHANES_DATA/ExWAS_Race_Stratified` | Output root |
| `MIN_SAMPLE_SIZE` | 300 | Min n per race–exposure–phenotype cell |
| `MIN_SURVEY_WAVES` | 2 | Min survey cycles required |
| `FDR_LEVEL` | 0.05 | Benjamini–Yekutieli threshold |

## Software

R ≥ 4.5.1 with: survey, dplyr, tidyr, purrr, stringr, haven,
data.table, broom, ggplot2, patchwork, scales, logger, pwr

## Files Removed from Development Archive

The following scripts were superseded during development and are
excluded from this release:

- `04_stratified_exwas.R` → superseded by `phase2_v3.R`
- `04_stratified_exwas_fixed.R` → superseded by `phase2_v3.R`
- `05_visualization.R` → embedded in `phase2_v3.R` PART 7
- `fig6_forest_final.R` → superseded by `fig6_forest_final_v2.R`
- `phase2_supplement_final.R` → superseded by `phase2_supplement_final_v2.R`
