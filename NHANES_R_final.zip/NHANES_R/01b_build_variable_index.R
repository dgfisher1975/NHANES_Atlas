#=============================================================================
# 修复脚本 01b: 构建变量→文件精确索引
#=============================================================================
# 问题: NHANES早期波次(1999-2004)文件命名与后期不一致
#   - 1999-2000: lab06.xpt (包含血铅、镉等)
#   - 2005-2006: pbcd_d.xpt (同样变量)
#   Phase 2按table_pattern匹配会丢失早期波次数据
#
# 解决: 扫描每个XPT文件的列名，建立 变量名→文件路径 的精确映射
#
# 使用方法:
#   在运行Phase 2之前执行此脚本
#   source("01b_build_variable_index.R")
#=============================================================================

source("00_config.R")
log_info("===== 修复脚本01b: 构建变量→文件索引 =====")

library(haven)
library(data.table)

# 加载文件目录和变量目录
file_catalog  <- read.csv(file.path(CACHE_DIR, "file_catalog.csv"), stringsAsFactors = FALSE)
full_catalog  <- readRDS(file.path(CACHE_DIR, "variable_catalog.rds"))

# 我们需要查找的所有目标变量
target_vars <- full_catalog$var_name
cat(sprintf("目标变量: %d 个\n", length(target_vars)))

# 只扫描XPT文件
xpt_files <- file_catalog %>% 
  filter(tolower(file_ext) == "xpt") %>%
  # 排除过大的膳食个体条目文件（通常>50MB，不包含我们的目标变量）
  filter(file_size < 80000000)  

cat(sprintf("待扫描XPT文件: %d 个\n", nrow(xpt_files)))

# ============================================================
# 扫描每个XPT文件的列名
# ============================================================
cat("\n[开始扫描文件列名...]\n")

# 存储结果: variable_name -> [(file_path, survey_cycle), ...]
var_file_index <- list()
scan_errors <- character()

pb_total <- nrow(xpt_files)

for (i in seq_len(pb_total)) {
  
  fpath  <- xpt_files$full_path[i]
  fcycle <- xpt_files$survey_cycle[i]
  fname  <- xpt_files$filename[i]
  
  # 进度条
  if (i %% 50 == 0 || i == 1) {
    cat(sprintf("\r  扫描: %d / %d (%.0f%%) | %s        ", 
                i, pb_total, 100*i/pb_total, fname))
  }
  
  # 只读取列名（不读数据，非常快）
  col_names <- tryCatch({
    # 方法1: 用haven快速读取前1行获取列名
    df_head <- haven::read_xpt(fpath, n_max = 1)
    names(df_head)
  }, error = function(e) {
    tryCatch({
      # 方法2: 备选，用foreign
      df_head <- foreign::read.xport(fpath, n_max = 1)
      names(df_head)
    }, error = function(e2) {
      scan_errors <<- c(scan_errors, fpath)
      NULL
    })
  })
  
  if (is.null(col_names)) next
  
  # 检查哪些目标变量在这个文件中
  found_vars <- intersect(toupper(col_names), toupper(target_vars))
  
  # 用原始大小写（匹配target_vars中的形式）
  for (fv in found_vars) {
    # 找到target_vars中匹配的原始名称
    orig_name <- target_vars[toupper(target_vars) == fv][1]
    # 找到文件中的实际列名
    actual_col <- col_names[toupper(col_names) == fv][1]
    
    entry <- data.frame(
      var_name      = orig_name,
      actual_colname = actual_col,
      file_path     = fpath,
      filename      = fname,
      survey_cycle  = fcycle,
      stringsAsFactors = FALSE
    )
    
    var_file_index[[length(var_file_index) + 1]] <- entry
  }
}

cat(sprintf("\n\n扫描完成! 扫描失败: %d 个文件\n", length(scan_errors)))

# 合并为数据框
var_index_df <- rbindlist(var_file_index) |> as.data.frame()

cat(sprintf("变量→文件映射: %d 条记录\n", nrow(var_index_df)))
cat(sprintf("覆盖的唯一变量: %d / %d\n", 
            n_distinct(var_index_df$var_name), length(target_vars)))

# ============================================================
# 对比修复前后的覆盖情况
# ============================================================
cat("\n===== 修复前后对比 =====\n")

# 修复前: 按table_pattern匹配
old_method_count <- 0
for (v in target_vars) {
  tp <- full_catalog$table_pattern[full_catalog$var_name == v][1]
  if (is.na(tp)) next
  matched <- file_catalog %>% 
    filter(str_detect(toupper(table_name), toupper(tp)))
  if (nrow(matched) > 0) old_method_count <- old_method_count + 1
}

# 修复后: 按列名精确匹配
new_method_count <- n_distinct(var_index_df$var_name)

cat(sprintf("  旧方法(table_pattern匹配): %d / %d 变量可找到文件\n", 
            old_method_count, length(target_vars)))
cat(sprintf("  新方法(列名扫描):          %d / %d 变量可找到文件\n", 
            new_method_count, length(target_vars)))
cat(sprintf("  新增覆盖: +%d 变量\n", new_method_count - old_method_count))

# ============================================================
# 查看各变量的波次覆盖
# ============================================================
cat("\n===== 各变量的波次覆盖情况 =====\n")

var_coverage <- var_index_df %>%
  group_by(var_name) %>%
  summarise(
    n_cycles = n_distinct(survey_cycle),
    cycles = paste(sort(unique(survey_cycle)), collapse = ", "),
    n_files = n(),
    .groups = "drop"
  ) %>%
  left_join(full_catalog %>% select(var_name, description, category, var_type),
            by = "var_name") %>%
  arrange(var_type, category, var_name)

# 打印暴露变量覆盖
cat("\n[暴露变量]\n")
exp_cov <- var_coverage %>% filter(var_type == "exposure")
for (i in seq_len(min(nrow(exp_cov), 30))) {
  row <- exp_cov[i, ]
  cat(sprintf("  %-12s %-35s %2d波次\n", row$var_name, row$description, row$n_cycles))
}
if (nrow(exp_cov) > 30) cat(sprintf("  ... 共 %d 个暴露变量\n", nrow(exp_cov)))

# 打印表型变量覆盖
cat("\n[表型变量]\n")
phe_cov <- var_coverage %>% filter(var_type == "phenotype")
for (i in seq_len(min(nrow(phe_cov), 20))) {
  row <- phe_cov[i, ]
  cat(sprintf("  %-12s %-35s %2d波次\n", row$var_name, row$description, row$n_cycles))
}

# ============================================================
# 重新计算种族分层样本量 (使用精确索引)
# ============================================================
cat("\n===== 基于精确索引重新评估种族分层样本量 =====\n")

demo_clean <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))

# 抽样检查几个关键变量
key_vars <- c("LBXBPB", "LBXBCD", "LBXCOT", "LBXTC", "BMXBMI", "LBXGLU", "LBXGH", "LBXCRP")

for (kv in key_vars) {
  files_for_var <- var_index_df %>% filter(var_name == kv)
  
  if (nrow(files_for_var) == 0) {
    cat(sprintf("  %s: 未找到\n", kv))
    next
  }
  
  # 读取并合并
  all_data <- list()
  for (j in seq_len(nrow(files_for_var))) {
    fp <- files_for_var$file_path[j]
    fc <- files_for_var$survey_cycle[j]
    ac <- files_for_var$actual_colname[j]
    
    df <- tryCatch(haven::read_xpt(fp), error = function(e) NULL)
    if (is.null(df) || !ac %in% names(df) || !"SEQN" %in% names(df)) next
    
    sub <- data.frame(SEQN = df$SEQN, value = as.numeric(df[[ac]]), 
                      survey_cycle = fc, stringsAsFactors = FALSE)
    sub <- sub[!is.na(sub$value), ]
    all_data[[length(all_data) + 1]] <- sub
  }
  
  if (length(all_data) == 0) next
  combined <- do.call(rbind, all_data)
  
  # 与DEMO合并获取种族
  merged <- merge(combined, 
                  demo_clean[, c("SEQN", "survey_cycle", "race_ethnicity")],
                  by = c("SEQN", "survey_cycle"))
  
  race_n <- table(merged$race_ethnicity)
  desc <- full_catalog$description[full_catalog$var_name == kv][1]
  
  cat(sprintf("  %-10s %-30s %d波次 | NHW:%5d NHB:%5d MA:%5d OH:%5d OTH:%5d\n",
              kv, desc, nrow(files_for_var),
              as.integer(race_n["NHW"]), as.integer(race_n["NHB"]),
              as.integer(race_n["MA"]), as.integer(race_n["OH"]),
              as.integer(race_n["OTH"])))
}

# ============================================================
# 保存索引
# ============================================================
saveRDS(var_index_df, file.path(CACHE_DIR, "variable_file_index.rds"))
write.csv(var_index_df, file.path(TABLE_DIR, "variable_file_index.csv"), row.names = FALSE)
saveRDS(var_coverage, file.path(CACHE_DIR, "variable_coverage.rds"))
write.csv(var_coverage, file.path(TABLE_DIR, "variable_coverage.csv"), row.names = FALSE)

cat(sprintf("\n[索引已保存] %s\n", file.path(CACHE_DIR, "variable_file_index.rds")))
log_info("变量文件索引构建完成: {nrow(var_index_df)} 条映射, {n_distinct(var_index_df$var_name)} 个变量")

cat("\n================================================================\n")
cat("  修复完成! 请确认覆盖情况满意后运行 Phase 2\n")
cat("  Phase 2 的 04_stratified_exwas.R 将自动使用新索引\n")
cat("================================================================\n")
