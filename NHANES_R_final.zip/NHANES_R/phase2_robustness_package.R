#=============================================================================
# phase2_robustness_package.R
# 强化稳健性包：Top异质性对的详细证据链
#=============================================================================
# 输出:
#   1. table3_top_hits_detail.csv     — 主表Table 3素材
#   2. sensitivity_log_outcome.csv    — log-outcome敏感性分析
#   3. sensitivity_extra_confounders.csv — 额外混杂调整
#   4. table_s4_all_fdr_sig.csv       — 全部FDR显著交互对详情
#   5. fig_robustness_forest.png      — 稳健性森林图
#
# 使用:
#   setwd("E:/NHANES_R")
#   source("phase2_robustness_package.R")
#
# 前提: phase2_common_scale.R 已运行
#=============================================================================

source("00_config.R")
log_info("===== 稳健性分析包 =====")

library(survey)
library(broom)
library(data.table)
library(ggplot2)
library(patchwork)

# ============================================================
# PART 0: 加载数据
# ============================================================
cat("\n[PART 0] 加载数据...\n")

demo_clean     <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
full_catalog   <- readRDS(file.path(CACHE_DIR, "variable_catalog.rds"))
var_file_index <- readRDS(file.path(CACHE_DIR, "variable_file_index.rds"))
interaction_cs <- readRDS(file.path(CACHE_DIR, "interaction_results_common_scale.rds"))
results_cs     <- readRDS(file.path(CACHE_DIR, "exwas_results_common_scale.rds"))

demo_clean$SEQN <- as.double(demo_clean$SEQN)

demo_slim <- demo_clean[, c("SEQN", "survey_cycle", "race_ethnicity",
                             "female", "age", "age_sq",
                             "education", "income_poverty_ratio",
                             "wt_mec", "psu", "strata")]

cat(sprintf("  交互结果: %d 对, 其中 FDR显著: %d\n",
            nrow(interaction_cs), sum(interaction_cs$fdr_sig_int, na.rm = TRUE)))

# 复用 load_var
load_var <- function(var_name, index) {
  vf <- index[index$var_name == var_name, ]
  if (nrow(vf) == 0) return(NULL)
  chunks <- vector("list", nrow(vf))
  for (i in seq_len(nrow(vf))) {
    df <- tryCatch(haven::read_xpt(vf$file_path[i]), error = function(e) NULL)
    if (is.null(df)) next
    col <- vf$actual_colname[i]
    if (!col %in% names(df) || !"SEQN" %in% names(df)) next
    chunks[[i]] <- data.frame(SEQN = as.double(df[["SEQN"]]),
                               val = as.numeric(df[[col]]),
                               survey_cycle = vf$survey_cycle[i],
                               stringsAsFactors = FALSE)
  }
  chunks <- chunks[!sapply(chunks, is.null)]
  if (length(chunks) == 0) return(NULL)
  out <- do.call(rbind, chunks)
  out <- out[!duplicated(out[, c("SEQN", "survey_cycle")]), ]
  out <- out[!is.na(out$val), ]
  names(out)[2] <- var_name
  return(out)
}

# ============================================================
# PART 1: 确定Top Hits
# ============================================================
cat("\n[PART 1] 确定Top Hits...\n")

# 从共同尺度分层结果中计算 cross-race β range
actual_races <- c("NHW", "NHB", "MA", "OH", "OTH")
rv <- results_cs[results_cs$race_group %in% actual_races, ]

beta_range <- aggregate(beta ~ exposure + phenotype, data = rv,
                        FUN = function(x) {
                          if (length(x) < 3) return(NA)
                          max(x, na.rm = TRUE) - min(x, na.rm = TRUE)
                        })
names(beta_range)[3] <- "beta_range"
beta_range <- beta_range[!is.na(beta_range$beta_range), ]

# 合并交互P值
beta_range <- merge(beta_range,
                    interaction_cs[, c("exposure", "phenotype",
                                       "p_interaction", "p_fdr_int", "fdr_sig_int")],
                    by = c("exposure", "phenotype"), all.x = TRUE)

# Top 15: 按beta_range排序，限定FDR显著的
top_sig <- beta_range[beta_range$fdr_sig_int == TRUE, ]
top_sig <- top_sig[order(-top_sig$beta_range), ]
top15 <- head(top_sig, 15)

cat("  Top 15 heterogeneous pairs (FDR-significant, common scale):\n")
for (i in seq_len(nrow(top15))) {
  cat(sprintf("    %2d. %s → %s (range=%.3f, p_int=%.2e, q=%.4f)\n",
              i, top15$exposure[i], top15$phenotype[i],
              top15$beta_range[i], top15$p_interaction[i], top15$p_fdr_int[i]))
}

# ============================================================
# PART 2: 每个Top Hit的详细分组统计 (Table 3素材)
# ============================================================
cat("\n[PART 2] 生成Table 3详细数据...\n")

# 对每个top pair，提取各组的 n, β, SE, 95%CI, p
table3_data <- list()

for (i in seq_len(nrow(top15))) {
  ep <- top15[i, ]
  
  # 从共同尺度结果中提取各组数据
  pair_data <- results_cs[results_cs$exposure == ep$exposure &
                           results_cs$phenotype == ep$phenotype, ]
  
  for (j in seq_len(nrow(pair_data))) {
    row <- pair_data[j, ]
    table3_data[[length(table3_data) + 1]] <- data.frame(
      rank         = i,
      exposure     = ep$exposure,
      phenotype    = ep$phenotype,
      race_group   = row$race_group,
      n_obs        = row$n_obs,
      beta         = row$beta,
      se           = row$se,
      ci_low       = row$beta - 1.96 * row$se,
      ci_high      = row$beta + 1.96 * row$se,
      p_value      = row$p_value,
      beta_range   = ep$beta_range,
      p_interaction = ep$p_interaction,
      fdr_q        = ep$p_fdr_int,
      stringsAsFactors = FALSE
    )
  }
}

table3_df <- do.call(rbind, table3_data)

cat(sprintf("  Table 3 行数: %d (Top %d pairs × 各组)\n", nrow(table3_df), nrow(top15)))

# ============================================================
# PART 3: 偏态表型的 log-outcome 敏感性分析
# ============================================================
cat("\n[PART 3] Log-outcome 敏感性分析...\n")

# 定义需要log转换的偏态表型
SKEWED_PHENOTYPES <- c(
  "LBXSGTSI",  # GGT
  "LBXIN",     # Insulin
  "LBXTR",     # Triglycerides
  "LBXCRP",    # CRP
  "URXUMA",    # Urinary albumin
  "LBXSATSI",  # ALT
  "LBXGLU",    # Fasting glucose (mild skew)
  "LBXSUA"     # Uric acid
)

# 找出top15中涉及偏态表型的对
skewed_pairs <- top15[top15$phenotype %in% SKEWED_PHENOTYPES, ]
cat(sprintf("  Top15中涉及偏态表型的对: %d\n", nrow(skewed_pairs)))

# 同时对所有FDR显著的偏态表型对做log-outcome
all_skewed <- top_sig[top_sig$phenotype %in% SKEWED_PHENOTYPES, ]
cat(sprintf("  所有FDR显著中涉及偏态表型的对: %d\n", nrow(all_skewed)))

# 合并两组（去重）
pairs_for_log <- unique(rbind(
  skewed_pairs[, c("exposure", "phenotype")],
  all_skewed[, c("exposure", "phenotype")]
))

run_log_outcome <- function(exp_data, phe_data, demo, exp_name, phe_name, race_grp = NULL) {
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  if (!is.null(race_grp)) m <- m[m$race_ethnicity == race_grp, ]
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$age) & !is.na(m$female), ]
  
  nn <- nrow(m); nc <- length(unique(m$survey_cycle))
  if (nn < MIN_SAMPLE_SIZE || nc < MIN_SURVEY_WAVES) return(NULL)
  
  # 暴露: log10
  x <- m[[exp_name]]
  mnz <- min(x[x > 0], na.rm = TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm = TRUE) == 0) return(NULL)
  
  # ★ 表型: log转换 ★
  y <- m[[phe_name]]
  if (any(y <= 0, na.rm = TRUE)) {
    min_pos <- min(y[y > 0], na.rm = TRUE)
    y[y <= 0] <- min_pos / 2
  }
  m$P_log <- log(y)  # natural log
  
  m$wt_adj <- m$wt_mec / nc
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_log ~ E_log10 + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nn * 0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nn * 0.5)
    fml_str <- paste(fml_str, "+ education")
  if (is.null(race_grp)) {
    m$race_f <- droplevels(factor(m$race_ethnicity))
    if (nlevels(m$race_f) > 1) fml_str <- paste(fml_str, "+ race_f")
  }
  
  des <- tryCatch(svydesign(id=~psu, strata=~strata, weights=~wt_adj, data=m, nest=TRUE),
                  error = function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str), design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  if (!"E_log10" %in% rownames(co)) return(NULL)
  
  data.frame(exposure=exp_name, phenotype=phe_name,
             race_group=ifelse(is.null(race_grp),"ALL",race_grp),
             n_obs=nn, beta_log=co["E_log10","Estimate"],
             se_log=co["E_log10","Std. Error"],
             p_log=co["E_log10","Pr(>|t|)"],
             stringsAsFactors=FALSE)
}

run_log_interaction <- function(exp_data, phe_data, demo, exp_name, phe_name) {
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$race_ethnicity) & !is.na(m$age) & !is.na(m$female), ]
  if (nrow(m) < 500) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x>0], na.rm=TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm=TRUE)==0) return(NULL)
  
  y <- m[[phe_name]]
  if (any(y <= 0, na.rm=TRUE)) { mp <- min(y[y>0],na.rm=TRUE); y[y<=0] <- mp/2 }
  m$P_log <- log(y)
  
  nc <- length(unique(m$survey_cycle))
  m$wt_adj <- m$wt_mec / nc
  m$race_f <- droplevels(factor(m$race_ethnicity, levels=c("NHW","NHB","MA","OH","OTH")))
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_log ~ E_log10 * race_f + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nrow(m)*0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nrow(m)*0.5)
    fml_str <- paste(fml_str, "+ education")
  
  des <- tryCatch(svydesign(id=~psu,strata=~strata,weights=~wt_adj,data=m,nest=TRUE),
                  error=function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str), design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  int_terms <- grep("^E_log10:race_f", rownames(co), value=TRUE)
  if (length(int_terms)==0) return(NULL)
  
  p_int <- tryCatch({regTermTest(fit,"E_log10:race_f")$p},
                    error=function(e) min(co[int_terms,"Pr(>|t|)"],na.rm=TRUE))
  
  data.frame(exposure=exp_name, phenotype=phe_name,
             p_interaction_log=p_int, sensitivity="log_outcome",
             stringsAsFactors=FALSE)
}

# 执行log-outcome分析
log_strat_list <- list()
log_int_list   <- list()
lsi <- 0; lii <- 0

cat(sprintf("  对 %d 对进行log-outcome分析...\n", nrow(pairs_for_log)))

for (k in seq_len(nrow(pairs_for_log))) {
  ename <- pairs_for_log$exposure[k]
  pname <- pairs_for_log$phenotype[k]
  
  if (k %% 10 == 0) cat(sprintf("\r    %d/%d", k, nrow(pairs_for_log)))
  
  edata <- load_var(ename, var_file_index)
  pdata <- load_var(pname, var_file_index)
  if (is.null(edata) || is.null(pdata)) next
  
  # 分层
  for (rg in c("ALL", actual_races)) {
    rarg <- if (rg=="ALL") NULL else rg
    r <- tryCatch(run_log_outcome(edata, pdata, demo_slim, ename, pname, rarg),
                  error=function(e) NULL)
    if (!is.null(r)) { lsi <- lsi+1; log_strat_list[[lsi]] <- r }
  }
  
  # 交互
  ir <- tryCatch(run_log_interaction(edata, pdata, demo_slim, ename, pname),
                 error=function(e) NULL)
  if (!is.null(ir)) { lii <- lii+1; log_int_list[[lii]] <- ir }
}

log_strat_df <- if (lsi>0) do.call(rbind, log_strat_list[1:lsi]) else data.frame()
log_int_df   <- if (lii>0) do.call(rbind, log_int_list[1:lii]) else data.frame()

cat(sprintf("\n  Log-outcome结果: %d条分层, %d条交互\n", nrow(log_strat_df), nrow(log_int_df)))

# ============================================================
# PART 4: 额外混杂调整敏感性
# ============================================================
cat("\n[PART 4] 额外混杂调整...\n")

# 需要额外加载 BMI 和吸烟状态
cat("  加载BMI和吸烟状态数据...\n")
bmi_data <- load_var("BMXBMI", var_file_index)
cotinine_data <- load_var("LBXCOT", var_file_index)  # 用cotinine作为吸烟连续指标

run_extra_confounders <- function(exp_data, phe_data, demo, exp_name, phe_name,
                                   bmi_dat = NULL, cot_dat = NULL, race_grp = NULL) {
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  
  # 额外合并BMI（如果表型不是BMI相关）
  add_bmi <- FALSE
  if (!is.null(bmi_dat) && !grepl("^BMX", phe_name) && !grepl("^BMX", exp_name)) {
    m <- merge(m, bmi_dat, by = c("SEQN", "survey_cycle"), all.x = TRUE)
    add_bmi <- TRUE
  }
  
  # 额外合并cotinine（如果暴露不是cotinine/吸烟相关）
  add_cot <- FALSE
  if (!is.null(cot_dat) && !grepl("COT", exp_name, ignore.case = TRUE)) {
    # 避免与已有cotinine列冲突
    if (!"LBXCOT" %in% names(m)) {
      m <- merge(m, cot_dat, by = c("SEQN", "survey_cycle"), all.x = TRUE)
      add_cot <- TRUE
    }
  }
  
  if (!is.null(race_grp)) m <- m[m$race_ethnicity == race_grp, ]
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$age) & !is.na(m$female), ]
  
  nn <- nrow(m); nc <- length(unique(m$survey_cycle))
  if (nn < MIN_SAMPLE_SIZE || nc < MIN_SURVEY_WAVES) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x>0], na.rm=TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm=TRUE)==0) return(NULL)
  m$P_raw <- m[[phe_name]]
  
  m$wt_adj <- m$wt_mec / nc
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_raw ~ E_log10 + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nn*0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nn*0.5)
    fml_str <- paste(fml_str, "+ education")
  if (is.null(race_grp)) {
    m$race_f <- droplevels(factor(m$race_ethnicity))
    if (nlevels(m$race_f) > 1) fml_str <- paste(fml_str, "+ race_f")
  }
  
  # ★ 额外混杂 ★
  confounders_added <- c()
  if (add_bmi && sum(!is.na(m$BMXBMI)) > nn*0.3) {
    fml_str <- paste(fml_str, "+ BMXBMI")
    confounders_added <- c(confounders_added, "BMI")
  }
  if (add_cot && "LBXCOT" %in% names(m) && sum(!is.na(m$LBXCOT)) > nn*0.3) {
    # log-transform cotinine
    m$cot_log <- log10(m$LBXCOT + 0.01)
    fml_str <- paste(fml_str, "+ cot_log")
    confounders_added <- c(confounders_added, "cotinine")
  }
  
  if (length(confounders_added) == 0) return(NULL)  # 没有额外混杂可加
  
  des <- tryCatch(svydesign(id=~psu, strata=~strata, weights=~wt_adj, data=m, nest=TRUE),
                  error=function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str), design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  if (!"E_log10" %in% rownames(co)) return(NULL)
  
  data.frame(exposure=exp_name, phenotype=phe_name,
             race_group=ifelse(is.null(race_grp),"ALL",race_grp),
             n_obs=nn,
             beta_adj=co["E_log10","Estimate"],
             se_adj=co["E_log10","Std. Error"],
             p_adj=co["E_log10","Pr(>|t|)"],
             extra_confounders=paste(confounders_added, collapse="+"),
             stringsAsFactors=FALSE)
}

run_extra_interaction <- function(exp_data, phe_data, demo, exp_name, phe_name,
                                   bmi_dat=NULL, cot_dat=NULL) {
  m <- merge(demo, exp_data, by = c("SEQN","survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN","survey_cycle"))
  
  add_bmi <- FALSE
  if (!is.null(bmi_dat) && !grepl("^BMX",phe_name) && !grepl("^BMX",exp_name)) {
    m <- merge(m, bmi_dat, by=c("SEQN","survey_cycle"), all.x=TRUE)
    add_bmi <- TRUE
  }
  add_cot <- FALSE
  if (!is.null(cot_dat) && !grepl("COT",exp_name,ignore.case=TRUE)) {
    if (!"LBXCOT" %in% names(m)) {
      m <- merge(m, cot_dat, by=c("SEQN","survey_cycle"), all.x=TRUE)
      add_cot <- TRUE
    }
  }
  
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec>0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$race_ethnicity) & !is.na(m$age) & !is.na(m$female), ]
  if (nrow(m)<500) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x>0],na.rm=TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x+mnz)
  if (sd(m$E_log10,na.rm=TRUE)==0) return(NULL)
  m$P_raw <- m[[phe_name]]
  
  nc <- length(unique(m$survey_cycle))
  m$wt_adj <- m$wt_mec / nc
  m$race_f <- droplevels(factor(m$race_ethnicity,levels=c("NHW","NHB","MA","OH","OTH")))
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_raw ~ E_log10 * race_f + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nrow(m)*0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nrow(m)*0.5)
    fml_str <- paste(fml_str, "+ education")
  
  confounders_added <- c()
  if (add_bmi && sum(!is.na(m$BMXBMI)) > nrow(m)*0.3) {
    fml_str <- paste(fml_str, "+ BMXBMI")
    confounders_added <- c(confounders_added, "BMI")
  }
  if (add_cot && "LBXCOT" %in% names(m) && sum(!is.na(m$LBXCOT)) > nrow(m)*0.3) {
    m$cot_log <- log10(m$LBXCOT + 0.01)
    fml_str <- paste(fml_str, "+ cot_log")
    confounders_added <- c(confounders_added, "cotinine")
  }
  if (length(confounders_added)==0) return(NULL)
  
  des <- tryCatch(svydesign(id=~psu,strata=~strata,weights=~wt_adj,data=m,nest=TRUE),
                  error=function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str),design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  int_terms <- grep("^E_log10:race_f", rownames(co), value=TRUE)
  if (length(int_terms)==0) return(NULL)
  
  p_int <- tryCatch({regTermTest(fit,"E_log10:race_f")$p},
                    error=function(e) min(co[int_terms,"Pr(>|t|)"],na.rm=TRUE))
  
  data.frame(exposure=exp_name, phenotype=phe_name,
             p_interaction_adj=p_int,
             extra_confounders=paste(confounders_added,collapse="+"),
             stringsAsFactors=FALSE)
}

# 对Top15执行额外混杂调整
extra_strat_list <- list()
extra_int_list   <- list()
esi <- 0; eii <- 0

cat(sprintf("  对Top %d对进行额外混杂调整...\n", nrow(top15)))

for (k in seq_len(nrow(top15))) {
  ename <- top15$exposure[k]
  pname <- top15$phenotype[k]
  
  cat(sprintf("\r    %d/%d: %s → %s", k, nrow(top15), ename, pname))
  
  edata <- load_var(ename, var_file_index)
  pdata <- load_var(pname, var_file_index)
  if (is.null(edata) || is.null(pdata)) next
  
  # 分层
  for (rg in c("ALL", actual_races)) {
    rarg <- if (rg=="ALL") NULL else rg
    r <- tryCatch(run_extra_confounders(edata, pdata, demo_slim, ename, pname,
                                         bmi_data, cotinine_data, rarg),
                  error=function(e) NULL)
    if (!is.null(r)) { esi <- esi+1; extra_strat_list[[esi]] <- r }
  }
  
  # 交互
  ir <- tryCatch(run_extra_interaction(edata, pdata, demo_slim, ename, pname,
                                        bmi_data, cotinine_data),
                 error=function(e) NULL)
  if (!is.null(ir)) { eii <- eii+1; extra_int_list[[eii]] <- ir }
}

extra_strat_df <- if (esi>0) do.call(rbind, extra_strat_list[1:esi]) else data.frame()
extra_int_df   <- if (eii>0) do.call(rbind, extra_int_list[1:eii]) else data.frame()

cat(sprintf("\n  额外混杂结果: %d条分层, %d条交互\n", nrow(extra_strat_df), nrow(extra_int_df)))

# ============================================================
# PART 5: 汇总Table 3（合并主分析+敏感性）
# ============================================================
cat("\n[PART 5] 汇总Table 3...\n")

# 主分析β
table3_final <- table3_df

# 合并log-outcome（如果适用）
if (nrow(log_strat_df) > 0) {
  table3_final <- merge(table3_final,
    log_strat_df[, c("exposure","phenotype","race_group","beta_log","se_log","p_log")],
    by = c("exposure","phenotype","race_group"), all.x = TRUE)
}

# 合并额外混杂
if (nrow(extra_strat_df) > 0) {
  table3_final <- merge(table3_final,
    extra_strat_df[, c("exposure","phenotype","race_group","beta_adj","se_adj","p_adj","extra_confounders")],
    by = c("exposure","phenotype","race_group"), all.x = TRUE)
}

# 合并log-outcome交互P
if (nrow(log_int_df) > 0) {
  table3_final <- merge(table3_final,
    log_int_df[, c("exposure","phenotype","p_interaction_log")],
    by = c("exposure","phenotype"), all.x = TRUE)
}

# 合并额外混杂交互P
if (nrow(extra_int_df) > 0) {
  table3_final <- merge(table3_final,
    extra_int_df[, c("exposure","phenotype","p_interaction_adj","extra_confounders")],
    by = c("exposure","phenotype"), all.x = TRUE,
    suffixes = c("", "_int"))
}

# 排序
table3_final <- table3_final[order(table3_final$rank,
                                    match(table3_final$race_group,
                                          c("ALL","NHW","NHB","MA","OH","OTH"))), ]

cat(sprintf("  Table 3 最终行数: %d\n", nrow(table3_final)))

# ============================================================
# PART 6: Table S4 — 全部244个FDR显著交互对的详情
# ============================================================
cat("\n[PART 6] 生成Table S4...\n")

fdr_sig_pairs <- interaction_cs[interaction_cs$fdr_sig_int == TRUE,
                                 c("exposure", "phenotype", "p_interaction",
                                   "p_fdr_int", "beta_NHW", "se_NHW",
                                   "beta_int_NHB", "beta_int_MA",
                                   "beta_int_OH", "beta_int_OTH",
                                   "p_int_NHB", "p_int_MA", "p_int_OH", "p_int_OTH",
                                   "n_obs")]

# 添加各组的分层β和n
for (rg in c("ALL", actual_races)) {
  sub <- results_cs[results_cs$race_group == rg,
                     c("exposure", "phenotype", "n_obs", "beta", "se", "p_value")]
  names(sub)[3:6] <- paste0(c("n_", "beta_", "se_", "p_"), rg)
  fdr_sig_pairs <- merge(fdr_sig_pairs, sub, by = c("exposure", "phenotype"), all.x = TRUE)
}

# 添加分类信息
fdr_sig_pairs <- merge(fdr_sig_pairs,
  full_catalog[full_catalog$var_type=="exposure", c("var_name","category")],
  by.x="exposure", by.y="var_name", all.x=TRUE)
names(fdr_sig_pairs)[names(fdr_sig_pairs)=="category"] <- "exp_category"

fdr_sig_pairs <- merge(fdr_sig_pairs,
  full_catalog[full_catalog$var_type=="phenotype", c("var_name","category")],
  by.x="phenotype", by.y="var_name", all.x=TRUE)
names(fdr_sig_pairs)[names(fdr_sig_pairs)=="category"] <- "phe_category"

# 排序
fdr_sig_pairs <- fdr_sig_pairs[order(fdr_sig_pairs$p_interaction), ]

cat(sprintf("  Table S4 行数: %d\n", nrow(fdr_sig_pairs)))

# ============================================================
# PART 7: 保存所有结果
# ============================================================
cat("\n[PART 7] 保存...\n")

fwrite(as.data.table(table3_final),
       file.path(OUTPUT_DIR, "table3_top_hits_detail.csv"))
fwrite(as.data.table(fdr_sig_pairs),
       file.path(OUTPUT_DIR, "table_s4_all_fdr_sig_detail.csv"))

if (nrow(log_strat_df) > 0)
  fwrite(as.data.table(log_strat_df),
         file.path(OUTPUT_DIR, "sensitivity_log_outcome_stratified.csv"))
if (nrow(log_int_df) > 0)
  fwrite(as.data.table(log_int_df),
         file.path(OUTPUT_DIR, "sensitivity_log_outcome_interaction.csv"))
if (nrow(extra_strat_df) > 0)
  fwrite(as.data.table(extra_strat_df),
         file.path(OUTPUT_DIR, "sensitivity_extra_confounders_stratified.csv"))
if (nrow(extra_int_df) > 0)
  fwrite(as.data.table(extra_int_df),
         file.path(OUTPUT_DIR, "sensitivity_extra_confounders_interaction.csv"))

# ============================================================
# PART 8: 稳健性汇总森林图
# ============================================================
cat("\n[PART 8] 稳健性汇总图...\n")

tryCatch({
  # 取top5做对比森林图: 主分析 vs log-outcome vs extra-confounder
  top5_pairs <- top15[1:min(5, nrow(top15)), c("exposure","phenotype")]
  
  plot_list <- list()
  
  for (k in seq_len(nrow(top5_pairs))) {
    ep <- top5_pairs[k, ]
    
    # 主分析
    main <- table3_df[table3_df$exposure == ep$exposure &
                       table3_df$phenotype == ep$phenotype &
                       table3_df$race_group %in% actual_races, ]
    main$model <- "Primary"
    main <- main[, c("race_group","beta","se","model")]
    
    # Log-outcome
    if (nrow(log_strat_df) > 0) {
      logr <- log_strat_df[log_strat_df$exposure == ep$exposure &
                            log_strat_df$phenotype == ep$phenotype &
                            log_strat_df$race_group %in% actual_races, ]
      if (nrow(logr) > 0) {
        logr$model <- "Log-outcome"
        logr <- data.frame(race_group=logr$race_group, beta=logr$beta_log,
                           se=logr$se_log, model=logr$model)
        main <- rbind(main, logr)
      }
    }
    
    # Extra confounder
    if (nrow(extra_strat_df) > 0) {
      exr <- extra_strat_df[extra_strat_df$exposure == ep$exposure &
                             extra_strat_df$phenotype == ep$phenotype &
                             extra_strat_df$race_group %in% actual_races, ]
      if (nrow(exr) > 0) {
        exr$model <- paste0("+", exr$extra_confounders[1])
        exr <- data.frame(race_group=exr$race_group, beta=exr$beta_adj,
                           se=exr$se_adj, model=exr$model)
        main <- rbind(main, exr)
      }
    }
    
    if (nrow(main) < 5) next
    
    main$ci_lo <- main$beta - 1.96 * main$se
    main$ci_hi <- main$beta + 1.96 * main$se
    main$race_group <- factor(main$race_group, levels = actual_races)
    
    p <- ggplot(main, aes(x = beta, y = race_group, color = model, shape = model)) +
      geom_vline(xintercept = 0, linetype = "dashed", color = "grey60") +
      geom_point(position = position_dodge(0.5), size = 2.5) +
      geom_errorbarh(aes(xmin = ci_lo, xmax = ci_hi),
                     height = 0.2, position = position_dodge(0.5)) +
      scale_color_manual(values = c("Primary" = "#333333",
                                     "Log-outcome" = "#E15759",
                                     "+BMI" = "#4E79A7",
                                     "+cotinine" = "#76B7B2",
                                     "+BMI+cotinine" = "#F28E2B")) +
      labs(title = paste0(ep$exposure, " → ", ep$phenotype),
           x = "β", y = "", color = "Model", shape = "Model") +
      theme_minimal(base_size = 10) +
      theme(legend.position = "bottom", plot.title = element_text(size = 9))
    
    plot_list[[k]] <- p
  }
  
  if (length(plot_list) > 0) {
    p_combined <- wrap_plots(plot_list, ncol = 1)
    ggsave(file.path(FIGURE_DIR, "fig_robustness_forest.png"),
           p_combined, width = 10, height = 4 * length(plot_list), dpi = 300)
    cat("  [OK] fig_robustness_forest\n")
  }
}, error = function(e) cat("  [SKIP] robustness forest:", e$message, "\n"))

# ============================================================
# PART 9: 稳健性汇总报告
# ============================================================
cat("\n[PART 9] 稳健性汇总...\n")

cat("\n  ═══ Top 15 Hits 稳健性汇总 ═══\n")
cat(sprintf("  %-4s %-10s %-10s %8s %12s %12s %12s\n",
            "Rank", "Exposure", "Phenotype", "β_range", "P_int(prim)", "P_int(log)", "P_int(+conf)"))
cat(paste(rep("─", 80), collapse=""), "\n")

for (i in seq_len(nrow(top15))) {
  ep <- top15[i, ]
  
  p_log <- NA
  if (nrow(log_int_df) > 0) {
    lr <- log_int_df[log_int_df$exposure==ep$exposure & log_int_df$phenotype==ep$phenotype, ]
    if (nrow(lr)>0) p_log <- lr$p_interaction_log[1]
  }
  
  p_adj <- NA
  if (nrow(extra_int_df) > 0) {
    er <- extra_int_df[extra_int_df$exposure==ep$exposure & extra_int_df$phenotype==ep$phenotype, ]
    if (nrow(er)>0) p_adj <- er$p_interaction_adj[1]
  }
  
  cat(sprintf("  %2d   %-10s %-10s %8.3f %12.2e %12.2e %12.2e\n",
              i, ep$exposure, ep$phenotype, ep$beta_range,
              ep$p_interaction,
              ifelse(is.na(p_log), NA, p_log),
              ifelse(is.na(p_adj), NA, p_adj)))
}

# ============================================================
cat("\n╔════════════════════════════════════════════════════════════════╗\n")
cat("║  稳健性分析包完成!                                            ║\n")
cat("║                                                                ║\n")
cat("║  输出文件:                                                     ║\n")
cat("║    table3_top_hits_detail.csv        — Table 3 素材             ║\n")
cat("║    table_s4_all_fdr_sig_detail.csv   — Table S4 全部详情        ║\n")
cat("║    sensitivity_log_outcome_*.csv     — Log-outcome敏感性       ║\n")
cat("║    sensitivity_extra_confounders_*.csv — 额外混杂敏感性        ║\n")
cat("║    fig_robustness_forest.png         — 稳健性对比森林图        ║\n")
cat("╚════════════════════════════════════════════════════════════════╝\n")
log_info("稳健性分析包完成")
