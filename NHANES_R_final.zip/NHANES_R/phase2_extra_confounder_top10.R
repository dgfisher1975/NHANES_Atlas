#=============================================================================
# phase2_extra_confounder_top10.R
# 对P值排序Top 10交互对运行+BMI+cotinine敏感性分析
#=============================================================================

source("00_config.R")
library(survey)
library(data.table)

cat("\n[加载数据]\n")
demo_clean     <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
var_file_index <- readRDS(file.path(CACHE_DIR, "variable_file_index.rds"))
interaction_cs <- readRDS(file.path(CACHE_DIR, "interaction_results_common_scale.rds"))
results_cs     <- readRDS(file.path(CACHE_DIR, "exwas_results_common_scale.rds"))

demo_clean$SEQN <- as.double(demo_clean$SEQN)
demo_slim <- demo_clean[, c("SEQN","survey_cycle","race_ethnicity",
                             "female","age","age_sq","education",
                             "income_poverty_ratio","wt_mec","psu","strata")]

load_var <- function(var_name, index) {
  vf <- index[index$var_name == var_name, ]
  if (nrow(vf) == 0) return(NULL)
  chunks <- vector("list", nrow(vf))
  for (i in seq_len(nrow(vf))) {
    df <- tryCatch(haven::read_xpt(vf$file_path[i]), error = function(e) NULL)
    if (is.null(df)) next
    col <- vf$actual_colname[i]
    if (!col %in% names(df) || !"SEQN" %in% names(df)) next
    chunks[[i]] <- data.frame(SEQN=as.double(df[["SEQN"]]), val=as.numeric(df[[col]]),
                               survey_cycle=vf$survey_cycle[i], stringsAsFactors=FALSE)
  }
  chunks <- chunks[!sapply(chunks, is.null)]
  if (length(chunks) == 0) return(NULL)
  out <- do.call(rbind, chunks)
  out <- out[!duplicated(out[, c("SEQN","survey_cycle")]), ]
  out <- out[!is.na(out$val), ]
  names(out)[2] <- var_name
  return(out)
}

# P-ranked Top 10
top10 <- head(interaction_cs[order(interaction_cs$p_interaction), ], 10)
cat("\n  P-ranked Top 10:\n")
for (i in 1:10) cat(sprintf("    %2d. %s → %s (P=%.2e)\n",
                              i, top10$exposure[i], top10$phenotype[i], top10$p_interaction[i]))

# 加载BMI和cotinine
cat("\n  加载BMI和cotinine...\n")
bmi_data <- load_var("BMXBMI", var_file_index)
cot_data <- load_var("LBXCOT", var_file_index)
if (!is.null(cot_data)) {
  cot_data$LBXCOT_log <- log10(cot_data$LBXCOT + 0.01)
}

# ============================================================
# 交互模型 + 额外混杂
# ============================================================
actual_races <- c("NHW","NHB","MA","OH","OTH")

run_int_adj <- function(exp_data, phe_data, demo, exp_name, phe_name,
                         bmi_dat, cot_dat) {
  m <- merge(demo, exp_data, by = c("SEQN","survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN","survey_cycle"))
  
  # 判断可加的混杂
  can_bmi <- !grepl("^BMX", phe_name) & !grepl("^BMX", exp_name)
  can_cot <- !grepl("COT", exp_name, ignore.case = TRUE)
  
  add_bmi <- FALSE; add_cot <- FALSE
  if (can_bmi && !is.null(bmi_dat)) {
    m <- merge(m, bmi_dat[, c("SEQN","survey_cycle","BMXBMI")],
               by = c("SEQN","survey_cycle"), all.x = TRUE)
    if (sum(!is.na(m$BMXBMI)) > nrow(m) * 0.3) add_bmi <- TRUE
  }
  if (can_cot && !is.null(cot_dat)) {
    m <- merge(m, cot_dat[, c("SEQN","survey_cycle","LBXCOT_log")],
               by = c("SEQN","survey_cycle"), all.x = TRUE)
    if (sum(!is.na(m$LBXCOT_log)) > nrow(m) * 0.3) add_cot <- TRUE
  }
  
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$race_ethnicity) & !is.na(m$age) & !is.na(m$female), ]
  if (nrow(m) < 500) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x>0], na.rm=TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm=TRUE) == 0) return(NULL)
  m$P_raw <- m[[phe_name]]
  
  nc <- length(unique(m$survey_cycle))
  m$wt_adj <- m$wt_mec / nc
  m$race_f <- droplevels(factor(m$race_ethnicity, levels=c("NHW","NHB","MA","OH","OTH")))
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_raw ~ E_log10 * race_f + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nrow(m)*0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nrow(m)*0.5)
    fml_str <- paste(fml_str, "+ education")
  
  confounders <- c()
  if (add_bmi) { fml_str <- paste(fml_str, "+ BMXBMI"); confounders <- c(confounders, "BMI") }
  if (add_cot) { fml_str <- paste(fml_str, "+ LBXCOT_log"); confounders <- c(confounders, "cotinine") }
  
  des <- tryCatch(svydesign(id=~psu, strata=~strata, weights=~wt_adj, data=m, nest=TRUE),
                  error=function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(as.formula(fml_str), design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  int_terms <- grep("^E_log10:race_f", rownames(summary(fit)$coefficients), value=TRUE)
  if (length(int_terms) == 0) return(NULL)
  
  p_int <- tryCatch({regTermTest(fit, "E_log10:race_f")$p},
                    error=function(e) NA)
  
  data.frame(
    exposure = exp_name, phenotype = phe_name,
    can_add_bmi = can_bmi, can_add_cot = can_cot,
    added_bmi = add_bmi, added_cot = add_cot,
    extra_confounders = if (length(confounders) > 0) paste(confounders, collapse="+") else "N/A",
    n_obs_adj = nrow(m),
    p_interaction_adj = p_int,
    stringsAsFactors = FALSE
  )
}

# 分层回归 + 额外混杂
run_strat_adj <- function(exp_data, phe_data, demo, exp_name, phe_name,
                           bmi_dat, cot_dat, race_grp = NULL) {
  m <- merge(demo, exp_data, by=c("SEQN","survey_cycle"))
  m <- merge(m, phe_data, by=c("SEQN","survey_cycle"))
  
  can_bmi <- !grepl("^BMX", phe_name) & !grepl("^BMX", exp_name)
  can_cot <- !grepl("COT", exp_name, ignore.case=TRUE)
  
  add_bmi <- FALSE; add_cot <- FALSE
  if (can_bmi && !is.null(bmi_dat)) {
    m <- merge(m, bmi_dat[,c("SEQN","survey_cycle","BMXBMI")], by=c("SEQN","survey_cycle"), all.x=TRUE)
    if (sum(!is.na(m$BMXBMI)) > nrow(m)*0.3) add_bmi <- TRUE
  }
  if (can_cot && !is.null(cot_dat)) {
    m <- merge(m, cot_dat[,c("SEQN","survey_cycle","LBXCOT_log")], by=c("SEQN","survey_cycle"), all.x=TRUE)
    if (sum(!is.na(m$LBXCOT_log)) > nrow(m)*0.3) add_cot <- TRUE
  }
  
  if (!is.null(race_grp)) m <- m[m$race_ethnicity == race_grp, ]
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) & !is.na(m$age) & !is.na(m$female), ]
  
  nn <- nrow(m); nc <- length(unique(m$survey_cycle))
  if (nn < 200 || nc < 2) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x>0], na.rm=TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm=TRUE)==0) return(NULL)
  m$P_raw <- m[[phe_name]]
  m$wt_adj <- m$wt_mec / nc
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  fml_str <- "P_raw ~ E_log10 + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nn*0.5) fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nn*0.5) fml_str <- paste(fml_str, "+ education")
  if (is.null(race_grp)) {
    m$race_f <- droplevels(factor(m$race_ethnicity))
    if (nlevels(m$race_f) > 1) fml_str <- paste(fml_str, "+ race_f")
  }
  if (add_bmi) fml_str <- paste(fml_str, "+ BMXBMI")
  if (add_cot) fml_str <- paste(fml_str, "+ LBXCOT_log")
  
  des <- tryCatch(svydesign(id=~psu, strata=~strata, weights=~wt_adj, data=m, nest=TRUE), error=function(e) NULL)
  if (is.null(des)) return(NULL)
  fit <- tryCatch(svyglm(as.formula(fml_str), design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  co <- summary(fit)$coefficients
  if (!"E_log10" %in% rownames(co)) return(NULL)
  
  data.frame(exposure=exp_name, phenotype=phe_name,
             race_group=ifelse(is.null(race_grp),"ALL",race_grp),
             n_adj=nn, beta_adj=co["E_log10","Estimate"], se_adj=co["E_log10","Std. Error"],
             p_adj=co["E_log10","Pr(>|t|)"],
             extra_confounders=if(add_bmi||add_cot) paste(c(if(add_bmi)"BMI",if(add_cot)"cotinine"),collapse="+") else "N/A",
             stringsAsFactors=FALSE)
}

# ============================================================
# 执行
# ============================================================
cat("\n[运行Top 10额外混杂调整]\n")

int_adj_list <- list()
strat_adj_list <- list()
ii <- 0; si <- 0

for (k in 1:nrow(top10)) {
  ename <- top10$exposure[k]; pname <- top10$phenotype[k]
  cat(sprintf("  %d/10: %s → %s", k, ename, pname))
  
  edata <- load_var(ename, var_file_index)
  pdata <- load_var(pname, var_file_index)
  if (is.null(edata) || is.null(pdata)) { cat(" [跳过]\n"); next }
  
  # 交互
  ir <- tryCatch(run_int_adj(edata, pdata, demo_slim, ename, pname, bmi_data, cot_data),
                 error=function(e) NULL)
  if (!is.null(ir)) {
    ii <- ii+1; int_adj_list[[ii]] <- ir
    cat(sprintf(" | +%s | P_adj=%.2e", ir$extra_confounders, ir$p_interaction_adj))
  }
  
  # 分层
  for (rg in c("ALL", actual_races)) {
    rarg <- if(rg=="ALL") NULL else rg
    sr <- tryCatch(run_strat_adj(edata, pdata, demo_slim, ename, pname, bmi_data, cot_data, rarg),
                   error=function(e) NULL)
    if (!is.null(sr)) { si <- si+1; strat_adj_list[[si]] <- sr }
  }
  cat("\n")
}

int_adj_df <- if(ii>0) do.call(rbind, int_adj_list[1:ii]) else data.frame()
strat_adj_df <- if(si>0) do.call(rbind, strat_adj_list[1:si]) else data.frame()

# ============================================================
# 汇总对比表
# ============================================================
cat("\n[汇总]\n")

comp <- merge(top10[, c("exposure","phenotype","p_interaction","n_obs")],
              int_adj_df, by=c("exposure","phenotype"), all.x=TRUE)

cat("\n═══════════════════════════════════════════════════════════════════════════════════════════\n")
cat(sprintf("%-4s %-10s %-10s %12s %12s %-18s %s\n",
            "Rank","Exposure","Phenotype","P_primary","P_adjusted","Added confounders","Preserved?"))
cat("─────────────────────────────────────────────────────────────────────────────────────────\n")

for (i in 1:nrow(comp)) {
  r <- comp[i, ]
  padj <- if(!is.na(r$p_interaction_adj)) sprintf("%.2e", r$p_interaction_adj) else "—"
  ec <- if(!is.na(r$extra_confounders)) r$extra_confounders else "N/A"
  preserved <- if(!is.na(r$p_interaction_adj)) {
    if(r$p_interaction_adj < 0.05) "Yes" else "No"
  } else "N/A (no extra confounders applicable)"
  cat(sprintf("%2d   %-10s %-10s %12.2e %12s %-18s %s\n",
              i, r$exposure, r$phenotype, r$p_interaction, padj, ec, preserved))
}

# 分层β对比
cat("\n  分层β对比（primary vs adjusted）:\n")
strat_comp <- merge(
  strat_adj_df[, c("exposure","phenotype","race_group","beta_adj","se_adj")],
  results_cs[, c("exposure","phenotype","race_group","beta","se")],
  by=c("exposure","phenotype","race_group")
)
strat_comp$same_dir <- sign(strat_comp$beta_adj) == sign(strat_comp$beta)
strat_comp$pct_change <- abs(strat_comp$beta_adj - strat_comp$beta) / abs(strat_comp$beta) * 100

cat(sprintf("  方向一致率: %.1f%% (%d/%d)\n",
            100*mean(strat_comp$same_dir, na.rm=TRUE),
            sum(strat_comp$same_dir, na.rm=TRUE), nrow(strat_comp)))
cat(sprintf("  β变化中位数: %.1f%%\n", median(strat_comp$pct_change, na.rm=TRUE)))

# 保存
fwrite(comp, file.path(OUTPUT_DIR, "table_s6_extra_confounder_top10_interaction.csv"))
fwrite(strat_adj_df, file.path(OUTPUT_DIR, "table_s6_extra_confounder_top10_stratified.csv"))
fwrite(strat_comp, file.path(OUTPUT_DIR, "table_s6_extra_confounder_top10_beta_comparison.csv"))

cat("\n  → table_s6_extra_confounder_top10_*.csv 已保存\n")
cat("\n[完成]\n")
