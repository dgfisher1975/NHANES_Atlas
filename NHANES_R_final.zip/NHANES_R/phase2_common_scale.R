#=============================================================================
# phase2_common_scale.R
# 共同剂量尺度补充分析
#=============================================================================
# 目的: 以 log10 原值（不做标准化）作为暴露尺度，重新运行：
#       (1) 分层回归（用于森林图、跨组β比较）
#       (2) 交互模型（作为效应修饰的主分析）
#
# 使用方法:
#   setwd("E:/NHANES_R")
#   source("phase2_common_scale.R")
#
# 前提: phase2_v3.R 已成功运行（需要 demo_clean, var_file_index, full_catalog）
#       或者对应的 .rds 缓存文件存在
#=============================================================================

source("00_config.R")
log_info("===== 共同剂量尺度补充分析 =====")

library(survey)
library(broom)
library(data.table)
library(ggplot2)
library(patchwork)
library(scales)

# ============================================================
# PART 0: 加载数据（与 phase2_v3 相同）
# ============================================================
cat("\n[PART 0] 加载数据...\n")

demo_clean     <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
full_catalog   <- readRDS(file.path(CACHE_DIR, "variable_catalog.rds"))
var_file_index <- readRDS(file.path(CACHE_DIR, "variable_file_index.rds"))

demo_clean$SEQN <- as.double(demo_clean$SEQN)

demo_slim <- demo_clean[, c("SEQN", "survey_cycle", "race_ethnicity",
                             "female", "age", "age_sq",
                             "education", "income_poverty_ratio",
                             "wt_mec", "psu", "strata")]

available_exp <- intersect(
  full_catalog$var_name[full_catalog$var_type == "exposure" & full_catalog$is_continuous],
  unique(var_file_index$var_name)
)
available_phe <- intersect(
  full_catalog$var_name[full_catalog$var_type == "phenotype"],
  unique(var_file_index$var_name)
)

cat(sprintf("  暴露: %d | 表型: %d | DEMO: %s 人\n",
            length(available_exp), length(available_phe),
            format(nrow(demo_slim), big.mark = ",")))

# ============================================================
# 复用 phase2_v3 的 load_var 函数
# ============================================================
load_var <- function(var_name, index) {
  vf <- index[index$var_name == var_name, ]
  if (nrow(vf) == 0) return(NULL)
  
  chunks <- vector("list", nrow(vf))
  for (i in seq_len(nrow(vf))) {
    df <- tryCatch(haven::read_xpt(vf$file_path[i]), error = function(e) NULL)
    if (is.null(df)) next
    col <- vf$actual_colname[i]
    if (!col %in% names(df) || !"SEQN" %in% names(df)) next
    chunks[[i]] <- data.frame(
      SEQN = as.double(df[["SEQN"]]),
      val  = as.numeric(df[[col]]),
      survey_cycle = vf$survey_cycle[i],
      stringsAsFactors = FALSE
    )
  }
  chunks <- chunks[!sapply(chunks, is.null)]
  if (length(chunks) == 0) return(NULL)
  out <- do.call(rbind, chunks)
  out <- out[!duplicated(out[, c("SEQN", "survey_cycle")]), ]
  out <- out[!is.na(out$val), ]
  names(out)[2] <- var_name
  return(out)
}

# ============================================================
# PART 1: 共同尺度回归函数
# ============================================================
# 核心改动（仅两处，其余与 phase2_v3 完全一致）:
#   1. 暴露: 只做 log10 转换，不做 z-score 标准化 → E_log10
#   2. 表型: 不做标准化，保留原始单位 → 直接用原值
#
# β 的解读: 暴露每增加 1 log10 单位（即浓度增大10倍），
#            表型变化的原始单位数

run_reg_common <- function(exp_data, phe_data, demo, exp_name, phe_name, race_grp = NULL) {
  
  # 合并
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  
  if (!is.null(race_grp)) m <- m[m$race_ethnicity == race_grp, ]
  
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$age) & !is.na(m$female), ]
  
  nn <- nrow(m)
  nc <- length(unique(m$survey_cycle))
  if (nn < MIN_SAMPLE_SIZE || nc < MIN_SURVEY_WAVES) return(NULL)
  
  # ═══════════════════════════════════════════════════════════
  # ★ 核心改动1: 暴露只做 log10，不标准化 ★
  # ═══════════════════════════════════════════════════════════
  x <- m[[exp_name]]
  mnz <- min(x[x > 0], na.rm = TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  
  # 检查暴露变异
  if (sd(m$E_log10, na.rm = TRUE) == 0) return(NULL)
  
  # ═══════════════════════════════════════════════════════════
  # ★ 核心改动2: 表型用全样本（全种族）加权SD标准化 ★
  #   这样β可解读为：暴露每增1 log10单位，表型变化几个全样本SD
  #   如果是分层分析，仍用全样本SD（不是组内SD），确保跨组可比
  # ═══════════════════════════════════════════════════════════
  y <- m[[phe_name]]
  # 注意：这里我们需要全样本（不分种族）的mean和SD
  # 但当前函数已按种族筛选过了，所以需要从外部传入
  # → 折中方案：表型也不标准化，β就是原始单位；
  #   或者在主循环中预计算全样本SD后传入。
  # 这里采用更简洁的方案：表型不标准化，β为原始单位变化。
  #   后续可在结果汇总时除以全样本SD得到标准化β。
  m$P_raw <- y
  
  # 权重
  m$wt_adj <- m$wt_mec / nc
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  # 公式构建（与v3一致的逻辑）
  if (nlevels(m$cycle_f) <= 1) {
    fml_str <- "P_raw ~ E_log10 + age + age_sq + female"
  } else {
    fml_str <- "P_raw ~ E_log10 + age + age_sq + female + cycle_f"
  }
  if (sum(!is.na(m$income_poverty_ratio)) > nn * 0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nn * 0.5)
    fml_str <- paste(fml_str, "+ education")
  if (is.null(race_grp)) {
    m$race_f <- droplevels(factor(m$race_ethnicity))
    if (nlevels(m$race_f) > 1) fml_str <- paste(fml_str, "+ race_f")
  }
  
  fml <- as.formula(fml_str)
  
  des <- tryCatch(
    svydesign(id = ~psu, strata = ~strata, weights = ~wt_adj, data = m, nest = TRUE),
    error = function(e) NULL
  )
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(fml, design = des), error = function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  if (!"E_log10" %in% rownames(co)) return(NULL)
  
  data.frame(
    exposure    = exp_name,
    phenotype   = phe_name,
    race_group  = ifelse(is.null(race_grp), "ALL", race_grp),
    n_obs       = nn,
    n_cycles    = nc,
    beta        = co["E_log10", "Estimate"],
    se          = co["E_log10", "Std. Error"],
    p_value     = co["E_log10", "Pr(>|t|)"],
    scale       = "log10_common",
    stringsAsFactors = FALSE
  )
}

# ============================================================
# 共同尺度交互检验
# ============================================================

run_int_common <- function(exp_data, phe_data, demo, exp_name, phe_name) {
  
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$race_ethnicity) & !is.na(m$age) & !is.na(m$female), ]
  
  if (nrow(m) < 500) return(NULL)
  
  # ★ 暴露: 只做 log10 ★
  x <- m[[exp_name]]
  mnz <- min(x[x > 0], na.rm = TRUE)
  if (!is.finite(mnz)) return(NULL)
  m$E_log10 <- log10(x + mnz)
  if (sd(m$E_log10, na.rm = TRUE) == 0) return(NULL)
  
  # ★ 表型: 不标准化 ★
  m$P_raw <- m[[phe_name]]
  
  nc <- length(unique(m$survey_cycle))
  m$wt_adj <- m$wt_mec / nc
  m$race_f <- droplevels(factor(m$race_ethnicity, levels = c("NHW","NHB","MA","OH","OTH")))
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  des <- tryCatch(
    svydesign(id = ~psu, strata = ~strata, weights = ~wt_adj, data = m, nest = TRUE),
    error = function(e) NULL
  )
  if (is.null(des)) return(NULL)
  
  # 构建公式（与v3一致，但加入income和education）
  fml_str <- "P_raw ~ E_log10 * race_f + age + age_sq + female + cycle_f"
  if (sum(!is.na(m$income_poverty_ratio)) > nrow(m) * 0.5)
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  if (sum(!is.na(m$education)) > nrow(m) * 0.5)
    fml_str <- paste(fml_str, "+ education")
  
  fit <- tryCatch(
    svyglm(as.formula(fml_str), design = des),
    error = function(e) NULL
  )
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  int_terms <- grep("^E_log10:race_f", rownames(co), value = TRUE)
  if (length(int_terms) == 0) return(NULL)
  
  # Wald联合检验
  p_int <- tryCatch({
    regTermTest(fit, "E_log10:race_f")$p
  }, error = function(e) {
    min(co[int_terms, "Pr(>|t|)"], na.rm = TRUE)
  })
  
  gv <- function(term, col) if (term %in% rownames(co)) co[term, col] else NA
  
  data.frame(
    exposure = exp_name, phenotype = phe_name,
    p_interaction = p_int, n_obs = nrow(m),
    # NHW的主效应（参考组斜率）
    beta_NHW = gv("E_log10", "Estimate"),
    se_NHW   = gv("E_log10", "Std. Error"),
    # 各组相对于NHW的交互项
    beta_int_NHB = gv("E_log10:race_fNHB", "Estimate"),
    beta_int_MA  = gv("E_log10:race_fMA",  "Estimate"),
    beta_int_OH  = gv("E_log10:race_fOH",  "Estimate"),
    beta_int_OTH = gv("E_log10:race_fOTH", "Estimate"),
    p_int_NHB = gv("E_log10:race_fNHB", "Pr(>|t|)"),
    p_int_MA  = gv("E_log10:race_fMA",  "Pr(>|t|)"),
    p_int_OH  = gv("E_log10:race_fOH",  "Pr(>|t|)"),
    p_int_OTH = gv("E_log10:race_fOTH", "Pr(>|t|)"),
    scale = "log10_common",
    stringsAsFactors = FALSE
  )
}

# ============================================================
# PART 2: 主循环
# ============================================================
cat("\n[PART 2] 执行共同尺度分层ExWAS...\n")

RACES <- c("ALL", "NHW", "NHB", "MA", "OH", "OTH")
total_pairs <- length(available_exp) * length(available_phe)
cat(sprintf("  %d暴露 × %d表型 = %d对 × 6组 = ~%d次回归\n",
            length(available_exp), length(available_phe), total_pairs, total_pairs * 6))

res_list <- list()
int_list <- list()
ri <- 0; ii <- 0
t0 <- Sys.time()
pc <- 0

for (ename in available_exp) {
  edata <- load_var(ename, var_file_index)
  if (is.null(edata)) next
  
  for (pname in available_phe) {
    pc <- pc + 1
    if (pc %% 50 == 0 || pc == 1) {
      el <- as.numeric(difftime(Sys.time(), t0, units = "mins"))
      eta <- if (pc > 1) (total_pairs - pc) / (pc / el) else NA
      cat(sprintf("\r  [%d/%d] %.0f%% | %.1fmin | ~%.0fmin剩余 | %s × %s      ",
                  pc, total_pairs, 100 * pc / total_pairs, el, eta, ename, pname))
    }
    
    pdata <- load_var(pname, var_file_index)
    if (is.null(pdata)) next
    
    # 各种族回归（共同尺度）
    for (rg in RACES) {
      rarg <- if (rg == "ALL") NULL else rg
      r <- tryCatch(
        run_reg_common(edata, pdata, demo_slim, ename, pname, rarg),
        error = function(e) NULL
      )
      if (!is.null(r)) { ri <- ri + 1; res_list[[ri]] <- r }
    }
    
    # 交互（共同尺度）
    ir <- tryCatch(
      run_int_common(edata, pdata, demo_slim, ename, pname),
      error = function(e) NULL
    )
    if (!is.null(ir)) { ii <- ii + 1; int_list[[ii]] <- ir }
    
    # 定期保存
    if (pc %% 200 == 0 && ri > 0) {
      saveRDS(do.call(rbind, res_list[1:ri]),
              file.path(CACHE_DIR, "results_common_scale_temp.rds"))
    }
  }
}

cat(sprintf("\n\n  完成! 耗时%.1f分钟 | 结果:%d条 | 交互:%d条\n",
            as.numeric(difftime(Sys.time(), t0, units = "mins")), ri, ii))

# ============================================================
# PART 3: 多重检验校正
# ============================================================
cat("\n[PART 3] 多重检验校正...\n")

results_cs <- do.call(rbind, res_list[1:ri])
interaction_cs <- if (ii > 0) do.call(rbind, int_list[1:ii]) else data.frame()

results_cs$bonferroni_sig <- FALSE
results_cs$p_fdr <- 1
results_cs$fdr_sig <- FALSE

for (rg in unique(results_cs$race_group)) {
  idx <- results_cs$race_group == rg
  nt <- sum(idx)
  results_cs$bonferroni_sig[idx] <- results_cs$p_value[idx] < (0.05 / nt)
  results_cs$p_fdr[idx] <- p.adjust(results_cs$p_value[idx], method = "BY")
  results_cs$fdr_sig[idx] <- results_cs$p_fdr[idx] < 0.05
}

if (nrow(interaction_cs) > 0) {
  interaction_cs$p_fdr_int <- p.adjust(interaction_cs$p_interaction, method = "BY")
  interaction_cs$fdr_sig_int <- interaction_cs$p_fdr_int < 0.05
}

# 汇总
cat("\n  ===== 共同尺度 各种族ExWAS结果汇总 =====\n")
for (rg in c("ALL", "NHW", "NHB", "MA", "OH", "OTH")) {
  sub <- results_cs[results_cs$race_group == rg, ]
  if (nrow(sub) == 0) { cat(sprintf("  %s: 无结果\n", rg)); next }
  nb <- sum(sub$bonferroni_sig)
  nf <- sum(sub$fdr_sig)
  cat(sprintf("  %s: %4d关联 | %3d Bonferroni (%.1f%%) | %3d FDR\n",
              rg, nrow(sub), nb, 100 * nb / nrow(sub), nf))
}

if (nrow(interaction_cs) > 0) {
  cat(sprintf("\n  交互效应(共同尺度): %d / %d 通过FDR (%.1f%%)\n",
              sum(interaction_cs$fdr_sig_int, na.rm = TRUE), nrow(interaction_cs),
              100 * sum(interaction_cs$fdr_sig_int, na.rm = TRUE) / nrow(interaction_cs)))
}

# ============================================================
# PART 4: 种族间一致性（共同尺度）
# ============================================================
cat("\n[PART 4] 种族间一致性（共同尺度）...\n")

actual_races <- setdiff(unique(results_cs$race_group), "ALL")
wide_cs <- results_cs[results_cs$race_group != "ALL",
                       c("exposure", "phenotype", "race_group", "beta")]
wide_cs <- reshape(wide_cs, idvar = c("exposure", "phenotype"),
                   timevar = "race_group", direction = "wide")

combos <- combn(actual_races, 2, simplify = FALSE)
cat("\n  种族间beta相关性(共同尺度):\n")
for (cb in combos) {
  c1 <- paste0("beta.", cb[1]); c2 <- paste0("beta.", cb[2])
  if (!c1 %in% names(wide_cs) || !c2 %in% names(wide_cs)) next
  v <- !is.na(wide_cs[[c1]]) & !is.na(wide_cs[[c2]])
  if (sum(v) < 10) next
  r <- cor(wide_cs[[c1]][v], wide_cs[[c2]][v])
  sd_pct <- mean(sign(wide_cs[[c1]][v]) == sign(wide_cs[[c2]][v])) * 100
  cat(sprintf("  %s vs %s: r=%.3f | 同向%.1f%% (n=%d)\n",
              cb[1], cb[2], round(r, 3), round(sd_pct, 1), sum(v)))
}

# ============================================================
# PART 5: 与原始组内z-score结果对比
# ============================================================
cat("\n[PART 5] 与原始结果对比...\n")

old_results_path <- file.path(CACHE_DIR, "exwas_results_stratified.rds")
if (file.exists(old_results_path)) {
  results_old <- readRDS(old_results_path)
  
  # 合并两种尺度
  comp <- merge(
    results_cs[, c("exposure", "phenotype", "race_group", "beta", "se", "p_value")],
    results_old[, c("exposure", "phenotype", "race_group", "beta", "se", "p_value")],
    by = c("exposure", "phenotype", "race_group"),
    suffixes = c("_common", "_within")
  )
  
  if (nrow(comp) > 0) {
    # 方向一致率
    comp$same_dir <- sign(comp$beta_common) == sign(comp$beta_within)
    cat(sprintf("  总配对数: %d\n", nrow(comp)))
    cat(sprintf("  方向一致率: %.1f%%\n", 100 * mean(comp$same_dir, na.rm = TRUE)))
    
    # 按种族分组
    for (rg in c("ALL", "NHW", "NHB", "MA", "OH", "OTH")) {
      sub <- comp[comp$race_group == rg, ]
      if (nrow(sub) < 10) next
      r <- cor(sub$beta_common, sub$beta_within, use = "complete.obs")
      cat(sprintf("  %s: r=%.3f (n=%d) 同向%.1f%%\n",
                  rg, round(r, 3), nrow(sub),
                  100 * mean(sub$same_dir, na.rm = TRUE)))
    }
    
    fwrite(as.data.table(comp), file.path(OUTPUT_DIR, "scale_comparison.csv"))
    cat("  → scale_comparison.csv 已保存\n")
  }
} else {
  cat("  [跳过] 未找到原始结果文件\n")
}

# ============================================================
# PART 6: 保存
# ============================================================
cat("\n[PART 6] 保存共同尺度结果...\n")

saveRDS(results_cs, file.path(CACHE_DIR, "exwas_results_common_scale.rds"))
saveRDS(interaction_cs, file.path(CACHE_DIR, "interaction_results_common_scale.rds"))
fwrite(as.data.table(results_cs), file.path(OUTPUT_DIR, "exwas_common_scale_full.csv"))
if (nrow(interaction_cs) > 0)
  fwrite(as.data.table(interaction_cs), file.path(OUTPUT_DIR, "interaction_common_scale.csv"))

# ============================================================
# PART 7: 可视化
# ============================================================
cat("\n[PART 7] 生成共同尺度图表...\n")

race_colors <- c(ALL = "#999999", NHW = "#4E79A7", NHB = "#E15759",
                 MA = "#76B7B2", OH = "#F28E2B", OTH = "#B07AA1")

# Fig CS-1: 交互火山图（共同尺度）
tryCatch({
  if (nrow(interaction_cs) > 0) {
    idf <- interaction_cs[!is.na(interaction_cs$p_interaction) & interaction_cs$p_interaction > 0, ]
    idf$nlp <- pmin(-log10(idf$p_interaction), 15)
    idf$max_b <- pmax(
      abs(ifelse(is.na(idf$beta_int_NHB), 0, idf$beta_int_NHB)),
      abs(ifelse(is.na(idf$beta_int_MA),  0, idf$beta_int_MA)),
      abs(ifelse(is.na(idf$beta_int_OH),  0, idf$beta_int_OH)),
      abs(ifelse(is.na(idf$beta_int_OTH), 0, idf$beta_int_OTH))
    )
    idf$sig <- ifelse(idf$fdr_sig_int, "FDR<0.05", "NS")
    
    p_volcano <- ggplot(idf, aes(x = max_b, y = nlp, color = sig)) +
      geom_point(alpha = 0.5, size = 2) +
      scale_color_manual(values = c("FDR<0.05" = "#E15759", "NS" = "#CCCCCC")) +
      labs(title = "Exposure × Race Interaction (Common Dose Scale: per 1 log10-unit)",
           x = "|β_interaction|", y = "-log10(P)") +
      theme_minimal(base_size = 12) + theme(legend.position = "bottom")
    ggsave(file.path(FIGURE_DIR, "fig5_interaction_common_scale.png"),
           p_volcano, width = 9, height = 7, dpi = 300)
    cat("  [OK] fig5_interaction_common_scale\n")
  }
}, error = function(e) cat("  [SKIP] volcano:", e$message, "\n"))

# Fig CS-2: Top10 异质性森林图（共同尺度）
# ============================================================
# Fig 6: Top 10 交互效应森林图（共同尺度，按P值排序）
# 完整独立代码，直接运行即可
# ============================================================
results_cs     <- readRDS("E:/NHANES_DATA/ExWAS_Race_Stratified/cache/exwas_results_common_scale.rds")
interaction_cs <- readRDS("E:/NHANES_DATA/ExWAS_Race_Stratified/cache/interaction_results_common_scale.rds")
library(ggplot2)

race_colors <- c(ALL="#999999", NHW="#4E79A7", NHB="#E15759",
                 MA="#76B7B2", OH="#F28E2B", OTH="#B07AA1")
actual_races <- c("NHW","NHB","MA","OH","OTH")

# 1. 计算 beta range 并合并交互P
rv <- results_cs[results_cs$race_group %in% actual_races, ]
rv_range <- aggregate(beta ~ exposure + phenotype, data = rv,
                      FUN = function(x) max(x) - min(x))
names(rv_range)[3] <- "range_beta"
rv_range <- merge(rv_range,
                  interaction_cs[, c("exposure","phenotype","p_interaction")],
                  by = c("exposure","phenotype"), all.x = TRUE)

# 2. 按交互P值取Top 10
top10 <- head(rv_range[order(rv_range$p_interaction), ], 10)

# 3. 提取分层数据
fd <- merge(results_cs[results_cs$race_group %in% c(actual_races, "ALL"), ],
            top10[, c("exposure","phenotype")])
fd <- merge(fd, top10[, c("exposure","phenotype","p_interaction")])

# 4. 标签：带P值，按P值排序
fd$label <- sprintf("%s → %s\n(P_int = %.1e)",
                    fd$exposure, fd$phenotype, fd$p_interaction)
fd$label <- reorder(fd$label, log10(fd$p_interaction))  # 最显著在最上

# 5. 因子化
fd$race_group <- factor(fd$race_group,
                        levels = c("ALL","NHW","NHB","MA","OH","OTH"))
fd$ci_lo <- fd$beta - 1.96 * fd$se
fd$ci_hi <- fd$beta + 1.96 * fd$se

# 6. 绘图
p_forest <- ggplot(fd, aes(x = beta, y = race_group, color = race_group)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  geom_errorbarh(aes(xmin = ci_lo, xmax = ci_hi), height = 0.3, linewidth = 0.6) +
  geom_point(size = 2.8) +
  facet_wrap(~ label, scales = "free_x", ncol = 2) +
  scale_color_manual(values = race_colors) +
  labs(
    title = "Top 10 Exposure × Race/Ethnicity Interactions (Common Dose Scale)",
    subtitle = expression("Ranked by Wald interaction P;  " *
                            beta == " phenotype change per 1 log"[10]*"-unit increase in exposure"),
    x = expression(beta ~ "(per 1 log"[10]*"-unit increase)"),
    y = NULL,
    color = "Race/Ethnicity"
  ) +
  theme_bw(base_size = 11) +
  theme(
    # 白色背景
    plot.background    = element_rect(fill = "white", color = NA),
    panel.background   = element_rect(fill = "white", color = "grey80"),
    strip.background   = element_rect(fill = "#F0F4F8", color = "grey70"),
    strip.text         = element_text(size = 7.5, face = "bold", color = "grey20"),
    # 网格线
    panel.grid.major.x = element_line(color = "grey90", linewidth = 0.3),
    panel.grid.minor   = element_blank(),
    panel.grid.major.y = element_blank(),
    # 图例
    legend.position    = "bottom",
    legend.background  = element_rect(fill = "white", color = NA),
    legend.key         = element_rect(fill = "white"),
    # 标题
    plot.title         = element_text(size = 13, face = "bold", color = "grey10"),
    plot.subtitle      = element_text(size = 9, color = "grey30"),
    # 轴
    axis.text.y        = element_text(size = 9, color = "grey20"),
    axis.text.x        = element_text(size = 8, color = "grey30")
  )

ggsave(file.path(FIGURE_DIR, "fig6_forest_common_scale.png"),
       p_forest, width = 13, height = 14, dpi = 300,
       bg = "white")  # ← 关键：强制白色导出背景

cat("[OK] fig6_forest_common_scale.png 已保存至", "E:/NHANES_DATA/ExWAS_Race_Stratified/figures", "\n")


# Fig CS-3: 两种尺度β排名对比散点图
tryCatch({
  if (file.exists(old_results_path)) {
    # 取 top heterogeneous pairs 在两种尺度下的 range 排名
    results_old <- readRDS(old_results_path)
    
    # 原始尺度range
    rv_old <- results_old[results_old$race_group %in% actual_races, ]
    range_old <- aggregate(beta ~ exposure + phenotype, data = rv_old,
                           FUN = function(x) max(x) - min(x))
    names(range_old)[3] <- "range_within"
    
    # 共同尺度range
    range_new <- aggregate(beta ~ exposure + phenotype,
                           data = results_cs[results_cs$race_group %in% actual_races, ],
                           FUN = function(x) max(x) - min(x))
    names(range_new)[3] <- "range_common"
    
    range_comp <- merge(range_old, range_new, by = c("exposure", "phenotype"))
    
    if (nrow(range_comp) > 10) {
      range_comp$rank_within <- rank(-range_comp$range_within)
      range_comp$rank_common <- rank(-range_comp$range_common)
      
      r_rank <- cor(range_comp$rank_within, range_comp$rank_common, method = "spearman")
      
      p_rank <- ggplot(range_comp, aes(x = rank_within, y = rank_common)) +
        geom_point(alpha = 0.3, size = 1.5) +
        geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
        labs(title = "Heterogeneity Ranking: Within-group z vs Common Scale",
             subtitle = sprintf("Spearman ρ = %.3f (n = %d)", r_rank, nrow(range_comp)),
             x = "Rank (within-group z-score)", y = "Rank (common log10 scale)") +
        theme_minimal(base_size = 12)
      ggsave(file.path(FIGURE_DIR, "fig_rank_comparison.png"),
             p_rank, width = 8, height = 7, dpi = 300)
      cat(sprintf("  [OK] rank_comparison (Spearman ρ = %.3f)\n", r_rank))
    }
  }
}, error = function(e) cat("  [SKIP] rank comparison:", e$message, "\n"))

# ============================================================
cat("\n╔════════════════════════════════════════════════════════════╗\n")
cat("║  共同尺度补充分析完成!                                    ║\n")
cat(sprintf("║  结果: %s/output/  ║\n", PROJECT_DIR))
cat(sprintf("║  图形: %s/figures/ ║\n", PROJECT_DIR))
cat("║                                                            ║\n")
cat("║  输出文件:                                                 ║\n")
cat("║    exwas_common_scale_full.csv    分层回归(共同尺度)        ║\n")
cat("║    interaction_common_scale.csv   交互检验(共同尺度)        ║\n")
cat("║    scale_comparison.csv           两种尺度β对比             ║\n")
cat("║    fig5_interaction_common_scale.png                       ║\n")
cat("║    fig6_forest_common_scale.png                            ║\n")
cat("║    fig_rank_comparison.png                                 ║\n")
cat("╚════════════════════════════════════════════════════════════╝\n")
log_info("共同尺度补充分析完成")
