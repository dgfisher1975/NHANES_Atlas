#=============================================================================
# 脚本 01: NHANES数据加载、变量编目与协调化
#=============================================================================
# 功能:
#   1. 扫描本地NHANES数据目录结构
#   2. 加载人口统计学数据
#   3. 构建暴露变量和表型变量目录
#   4. 协调化跨波次变量编码
#=============================================================================

source("00_config.R")
log_info("===== 脚本01: 数据加载与编目 =====")

# ============================================================
# PART 1: 扫描NHANES本地数据目录
# ============================================================
cat("\n[PART 1] 扫描NHANES本地数据目录...\n")

#' 扫描NHANES数据目录，识别可用文件
#' @param base_dir NHANES根目录
#' @return data.frame 包含文件清单
scan_nhanes_directory <- function(base_dir) {
  
  if (!dir.exists(base_dir)) {
    stop("NHANES数据目录不存在: ", base_dir, 
         "\n请检查 00_config.R 中的 NHANES_DATA_DIR 设置")
  }
  
  # 递归查找所有XPT文件
  all_files <- list.files(base_dir, pattern = "\\.(XPT|xpt)$", 
                          recursive = TRUE, full.names = TRUE)
  
  if (length(all_files) == 0) {
    # 也尝试查找SAS格式
    all_files <- list.files(base_dir, pattern = "\\.(sas7bdat|csv)$", 
                            recursive = TRUE, full.names = TRUE)
  }
  
  cat("  找到", length(all_files), "个数据文件\n")
  
  # 提取文件信息
  file_info <- tibble(
    full_path  = all_files,
    filename   = basename(all_files),
    dir_path   = dirname(all_files),
    file_base  = tools::file_path_sans_ext(basename(all_files)),
    file_ext   = tools::file_ext(all_files),
    file_size  = file.size(all_files)
  )
  
  # 尝试从文件名或目录名推断调查波次
  file_info <- file_info %>%
    mutate(
      # 从文件名后缀推断波次
      cycle_suffix = str_extract(file_base, "_[A-J]$"),
      inferred_cycle = case_when(
        is.na(cycle_suffix) | cycle_suffix == "" ~ "1999-2000",
        cycle_suffix == "_B" ~ "2001-2002",
        cycle_suffix == "_C" ~ "2003-2004",
        cycle_suffix == "_D" ~ "2005-2006",
        cycle_suffix == "_E" ~ "2007-2008",
        cycle_suffix == "_F" ~ "2009-2010",
        cycle_suffix == "_G" ~ "2011-2012",
        cycle_suffix == "_H" ~ "2013-2014",
        cycle_suffix == "_I" ~ "2015-2016",
        cycle_suffix == "_J" ~ "2017-2018",
        TRUE ~ NA_character_
      ),
      # 从目录名中尝试提取波次
      dir_cycle = str_extract(dir_path, "\\d{4}-\\d{4}|\\d{4}_\\d{4}"),
      # 最终确定波次
      survey_cycle = coalesce(dir_cycle, inferred_cycle),
      # 提取变量表名（去除后缀）
      table_name = str_remove(file_base, "_[A-J]$")
    )
  
  return(file_info)
}

# 执行扫描
file_catalog <- scan_nhanes_directory(NHANES_DATA_DIR)

# 保存文件目录
write.csv(file_catalog, file.path(CACHE_DIR, "file_catalog.csv"), row.names = FALSE)
log_info("文件目录已保存，共 {nrow(file_catalog)} 个文件")

# 打印各波次文件数量
cat("\n  各波次文件数量:\n")
cycle_counts <- file_catalog %>% count(survey_cycle, sort = TRUE)
print(cycle_counts, n = Inf)

# ============================================================
# PART 2: 加载人口统计学(DEMO)数据
# ============================================================
cat("\n[PART 2] 加载人口统计学数据...\n")

#' 加载所有波次的DEMO数据
#' @param file_cat 文件目录
#' @return 合并的DEMO数据框
load_demographics <- function(file_cat) {
  
  # 查找DEMO文件
  demo_files <- file_cat %>%
    filter(str_detect(toupper(table_name), "^DEMO"))
  
  if (nrow(demo_files) == 0) {
    stop("未找到DEMO文件！请检查NHANES数据目录结构。")
  }
  
  cat("  找到", nrow(demo_files), "个DEMO文件\n")
  
  # 逐个读取并合并
  demo_list <- list()
  
  for (i in seq_len(nrow(demo_files))) {
    fpath  <- demo_files$full_path[i]
    fcycle <- demo_files$survey_cycle[i]
    
    cat("  读取:", basename(fpath), " (", fcycle, ")\n")
    
    df <- safe_read_xpt(fpath)
    if (is.null(df)) next
    
    # 选择需要的列（只保留存在的列）
    available_cols <- intersect(DEMO_VARS, names(df))
    df <- df[, available_cols, drop = FALSE]
    
    # 添加调查波次标识
    df$survey_cycle <- fcycle
    
    demo_list[[i]] <- df
  }
  
  # 合并所有波次
  demo_all <- bind_rows(demo_list)
  
  return(demo_all)
}

demo_data <- load_demographics(file_catalog)
log_info("DEMO数据加载完成: {nrow(demo_data)} 行, {ncol(demo_data)} 列")

# ============================================================
# PART 3: 人口统计学数据清洗与协调化
# ============================================================
cat("\n[PART 3] 人口统计学数据清洗与协调化...\n")

demo_clean <- demo_data %>%
  mutate(
    # ---- 种族/民族统一编码 ----
    # RIDRETH1 在所有波次中均可用 (1-5编码)
    race_ethnicity = case_when(
      RIDRETH1 == 3 ~ "NHW",
      RIDRETH1 == 4 ~ "NHB",
      RIDRETH1 == 1 ~ "MA",
      RIDRETH1 == 2 ~ "OH",
      RIDRETH1 == 5 ~ "OTH",
      TRUE ~ NA_character_
    ),
    race_label = case_when(
      race_ethnicity == "NHW" ~ "Non-Hispanic White",
      race_ethnicity == "NHB" ~ "Non-Hispanic Black",
      race_ethnicity == "MA"  ~ "Mexican American",
      race_ethnicity == "OH"  ~ "Other Hispanic",
      race_ethnicity == "OTH" ~ "Other/Multi-Racial",
      TRUE ~ NA_character_
    ),
    
    # ---- 性别 ----
    sex = case_when(
      RIAGENDR == 1 ~ "Male",
      RIAGENDR == 2 ~ "Female",
      TRUE ~ NA_character_
    ),
    female = as.integer(RIAGENDR == 2),
    
    # ---- 年龄 ----
    age = RIDAGEYR,
    age_sq = RIDAGEYR^2,
    
    # ---- 教育水平（成人20+） ----
    education = harmonize_education(DMDEDUC2),
    education_label = case_when(
      education == 1 ~ "Below HS",
      education == 2 ~ "HS/GED",
      education == 3 ~ "Above HS",
      TRUE ~ NA_character_
    ),
    
    # ---- 收入-贫困比 ----
    income_poverty_ratio = INDFMPIR,
    
    # ---- 调查权重 ----
    wt_mec = WTMEC2YR,
    wt_int = WTINT2YR,
    
    # ---- 调查设计变量 ----
    psu    = SDMVPSU,
    strata = SDMVSTRA
  ) %>%
  # 保留有种族信息的记录
  filter(!is.na(race_ethnicity))

cat("  清洗后记录数:", nrow(demo_clean), "\n")
cat("  各种族/民族人数:\n")
demo_clean %>% count(race_ethnicity, race_label) %>% print()

# 保存清洗后的DEMO数据
saveRDS(demo_clean, file.path(CACHE_DIR, "demo_clean.rds"))

# ============================================================
# PART 4: 暴露变量目录构建
# ============================================================
cat("\n[PART 4] 构建暴露变量目录...\n")

#' 定义暴露变量目录
#' 基于原文献的619个暴露指标分类体系
#' 此处列出核心变量名与其NHANES表名的映射
build_exposure_catalog <- function() {
  
  # ---- 膳食生物标志物 (血清/血浆) ----
  dietary_biomarker <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "LBXVIA",         "Retinol (Vitamin A)",           "VITAEC",        "dietary_biomarker",
    "LBXVIE",         "Alpha-tocopherol (Vit E)",      "VITAEC",        "dietary_biomarker",
    "LBXGTC",         "Gamma-tocopherol",              "VITAEC",        "dietary_biomarker",
    "LBXDTC",         "Delta-tocopherol",              "VITAEC",        "dietary_biomarker",
    "LBXALC",         "Alpha-carotene",                "VITAEC",        "dietary_biomarker",
    "LBXBEC",         "Trans-beta-carotene",           "VITAEC",        "dietary_biomarker",
    "LBXCBC",         "Cis-beta-carotene",             "VITAEC",        "dietary_biomarker",
    "LBXCRY",         "Cryptoxanthin",                 "VITAEC",        "dietary_biomarker",
    "LBXLUZ",         "Lutein+Zeaxanthin",             "VITAEC",        "dietary_biomarker",
    "LBXLYC",         "Lycopene",                      "VITAEC",        "dietary_biomarker",
    "LBXVD2",         "25OHD2",                        "VID",           "dietary_biomarker",
    "LBXVD3",         "25OHD3",                        "VID",           "dietary_biomarker",
    "LBDVIDMS",       "Vitamin D (standardized)",      "VID",           "dietary_biomarker",
    "LBXB12",         "Vitamin B12",                   "B12",           "dietary_biomarker",
    "LBXFOL",         "Folate, serum",                 "FOLATE",        "dietary_biomarker",
    "LBDRFO",         "RBC folate",                    "FOLATE",        "dietary_biomarker",
    "LBXFER",         "Ferritin",                      "FERTIN",        "dietary_biomarker",
    "LBXIRN",         "Iron",                          "FETIB",         "dietary_biomarker",
    "LBXTIB",         "TIBC",                          "FETIB",         "dietary_biomarker",
    "LBXSIR",         "Iron, refrigerated serum",      "BIOPRO",        "dietary_biomarker"
  )
  
  # ---- 吸烟生物标志物 ----
  smoking_biomarker <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "LBXCOT",         "Serum Cotinine",                "COT",           "smoking_biomarker",
    "LBXHCOT",        "Hydroxycotinine",               "COT",           "smoking_biomarker",
    "URXNAL",         "Urinary NNAL",                  "NNAL",          "smoking_biomarker",
    "URXCOTT",        "Urinary Cotinine",              "UCOT",          "smoking_biomarker"
  )
  
  # ---- 重金属 ----
  heavy_metals <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "LBXBPB",         "Blood Lead",                    "PBCD",          "heavy_metals",
    "LBXBCD",         "Blood Cadmium",                 "PBCD",          "heavy_metals",
    "LBXTHG",         "Blood Mercury, total",          "PBCD",          "heavy_metals",
    "LBXIHG",         "Blood Mercury, inorganic",      "PBCD",          "heavy_metals",
    "URXUBA",         "Urinary Barium",                "UHM",           "heavy_metals",
    "URXUCD",         "Urinary Cadmium",               "UHM",           "heavy_metals",
    "URXUCO",         "Urinary Cobalt",                "UHM",           "heavy_metals",
    "URXUCS",         "Urinary Cesium",                "UHM",           "heavy_metals",
    "URXUMO",         "Urinary Molybdenum",            "UHM",           "heavy_metals",
    "URXUPB",         "Urinary Lead",                  "UHM",           "heavy_metals",
    "URXUSB",         "Urinary Antimony",              "UHM",           "heavy_metals",
    "URXUTL",         "Urinary Thallium",              "UHM",           "heavy_metals",
    "URXUTU",         "Urinary Tungsten",              "UHM",           "heavy_metals",
    "URXUUR",         "Urinary Uranium",               "UHM",           "heavy_metals"
  )
  
  # ---- 有机氯 ----
  organochlorine <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "LBXPCB",         "PCB (various congeners)",       "PCBS",          "organochlorine",
    "LBXD01",         "1,2,3,7,8-pncdd",              "DOXPOL",        "organochlorine",
    "LBXHXC",         "Beta-HCH",                     "PESTMR",        "organochlorine",
    "LBXHCB",         "HCB",                           "PESTMR",        "organochlorine",
    "LBXODT",         "o,p'-DDT",                      "PESTMR",        "organochlorine",
    "LBXPDT",         "p,p'-DDT",                      "PESTMR",        "organochlorine",
    "LBXPDE",         "p,p'-DDE",                      "PESTMR",        "organochlorine",
    "LBXTNA",         "Trans-nonachlor",               "PESTMR",        "organochlorine",
    "LBXOXY",         "Oxychlordane",                  "PESTMR",        "organochlorine"
  )
  
  # ---- 邻苯二甲酸酯 ----
  phthalates <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "URXMEP",         "Mono-ethyl phthalate",          "PHTHTE",        "phthalates",
    "URXMBP",         "Mono-n-butyl phthalate",        "PHTHTE",        "phthalates",
    "URXMIB",         "Mono-isobutyl phthalate",       "PHTHTE",        "phthalates",
    "URXMHP",         "Mono-(2-ethyl)-hexyl pht",      "PHTHTE",        "phthalates",
    "URXMZP",         "Mono-benzyl phthalate",         "PHTHTE",        "phthalates",
    "URXMHH",         "MEHH phthalate",                "PHTHTE",        "phthalates",
    "URXECP",         "MECP phthalate",                "PHTHTE",        "phthalates",
    "URXMOH",         "MEOH phthalate",                "PHTHTE",        "phthalates",
    "URXMCN",         "Mono-carboxynonyl phthalate",   "PHTHTE",        "phthalates"
  )
  
  # ---- 全氟化合物 ----
  polyfluoro <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "LBXPFOA",        "PFOA",                          "PFAS",          "polyfluoro",
    "LBXPFOS",        "PFOS",                          "PFAS",          "polyfluoro",
    "LBXPFHS",        "PFHxS",                         "PFAS",          "polyfluoro",
    "LBXNFOA",        "n-PFOA",                        "PFAS",          "polyfluoro",
    "LBXNFOS",        "n-PFOS",                        "PFAS",          "polyfluoro",
    "LBXMPAH",        "Me-PFOSA-AcOH",                 "PFAS",          "polyfluoro",
    "LBXPFDE",        "PFDA",                          "PFAS",          "polyfluoro"
  )
  
  # ---- 酚类 ----
  phenols <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "URXBPH",         "Urinary BPA",                   "EPH",           "phenols",
    "URXBP3",         "Urinary Benzophenone-3",        "EPH",           "phenols",
    "URXTRS",         "Urinary Triclosan",             "EPH",           "phenols",
    "URX4TO",         "Urinary 4-tert-Octylphenol",    "EPH",           "phenols"
  )
  
  # ---- VOCs ----
  voc <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "LBXVBZ",         "Blood Benzene",                 "VOCWB",         "voc",
    "LBXVTO",         "Blood Toluene",                 "VOCWB",         "voc",
    "LBXVEB",         "Blood Ethylbenzene",            "VOCWB",         "voc",
    "LBXVXY",         "Blood o-Xylene",                "VOCWB",         "voc",
    "LBXVST",         "Blood Styrene",                 "VOCWB",         "voc",
    "LBXV3A",         "Blood 1,1,1-Trichloroethane",   "VOCWB",         "voc",
    "LBXVTC",         "Blood Trichloroethene",         "VOCWB",         "voc"
  )
  
  # ---- 吸烟行为 ----
  smoking_behavior <- tribble(
    ~var_name,        ~description,                    ~table_pattern,  ~category,
    "SMQ020",         "Smoked 100+ cigs in life",      "SMQ",           "smoking_behavior",
    "SMQ040",         "Current smoking status",        "SMQ",           "smoking_behavior",
    "SMD641",         "Cigarettes/day (past 30d)",     "SMQ",           "smoking_behavior"
  )
  
  # 合并所有暴露变量目录
  exposure_catalog <- bind_rows(
    dietary_biomarker, smoking_biomarker, heavy_metals,
    organochlorine, phthalates, polyfluoro, phenols,
    voc, smoking_behavior
  ) %>%
    mutate(
      var_type = "exposure",
      is_continuous = !str_detect(var_name, "^SMQ|^SMD")
    )
  
  return(exposure_catalog)
}

# ---- 表型变量目录 ----
build_phenotype_catalog <- function() {
  
  phenotype_catalog <- tribble(
    ~var_name,       ~description,                     ~table_pattern,   ~category,
    # 人体测量
    "BMXBMI",        "Body Mass Index",                "BMX",            "anthropometric",
    "BMXWT",         "Weight (kg)",                    "BMX",            "anthropometric",
    "BMXHT",         "Standing Height (cm)",           "BMX",            "anthropometric",
    "BMXWAIST",      "Waist Circumference (cm)",       "BMX",            "anthropometric",
    "BMXARML",       "Upper Arm Length (cm)",          "BMX",            "anthropometric",
    "BMXLEG",        "Upper Leg Length (cm)",          "BMX",            "anthropometric",
    
    # 血压
    "BPXSY1",        "Systolic BP (1st reading)",      "BPX",            "blood_pressure",
    "BPXDI1",        "Diastolic BP (1st reading)",     "BPX",            "blood_pressure",
    
    # 脂质
    "LBXTC",         "Total Cholesterol",              "TCHOL",          "lipids",
    "LBXTR",         "Triglycerides",                  "TRIGLY",         "lipids",
    "LBDHDD",        "HDL Cholesterol",                "HDL",            "lipids",
    "LBDLDL",        "LDL Cholesterol",                "TRIGLY",         "lipids",
    
    # 代谢
    "LBXGLU",        "Fasting Glucose",                "GLU",            "metabolic",
    "LBXGH",         "Glycated Hemoglobin (A1c%)",     "GHB",            "metabolic",
    "LBXIN",         "Fasting Insulin",                "INS",            "metabolic",
    
    # 肝功能
    "LBXSATSI",      "ALT (SGPT)",                     "BIOPRO",         "liver",
    "LBXSASSI",      "AST (SGOT)",                     "BIOPRO",         "liver",
    "LBXSGTSI",      "GGT",                            "GGT",            "liver",
    "LBXSBU",        "Blood Urea Nitrogen",            "BIOPRO",         "liver",
    "LBXSTB",        "Total Bilirubin",                "BIOPRO",         "liver",
    "LBXSAPSI",      "Alkaline Phosphatase",           "BIOPRO",         "liver",
    
    # 肾功能
    "LBXSCR",        "Serum Creatinine",               "BIOPRO",         "kidney",
    "LBXSUA",        "Uric Acid",                      "BIOPRO",         "kidney",
    "URXUMA",        "Urinary Albumin",                "ALB_CR",         "kidney",
    "URXUCR",        "Urinary Creatinine",             "ALB_CR",         "kidney",
    
    # 血液学
    "LBXWBCSI",      "White Blood Cell Count",         "CBC",            "blood",
    "LBXRBCSI",      "Red Blood Cell Count",           "CBC",            "blood",
    "LBXHGB",        "Hemoglobin",                     "CBC",            "blood",
    "LBXHCT",        "Hematocrit",                     "CBC",            "blood",
    "LBXMC",         "Mean Cell Volume (MCV)",         "CBC",            "blood",
    "LBXPLTSI",      "Platelet Count",                 "CBC",            "blood",
    "LBXRDW",        "RBC Distribution Width",         "CBC",            "blood",
    "LBXLYPCT",      "Lymphocyte %",                   "CBC",            "blood",
    "LBXMOPCT",      "Monocyte %",                     "CBC",            "blood",
    "LBXNEPCT",      "Neutrophil %",                   "CBC",            "blood",
    "LBXEOPCT",      "Eosinophil %",                   "CBC",            "blood",
    "LBXBAPCT",      "Basophil %",                     "CBC",            "blood",
    
    # 炎症
    "LBXCRP",        "C-Reactive Protein",             "CRP",            "inflammation",
    
    # 肺功能
    "SPXNFEV1",      "FEV1 (mL)",                      "SPX",            "lung",
    "SPXNFVC",       "FVC (mL)",                       "SPX",            "lung",
    "SPXNPEF",       "PEF (mL/s)",                     "SPX",            "lung",
    
    # 营养状态
    "LBXSAL",        "Albumin",                        "BIOPRO",         "nutrition",
    "LBXSTP",        "Total Protein",                  "BIOPRO",         "nutrition",
    
    # 电解质
    "LBXSCA",        "Calcium",                        "BIOPRO",         "electrolyte",
    "LBXSNASI",      "Sodium",                         "BIOPRO",         "electrolyte",
    "LBXSKSI",       "Potassium",                      "BIOPRO",         "electrolyte",
    "LBXSPH",        "Phosphorus",                     "BIOPRO",         "electrolyte",
    
    # 激素
    "LBXTSH",        "TSH",                            "THYROD",         "hormone"
  ) %>%
    mutate(
      var_type = "phenotype",
      is_continuous = TRUE
    )
  
  return(phenotype_catalog)
}

# 构建目录
exposure_catalog  <- build_exposure_catalog()
phenotype_catalog <- build_phenotype_catalog()

cat("  暴露变量目录:", nrow(exposure_catalog), "个变量,", 
    n_distinct(exposure_catalog$category), "个类别\n")
cat("  表型变量目录:", nrow(phenotype_catalog), "个变量,", 
    n_distinct(phenotype_catalog$category), "个类别\n")

# 合并为总目录
full_catalog <- bind_rows(exposure_catalog, phenotype_catalog)

# 保存目录
saveRDS(full_catalog, file.path(CACHE_DIR, "variable_catalog.rds"))
write.csv(full_catalog, file.path(TABLE_DIR, "variable_catalog.csv"), row.names = FALSE)

# ============================================================
# PART 5: 扫描变量在各波次中的可用性
# ============================================================
cat("\n[PART 5] 检查变量在各波次中的可用性...\n")

#' 检查特定变量在各波次中的存在性和样本量
#' @param var_info 单行变量信息
#' @param file_cat 文件目录
#' @param demo 人口统计学数据
check_variable_availability <- function(var_info, file_cat, demo) {
  
  var_name      <- var_info$var_name
  table_pattern <- var_info$table_pattern
  
  # 查找包含该表名模式的文件
  matching_files <- file_cat %>%
    filter(str_detect(toupper(table_name), toupper(table_pattern)))
  
  if (nrow(matching_files) == 0) return(NULL)
  
  results <- list()
  
  for (i in seq_len(nrow(matching_files))) {
    fpath <- matching_files$full_path[i]
    fcycle <- matching_files$survey_cycle[i]
    
    # 读取文件
    df <- safe_read_xpt(fpath)
    if (is.null(df)) next
    
    # 检查变量是否存在
    if (!var_name %in% names(df)) next
    
    # 与DEMO合并以获取种族信息
    if ("SEQN" %in% names(df)) {
      df_merged <- df %>%
        select(SEQN, all_of(var_name)) %>%
        inner_join(demo %>% select(SEQN, race_ethnicity, survey_cycle),
                   by = c("SEQN", "survey_cycle" = "survey_cycle")) %>%
        filter(!is.na(.data[[var_name]]))
      
      # 统计各种族的样本量
      race_n <- df_merged %>%
        count(race_ethnicity) %>%
        pivot_wider(names_from = race_ethnicity, values_from = n, values_fill = 0)
      
      results[[i]] <- tibble(
        var_name = var_name,
        survey_cycle = fcycle,
        total_n = nrow(df_merged)
      ) %>%
        bind_cols(race_n)
    }
  }
  
  if (length(results) == 0) return(NULL)
  bind_rows(results)
}

# 为节省时间，可以并行执行或分批处理
# 这里展示串行执行
cat("  正在逐变量检查可用性（这可能需要一段时间）...\n")

availability_list <- list()

# 先对demo数据添加一个简化版本用于合并
demo_for_merge <- demo_clean %>%
  select(SEQN, race_ethnicity, survey_cycle)

pb_total <- nrow(full_catalog)
pb_count <- 0

for (idx in seq_len(nrow(full_catalog))) {
  pb_count <- pb_count + 1
  if (pb_count %% 10 == 0) {
    cat(sprintf("\r  进度: %d / %d (%.0f%%)", pb_count, pb_total, 100*pb_count/pb_total))
  }
  
  result <- tryCatch(
    check_variable_availability(full_catalog[idx, ], file_catalog, demo_for_merge),
    error = function(e) NULL
  )
  
  if (!is.null(result)) {
    availability_list[[idx]] <- result
  }
}
cat("\n")

# 合并可用性结果
availability_df <- bind_rows(availability_list)

if (nrow(availability_df) > 0) {
  cat("  成功检查到", n_distinct(availability_df$var_name), "个变量的可用性\n")
  saveRDS(availability_df, file.path(CACHE_DIR, "variable_availability.rds"))
  write.csv(availability_df, file.path(TABLE_DIR, "variable_availability.csv"), row.names = FALSE)
} else {
  cat("  警告: 未能检查到任何变量的可用性，请检查数据目录结构\n")
  cat("  提示: 确保NHANES XPT文件位于:", NHANES_DATA_DIR, "\n")
}

log_info("脚本01完成: 变量编目与可用性检查")
cat("\n[脚本01完成]\n")
