#=============================================================================
# 种族/民族分层暴露组-表型关联图谱研究
# Phase 1: 数据准备、群体分层、样本量评估
# 脚本 00: 全局配置与依赖安装
#=============================================================================
# 项目: Race/Ethnicity-Stratified Exposome-Phenome Atlas
# 基于: Patel, Ioannidis & Manrai (2026) Nature Medicine
# 数据: NHANES 1999-2018
#=============================================================================

cat("
╔══════════════════════════════════════════════════════════════╗
║  种族/民族分层 Exposome-Phenome Atlas                       ║
║  Phase 1: 数据准备 · 群体分层 · 样本量评估                  ║
╚══════════════════════════════════════════════════════════════╝
\n")

# ---- 1. 全局路径配置 ----
# 请根据你的本地环境修改以下路径

# NHANES原始数据根目录
NHANES_DATA_DIR <- "E:/NHANES_DATA/NHANES"

# 项目输出目录（自动创建）
PROJECT_DIR <- "E:/NHANES_DATA/ExWAS_Race_Stratified"
OUTPUT_DIR  <- file.path(PROJECT_DIR, "output")
CACHE_DIR   <- file.path(PROJECT_DIR, "cache")
FIGURE_DIR  <- file.path(PROJECT_DIR, "figures")
TABLE_DIR   <- file.path(PROJECT_DIR, "tables")

# 创建目录
dirs_to_create <- c(PROJECT_DIR, OUTPUT_DIR, CACHE_DIR, FIGURE_DIR, TABLE_DIR)
for (d in dirs_to_create) {
  if (!dir.exists(d)) {
    dir.create(d, recursive = TRUE)
    cat("  [创建目录]", d, "\n")
  }
}

# ---- 2. NHANES调查波次定义 ----
SURVEY_CYCLES <- c(
  "1999-2000", "2001-2002", "2003-2004", "2005-2006", "2007-2008",
  "2009-2010", "2011-2012", "2013-2014", "2015-2016", "2017-2018"
)

# NHANES文件后缀与波次的映射
CYCLE_SUFFIX <- c(
  "1999-2000" = "",      # 或 "_A" 取决于文件命名

"2001-2002" = "_B",
  "2003-2004" = "_C",
  "2005-2006" = "_D",
  "2007-2008" = "_E",
  "2009-2010" = "_F",
  "2011-2012" = "_G",
  "2013-2014" = "_H",
  "2015-2016" = "_I",
  "2017-2018" = "_J"
)

# ---- 3. 种族/民族分组定义 ----
# NHANES变量 RIDRETH1 (1999-2006) 和 RIDRETH3 (2007-2018) 编码：
# 使用 RIDRETH1 统一编码:
#   1 = Mexican American
#   2 = Other Hispanic
#   3 = Non-Hispanic White
#   4 = Non-Hispanic Black
#   5 = Other Race (including Multi-Racial)

RACE_GROUPS <- list(
  NHW = list(code = 3, label = "Non-Hispanic White",   label_cn = "非西班牙裔白人"),
  NHB = list(code = 4, label = "Non-Hispanic Black",   label_cn = "非西班牙裔黑人"),
  MA  = list(code = 1, label = "Mexican American",     label_cn = "墨西哥裔美国人"),
  OH  = list(code = 2, label = "Other Hispanic",       label_cn = "其他西班牙裔"),
  OTH = list(code = 5, label = "Other/Multi-Racial",   label_cn = "其他/多种族")
)

RACE_VAR <- "RIDRETH1"  # 统一使用该变量(全10波次均可用)

# ---- 4. 人口统计学协变量 ----
DEMO_VARS <- c(
  "SEQN",          # 参与者ID
  "RIAGENDR",      # 性别 (1=Male, 2=Female)
  "RIDAGEYR",      # 年龄(岁)
  "RIDRETH1",      # 种族/民族(5分类)
  "DMDEDUC2",      # 教育水平(成人20+)
  "DMDEDUC3",      # 教育水平(儿童6-19)
  "INDFMPIR",      # 收入-贫困比
  "WTMEC2YR",      # MEC权重(2年)
  "WTINT2YR",      # 访谈权重(2年)
  "SDMVPSU",       # 伪PSU
  "SDMVSTRA"       # 伪层
)

# ---- 5. 暴露变量分类定义 ----
EXPOSOME_CATEGORIES <- c(
  "dietary_biomarker",  "dietary_interview",  "supplements",
  "smoking_biomarker",  "smoking_behavior",
  "heavy_metals",       "voc",                "hydrocarbon",
  "organochlorine",     "organophosphate",    "phenols",
  "phthalates",         "polyfluoro",         "diakyl",
  "amine_amide",        "infection",          "priority_pesticide",
  "pyrethroid"
)

# ---- 6. 表型分类定义 ----
PHENOME_CATEGORIES <- c(
  "anthropometric",  "aging",           "blood",
  "blood_pressure",  "bone",            "dexa",
  "electrolyte",     "fitness",         "hormone",
  "inflammation",    "iron",            "kidney",
  "lipids",          "liver",           "metabolic",
  "microbiome",      "nutrition",       "psa",
  "lung"
)

# ---- 7. 统计参数 ----
# 最小样本量要求（每个种族-暴露-表型组合）
MIN_SAMPLE_SIZE <- 300

# 最少需要出现的调查波次数
MIN_SURVEY_WAVES <- 2

# Bonferroni校正的显著性水平（将在实际检验数确定后调整）
BONFERRONI_ALPHA <- 0.05  # 总alpha，具体阈值 = 0.05/总检验数

# FDR水平
FDR_LEVEL <- 0.05

# 检验效能计算参数
POWER_TARGET <- 0.80
ALPHA_POWER  <- 1e-5  # 用于效能计算的alpha

# ---- 8. 安装与加载依赖包 ----
required_packages <- c(
  # 核心分析
  "survey",         # 调查加权回归
  "DBI",            # 数据库接口
  "RSQLite",        # SQLite
  "haven",          # 读取SAS/XPT文件
  "foreign",        # 读取XPT文件备选
  
  # 数据处理
  "dplyr",          # 数据操作
  "tidyr",          # 数据整理
  "purrr",          # 函数式编程
  "stringr",        # 字符串处理
  "tibble",         # 增强数据框
  "readr",          # 快速读取
  "data.table",     # 大数据快速操作
  "forcats",        # 因子处理
  
  # 统计
  "broom",          # 模型结果整理
  "mice",           # 多重插补
  "pwr",            # 检验效能
  
  # 可视化
  "ggplot2",        # 绑图
  "ggpubr",         # 出版级图形
  "patchwork",      # 图形拼接
  "RColorBrewer",   # 配色
  "scales",         # 坐标轴格式化
  "gt",             # 表格
  "knitr",          # 报告
  
  # 日志
  "logger"          # 日志记录
)

cat("\n[检查并安装R包...]\n")
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    cat("  安装:", pkg, "\n")
    install.packages(pkg, repos = "https://cran.r-project.org", quiet = TRUE)
  }
}

# 加载核心包
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(stringr)
  library(haven)
  library(survey)
  library(ggplot2)
  library(data.table)
  library(logger)
})

# ---- 9. 日志配置 ----
log_file <- file.path(PROJECT_DIR, paste0("phase1_log_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".log"))
log_appender(appender_tee(log_file))
log_info("========== Phase 1 启动 ==========")
log_info("NHANES数据目录: {NHANES_DATA_DIR}")
log_info("项目输出目录: {PROJECT_DIR}")
log_info("R版本: {R.version.string}")

# ---- 10. 辅助函数 ----

#' 安全读取XPT文件
#' @param filepath XPT文件路径
#' @return data.frame 或 NULL
safe_read_xpt <- function(filepath) {
  tryCatch({
    if (grepl("\\.XPT$|\\.xpt$", filepath)) {
      df <- haven::read_xpt(filepath)
    } else if (grepl("\\.sas7bdat$", filepath)) {
      df <- haven::read_sas(filepath)
    } else {
      df <- haven::read_xpt(filepath)
    }
    return(as.data.frame(df))
  }, error = function(e) {
    log_warn("无法读取文件: {filepath} - {e$message}")
    return(NULL)
  })
}

#' 教育水平统一编码
#' @param educ_adult DMDEDUC2 值
#' @return 统一编码: 1=低于高中, 2=高中, 3=高于高中
harmonize_education <- function(educ_adult) {
  case_when(
    educ_adult %in% c(1, 2) ~ 1L,  # 低于高中
    educ_adult == 3          ~ 2L,  # 高中毕业/GED
    educ_adult %in% c(4, 5) ~ 3L,  # 高于高中
    TRUE                     ~ NA_integer_
  )
}

#' 计算调查权重（合并多波次）
#' @param n_cycles 合并的调查波次数
#' @param weight_var 原始权重变量
#' @param weights_vec 权重向量
#' @return 调整后的权重
adjust_survey_weight <- function(weights_vec, n_cycles) {
  # 按NCHS指南：合并N个2年期权重时除以N
  weights_vec / n_cycles
}

cat("\n[配置完成] 所有路径和参数已设定\n")
cat("  数据目录:", NHANES_DATA_DIR, "\n")
cat("  输出目录:", PROJECT_DIR, "\n")
cat("  种族分组:", length(RACE_GROUPS), "组\n")
cat("  最小样本量:", MIN_SAMPLE_SIZE, "\n\n")
options(survey.lonely.psu = "adjust")
