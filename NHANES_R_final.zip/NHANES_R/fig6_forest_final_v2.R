#=============================================================================
# fig6_forest_final_v2.R
# Figure 6: 严格P值排序Top 10，与Table 3 / S1 / S6完全一致
#=============================================================================

source("00_config.R")
library(ggplot2)

results_cs     <- readRDS(file.path(CACHE_DIR, "exwas_results_common_scale.rds"))
interaction_cs <- readRDS(file.path(CACHE_DIR, "interaction_results_common_scale.rds"))

race_colors <- c(ALL="#666666", NHW="#4E79A7", NHB="#E15759",
                 MA="#76B7B2", OH="#F28E2B", OTH="#B07AA1")

# 严格P值排序Top 10（与Table 3, S1, S6完全一致）
table3_pairs <- data.frame(
  exposure  = c("LBXTHG","LBXCOT","LBXCOT","LBXCOT","LBXSIR",
                "URXUCS","LBXSIR","LBXCOT","LBXBPB","LBXBCD"),
  phenotype = c("BMXARML","BMXBMI","BMXWT","BMXWAIST","LBXHCT",
                "URXUCR","LBXHGB","BMXARML","BMXHT","BMXBMI"),
  label = c("Blood mercury → Arm length (cm)",
            "Serum cotinine → BMI (kg/m²)",
            "Serum cotinine → Body weight (kg)",
            "Serum cotinine → Waist circumference (cm)",
            "Serum iron → Haematocrit (%)",
            "Urinary caesium → Urinary creatinine (mg/dL)",
            "Serum iron → Haemoglobin (g/dL)",
            "Serum cotinine → Arm length (cm)",
            "Blood lead → Standing height (cm)",
            "Blood cadmium → BMI (kg/m²)"),
  rank = 1:10,
  stringsAsFactors = FALSE
)

# 合并交互P
table3_pairs <- merge(table3_pairs,
  interaction_cs[, c("exposure","phenotype","p_interaction")],
  by = c("exposure","phenotype"), all.x = TRUE)

cat("Strict P-ranked Top 10:\n")
for (i in 1:10) {
  r <- table3_pairs[table3_pairs$rank == i, ]
  cat(sprintf("  %2d. %s (P = %.2e)\n", i, r$label, r$p_interaction))
}

# 提取分层数据
actual_races <- c("NHW","NHB","MA","OH","OTH")
fd <- merge(results_cs[results_cs$race_group %in% c("ALL", actual_races), ],
            table3_pairs[, c("exposure","phenotype","rank","label","p_interaction")],
            by = c("exposure","phenotype"))

fd$ci_lo <- fd$beta - 1.96 * fd$se
fd$ci_hi <- fd$beta + 1.96 * fd$se
fd$race_group <- factor(fd$race_group, levels = c("ALL","NHW","NHB","MA","OH","OTH"))

# facet标签带P值，按rank排序
fd$panel_label <- sprintf("%s\n(P_int = %.1e)", fd$label, fd$p_interaction)
fd$panel_label <- reorder(fd$panel_label, fd$rank)

p6 <- ggplot(fd, aes(x = beta, y = race_group, color = race_group)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  geom_errorbarh(aes(xmin = ci_lo, xmax = ci_hi), height = 0.3, linewidth = 0.5) +
  geom_point(size = 2.5) +
  facet_wrap(~ panel_label, scales = "free_x", ncol = 2) +
  scale_color_manual(values = race_colors) +
  labs(
    title = "Top 10 Most Significant Exposure × Race/Ethnicity Interactions (Common Dose Scale)",
    subtitle = expression("Ranked by interaction Wald P;
" * beta * " = phenotype change per 1 log"[10]*"-unit increase in exposure"),
    x = expression(beta ~ "(per 1 log"[10]*"-unit increase in exposure)"),
    y = NULL,
    color = "Race/Ethnicity"
  ) +
  theme_bw(base_size = 11) +
  theme(
    plot.background    = element_rect(fill = "white", color = NA),
    panel.background   = element_rect(fill = "white", color = "grey80"),
    strip.background   = element_rect(fill = "#F0F4F8", color = "grey70"),
    strip.text         = element_text(size = 7.5, face = "bold", color = "grey20"),
    panel.grid.major.x = element_line(color = "grey90", linewidth = 0.3),
    panel.grid.minor   = element_blank(),
    panel.grid.major.y = element_blank(),
    legend.position    = "bottom",
    legend.background  = element_rect(fill = "white", color = NA),
    legend.key         = element_rect(fill = "white"),
    plot.title         = element_text(size = 12, face = "bold", color = "grey10"),
    plot.subtitle      = element_text(size = 9, color = "grey30"),
    axis.text.y        = element_text(size = 9, color = "grey20"),
    axis.text.x        = element_text(size = 8, color = "grey30")
  )

ggsave(file.path(FIGURE_DIR, "fig6_forest_final_v2.png"),
       p6, width = 13, height = 14, dpi = 300, bg = "white")

cat(sprintf("\n[OK] fig6_forest_final_v2.png → %s\n", FIGURE_DIR))
