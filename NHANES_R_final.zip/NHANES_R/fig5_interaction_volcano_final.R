#=============================================================================
# fig5_interaction_volcano_final.R
# 重新生成 Figure 5: 共同尺度交互火山图
#=============================================================================

source("00_config.R")
library(ggplot2)
library(data.table)

# 加载共同尺度交互结果
interaction_cs <- readRDS(file.path(CACHE_DIR, "interaction_results_common_scale.rds"))

cat(sprintf("  交互结果: %d 对, FDR显著: %d\n",
            nrow(interaction_cs), sum(interaction_cs$fdr_sig_int, na.rm = TRUE)))

# 准备数据
idf <- interaction_cs[!is.na(interaction_cs$p_interaction) & interaction_cs$p_interaction > 0, ]

# x轴: max |β₃| (最大交互项系数绝对值)
idf$max_beta_int <- pmax(
  abs(ifelse(is.na(idf$beta_int_NHB), 0, idf$beta_int_NHB)),
  abs(ifelse(is.na(idf$beta_int_MA),  0, idf$beta_int_MA)),
  abs(ifelse(is.na(idf$beta_int_OH),  0, idf$beta_int_OH)),
  abs(ifelse(is.na(idf$beta_int_OTH), 0, idf$beta_int_OTH))
)

# y轴: -log10(P)
idf$nlp <- pmin(-log10(idf$p_interaction), 20)

# 颜色: FDR显著性
idf$sig <- ifelse(idf$fdr_sig_int, "FDR < 0.05", "FDR >= 0.05")

# 统计
n_sig <- sum(idf$sig == "FDR < 0.05")
n_total <- nrow(idf)
pct_sig <- round(100 * n_sig / n_total, 1)

cat(sprintf("  绘图数据: %d 对, FDR<0.05: %d (%.1f%%)\n", n_total, n_sig, pct_sig))

# FDR阈值线 (近似: 找最大的FDR<0.05的P值)
fdr_threshold_p <- max(idf$p_interaction[idf$sig == "FDR < 0.05"], na.rm = TRUE)
fdr_line_y <- -log10(fdr_threshold_p)

p5 <- ggplot(idf, aes(x = max_beta_int, y = nlp, color = sig)) +
  geom_point(alpha = 0.5, size = 2) +
  geom_hline(yintercept = fdr_line_y, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  scale_color_manual(
    values = c("FDR < 0.05" = "#E15759", "FDR >= 0.05" = "#CCCCCC"),
    name = ""
  ) +
  annotate("text",
           x = max(idf$max_beta_int, na.rm = TRUE) * 0.75,
           y = fdr_line_y + 0.5,
           label = sprintf("FDR < 0.05\n%d / %d (%.1f%%)", n_sig, n_total, pct_sig),
           color = "#E15759", size = 3.5, fontface = "bold") +
  labs(
    title = "Exposure × Race/Ethnicity Interaction Effects (Common Dose Scale)",
    x = expression("Maximum |" * beta[interaction] * "| across non-reference groups"),
    y = expression(-log[10] * "(P"[interaction] * ")")
  ) +
  theme_bw(base_size = 12) +
  theme(
    plot.background  = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = "grey80"),
    panel.grid.minor = element_blank(),
    legend.position  = c(0.85, 0.85),
    legend.background = element_rect(fill = "white", color = "grey80", linewidth = 0.3),
    legend.key = element_rect(fill = "white"),
    plot.title = element_text(size = 13, face = "bold")
  )

ggsave(file.path(FIGURE_DIR, "fig5_interaction_common_scale_final.png"),
       p5, width = 9, height = 7, dpi = 300, bg = "white")

cat(sprintf("\n  [OK] fig5_interaction_common_scale_final.png → %s\n", FIGURE_DIR))
