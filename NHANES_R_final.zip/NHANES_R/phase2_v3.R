#=============================================================================
# Phase 2 一体化修正脚本 (v3)
#=============================================================================
# 修正内容:
#   1. 加载变量时按 SEQN+survey_cycle 去重，解决多文件重复行问题
#   2. SEQN统一为 double 类型，避免类型不匹配
#   3. 回归前 droplevels()，避免空因子水平导致奇异矩阵
#   4. 内置可视化，无需单独脚本
#
# 使用方法:
#   setwd("E:/NHANES_R")
#   source("phase2_v3.R")
#
# 前提: Phase 1 和 01b_build_variable_index.R 已运行
#=============================================================================

source("00_config.R")
log_info("===== Phase 2 v3: 一体化修正版 =====")

library(survey)
library(broom)
library(data.table)
library(ggplot2)
library(patchwork)
library(scales)

# ============================================================
# PART 0: 加载数据
# ============================================================
cat("\n[PART 0] 加载数据...\n")

demo_clean   <- readRDS(file.path(CACHE_DIR, "demo_clean.rds"))
full_catalog <- readRDS(file.path(CACHE_DIR, "variable_catalog.rds"))
var_file_index <- readRDS(file.path(CACHE_DIR, "variable_file_index.rds"))

# 统一SEQN类型为 double（与haven读取一致）
demo_clean$SEQN <- as.double(demo_clean$SEQN)

# 精简DEMO
demo_slim <- demo_clean[, c("SEQN", "survey_cycle", "race_ethnicity",
                             "female", "age", "age_sq",
                             "education", "income_poverty_ratio",
                             "wt_mec", "psu", "strata")]

# 可分析变量
available_exp <- intersect(
  full_catalog$var_name[full_catalog$var_type == "exposure" & full_catalog$is_continuous],
  unique(var_file_index$var_name)
)
available_phe <- intersect(
  full_catalog$var_name[full_catalog$var_type == "phenotype"],
  unique(var_file_index$var_name)
)

cat(sprintf("  暴露: %d | 表型: %d | DEMO: %s 人\n",
            length(available_exp), length(available_phe),
            format(nrow(demo_slim), big.mark = ",")))

# ============================================================
# PART 1: 修正的数据加载函数（关键修复：去重）
# ============================================================

#' 加载变量数据，按SEQN+survey_cycle去重
load_var <- function(var_name, index) {
  vf <- index[index$var_name == var_name, ]
  if (nrow(vf) == 0) return(NULL)
  
  chunks <- vector("list", nrow(vf))
  for (i in seq_len(nrow(vf))) {
    df <- tryCatch(haven::read_xpt(vf$file_path[i]), error = function(e) NULL)
    if (is.null(df)) next
    
    col <- vf$actual_colname[i]
    if (!col %in% names(df) || !"SEQN" %in% names(df)) next
    
    chunks[[i]] <- data.frame(
      SEQN = as.double(df[["SEQN"]]),       # ← 统一double
      val  = as.numeric(df[[col]]),
      survey_cycle = vf$survey_cycle[i],
      stringsAsFactors = FALSE
    )
  }
  
  chunks <- chunks[!sapply(chunks, is.null)]
  if (length(chunks) == 0) return(NULL)
  
  out <- do.call(rbind, chunks)
  
  # ★★★ 关键修复: 按SEQN+survey_cycle去重 ★★★
  # 同一人在同一波次可能出现在多个文件中（如lab06.xpt和lab06hm.xpt）
  out <- out[!duplicated(out[, c("SEQN", "survey_cycle")]), ]
  
  # 移除NA
  out <- out[!is.na(out$val), ]
  
  names(out)[2] <- var_name
  return(out)
}

# ---- 验证去重效果 ----
cat("\n  验证去重效果 (血铅 LBXBPB)...\n")
test_data <- load_var("LBXBPB", var_file_index)
if (!is.null(test_data)) {
  test_merged <- merge(demo_slim[, c("SEQN","survey_cycle","race_ethnicity")],
                       test_data, by = c("SEQN", "survey_cycle"))
  race_n <- table(test_merged$race_ethnicity)
  cat(sprintf("    去重后: NHW=%d NHB=%d MA=%d OH=%d OTH=%d (总=%d)\n",
              race_n["NHW"], race_n["NHB"], race_n["MA"], race_n["OH"], race_n["OTH"],
              nrow(test_merged)))
  
  # 检查无重复
  dup_check <- sum(duplicated(test_merged[, c("SEQN", "survey_cycle")]))
  cat(sprintf("    重复行: %d (应为0)\n", dup_check))
}

# ============================================================
# PART 2: 回归函数
# ============================================================

run_reg <- function(exp_data, phe_data, demo, exp_name, phe_name, race_grp = NULL) {
  
  # 合并
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  
  # 种族筛选
  if (!is.null(race_grp)) m <- m[m$race_ethnicity == race_grp, ]
  
  # 完整数据
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$age) & !is.na(m$female), ]
  
  nn <- nrow(m)
  nc <- length(unique(m$survey_cycle))
  if (nn < MIN_SAMPLE_SIZE || nc < MIN_SURVEY_WAVES) return(NULL)
  
  # 暴露: log10 + 标准化
  x <- m[[exp_name]]
  mnz <- min(x[x > 0], na.rm = TRUE)
  if (!is.finite(mnz)) return(NULL)
  xl <- log10(x + mnz)
  wt <- m$wt_mec
  mx <- weighted.mean(xl, wt, na.rm = TRUE)
  sx <- sqrt(sum(wt * (xl - mx)^2) / sum(wt))
  if (sx == 0) return(NULL)
  m$E_z <- (xl - mx) / sx
  
  # 表型: 标准化
  y <- m[[phe_name]]
  my <- weighted.mean(y, wt, na.rm = TRUE)
  sy <- sqrt(sum(wt * (y - my)^2) / sum(wt))
  if (sy == 0) return(NULL)
  m$P_z <- (y - my) / sy
  
  # 权重调整
  m$wt_adj <- m$wt_mec / nc
  
  # ★ 关键修复: droplevels避免空水平 ★
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  # 如果只有1个cycle水平则不加入模型
  if (nlevels(m$cycle_f) <= 1) {
    fml_str <- "P_z ~ E_z + age + age_sq + female"
  } else {
    fml_str <- "P_z ~ E_z + age + age_sq + female + cycle_f"
  }
  
  # 可选加入income和education（允许缺失时不加）
  if (sum(!is.na(m$income_poverty_ratio)) > nn * 0.5) {
    fml_str <- paste(fml_str, "+ income_poverty_ratio")
  }
  if (sum(!is.na(m$education)) > nn * 0.5) {
    fml_str <- paste(fml_str, "+ education")
  }
  
  # 全人群加种族调整
  if (is.null(race_grp)) {
    m$race_f <- droplevels(factor(m$race_ethnicity))
    if (nlevels(m$race_f) > 1) fml_str <- paste(fml_str, "+ race_f")
  }
  
  fml <- as.formula(fml_str)
  
  # 调查设计
  des <- tryCatch(
    svydesign(id = ~psu, strata = ~strata, weights = ~wt_adj, data = m, nest = TRUE),
    error = function(e) NULL
  )
  if (is.null(des)) return(NULL)
  
  # 回归
  fit <- tryCatch(svyglm(fml, design = des), error = function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  if (!"E_z" %in% rownames(co)) return(NULL)
  
  # R²
  tss <- sum(m$wt_adj * (m$P_z)^2, na.rm = TRUE)  # P_z已标准化
  rss <- sum(m$wt_adj * residuals(fit)^2, na.rm = TRUE)
  r2_full <- 1 - rss / tss
  
  # 基线R²
  fml_base <- update(fml, . ~ . - E_z)
  fit_base <- tryCatch(svyglm(fml_base, design = des), error = function(e) NULL)
  r2_base <- if (!is.null(fit_base)) {
    1 - sum(m$wt_adj * residuals(fit_base)^2, na.rm = TRUE) / tss
  } else NA
  
  data.frame(
    exposure = exp_name, phenotype = phe_name,
    race_group = ifelse(is.null(race_grp), "ALL", race_grp),
    n_obs = nn, n_cycles = nc,
    beta = co["E_z", "Estimate"], se = co["E_z", "Std. Error"],
    p_value = co["E_z", "Pr(>|t|)"],
    r2_full = r2_full, r2_base = r2_base,
    r2_exposure = r2_full - ifelse(is.na(r2_base), 0, r2_base),
    stringsAsFactors = FALSE
  )
}

# 交互检验
run_int <- function(exp_data, phe_data, demo, exp_name, phe_name) {
  m <- merge(demo, exp_data, by = c("SEQN", "survey_cycle"))
  m <- merge(m, phe_data, by = c("SEQN", "survey_cycle"))
  m <- m[!is.na(m[[exp_name]]) & !is.na(m[[phe_name]]) &
         !is.na(m$wt_mec) & m$wt_mec > 0 &
         !is.na(m$psu) & !is.na(m$strata) &
         !is.na(m$race_ethnicity) & !is.na(m$age) & !is.na(m$female), ]
  
  if (nrow(m) < 500) return(NULL)
  
  x <- m[[exp_name]]; mnz <- min(x[x>0], na.rm=TRUE)
  if (!is.finite(mnz)) return(NULL)
  xl <- log10(x + mnz); wt <- m$wt_mec
  mx <- weighted.mean(xl, wt); sx <- sqrt(sum(wt*(xl-mx)^2)/sum(wt))
  if (sx==0) return(NULL)
  m$E_z <- (xl-mx)/sx
  y <- m[[phe_name]]; my <- weighted.mean(y,wt); sy <- sqrt(sum(wt*(y-my)^2)/sum(wt))
  if (sy==0) return(NULL)
  m$P_z <- (y-my)/sy
  
  nc <- length(unique(m$survey_cycle))
  m$wt_adj <- m$wt_mec / nc
  m$race_f <- droplevels(factor(m$race_ethnicity, levels = c("NHW","NHB","MA","OH","OTH")))
  m$cycle_f <- droplevels(factor(m$survey_cycle))
  
  des <- tryCatch(svydesign(id=~psu, strata=~strata, weights=~wt_adj, data=m, nest=TRUE), error=function(e) NULL)
  if (is.null(des)) return(NULL)
  
  fit <- tryCatch(svyglm(P_z ~ E_z*race_f + age + age_sq + female + cycle_f, design=des), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  
  co <- summary(fit)$coefficients
  int_terms <- grep("^E_z:race_f", rownames(co), value = TRUE)
  if (length(int_terms) == 0) return(NULL)
  
  p_int <- tryCatch({regTermTest(fit, "E_z:race_f")$p}, error = function(e) {
    min(co[int_terms, "Pr(>|t|)"], na.rm = TRUE)
  })
  
  gv <- function(term, col) if (term %in% rownames(co)) co[term, col] else NA
  
  data.frame(
    exposure=exp_name, phenotype=phe_name, p_interaction=p_int, n_obs=nrow(m),
    beta_int_NHB=gv("E_z:race_fNHB","Estimate"), p_int_NHB=gv("E_z:race_fNHB","Pr(>|t|)"),
    beta_int_MA=gv("E_z:race_fMA","Estimate"),   p_int_MA=gv("E_z:race_fMA","Pr(>|t|)"),
    beta_int_OH=gv("E_z:race_fOH","Estimate"),   p_int_OH=gv("E_z:race_fOH","Pr(>|t|)"),
    beta_int_OTH=gv("E_z:race_fOTH","Estimate"), p_int_OTH=gv("E_z:race_fOTH","Pr(>|t|)"),
    stringsAsFactors=FALSE
  )
}

# ============================================================
# PART 3: 主循环
# ============================================================
cat("\n[PART 3] 执行分层ExWAS...\n")

RACES <- c("ALL", "NHW", "NHB", "MA", "OH", "OTH")
total_pairs <- length(available_exp) * length(available_phe)
cat(sprintf("  %d暴露 × %d表型 = %d对 × 6组 = ~%d次回归\n",
            length(available_exp), length(available_phe), total_pairs, total_pairs*6))

res_list <- list()
int_list <- list()
ri <- 0; ii <- 0
t0 <- Sys.time()
pc <- 0

for (ename in available_exp) {
  edata <- load_var(ename, var_file_index)
  if (is.null(edata)) next
  
  for (pname in available_phe) {
    pc <- pc + 1
    if (pc %% 50 == 0 || pc == 1) {
      el <- as.numeric(difftime(Sys.time(), t0, units="mins"))
      eta <- if (pc > 1) (total_pairs - pc) / (pc / el) else NA
      cat(sprintf("\r  [%d/%d] %.0f%% | %.1fmin | ~%.0fmin剩余 | %s × %s      ",
                  pc, total_pairs, 100*pc/total_pairs, el, eta, ename, pname))
    }
    
    pdata <- load_var(pname, var_file_index)
    if (is.null(pdata)) next
    
    # 各种族回归
    for (rg in RACES) {
      rarg <- if (rg == "ALL") NULL else rg
      r <- tryCatch(run_reg(edata, pdata, demo_slim, ename, pname, rarg), error=function(e) NULL)
      if (!is.null(r)) { ri <- ri + 1; res_list[[ri]] <- r }
    }
    
    # 交互
    ir <- tryCatch(run_int(edata, pdata, demo_slim, ename, pname), error=function(e) NULL)
    if (!is.null(ir)) { ii <- ii + 1; int_list[[ii]] <- ir }
    
    # 定期保存
    if (pc %% 200 == 0 && ri > 0) {
      saveRDS(do.call(rbind, res_list[1:ri]), file.path(CACHE_DIR, "results_temp_v3.rds"))
    }
  }
}

cat(sprintf("\n\n  完成! 耗时%.1f分钟 | 结果:%d条 | 交互:%d条\n",
            as.numeric(difftime(Sys.time(), t0, units="mins")), ri, ii))

# ============================================================
# PART 4: 多重检验校正
# ============================================================
cat("\n[PART 4] 多重检验校正...\n")

results_df <- do.call(rbind, res_list[1:ri])
interaction_df <- if (ii > 0) do.call(rbind, int_list[1:ii]) else data.frame()

results_df$bonferroni_sig <- FALSE
results_df$p_fdr <- 1
results_df$fdr_sig <- FALSE

for (rg in unique(results_df$race_group)) {
  idx <- results_df$race_group == rg
  nt <- sum(idx)
  results_df$bonferroni_sig[idx] <- results_df$p_value[idx] < (0.05 / nt)
  results_df$p_fdr[idx] <- p.adjust(results_df$p_value[idx], method = "BY")
  results_df$fdr_sig[idx] <- results_df$p_fdr[idx] < 0.05
}

if (nrow(interaction_df) > 0) {
  interaction_df$fdr_sig_int <- p.adjust(interaction_df$p_interaction, method = "BY") < 0.05
}

# 汇总
cat("\n  ===== 各种族ExWAS结果汇总 =====\n")
for (rg in c("ALL","NHW","NHB","MA","OH","OTH")) {
  sub <- results_df[results_df$race_group == rg, ]
  if (nrow(sub) == 0) { cat(sprintf("  %s: 无结果\n", rg)); next }
  nb <- sum(sub$bonferroni_sig)
  nf <- sum(sub$fdr_sig)
  mr2 <- round(median(sub$r2_exposure[sub$bonferroni_sig], na.rm=TRUE)*100, 3)
  ne <- length(unique(sub$exposure))
  np <- length(unique(sub$phenotype))
  cat(sprintf("  %s: %4d关联 (%2d暴露×%2d表型) | %3d Bonferroni (%.1f%%) | %3d FDR | 中位R²=%.3f%%\n",
              rg, nrow(sub), ne, np, nb, 100*nb/nrow(sub), nf, mr2))
}

if (nrow(interaction_df) > 0) {
  cat(sprintf("\n  交互效应: %d / %d 通过FDR (%.1f%%)\n",
              sum(interaction_df$fdr_sig_int), nrow(interaction_df),
              100*sum(interaction_df$fdr_sig_int)/nrow(interaction_df)))
}

# ============================================================
# PART 5: 种族间一致性
# ============================================================
cat("\n[PART 5] 种族间一致性...\n")

actual_races <- setdiff(unique(results_df$race_group), "ALL")

wide <- results_df[results_df$race_group != "ALL", c("exposure","phenotype","race_group","beta")]
wide <- reshape(wide, idvar=c("exposure","phenotype"), timevar="race_group", direction="wide")

combos <- combn(actual_races, 2, simplify = FALSE)
con_list <- list()
for (cb in combos) {
  c1 <- paste0("beta.", cb[1]); c2 <- paste0("beta.", cb[2])
  if (!c1 %in% names(wide) || !c2 %in% names(wide)) next
  v <- !is.na(wide[[c1]]) & !is.na(wide[[c2]])
  if (sum(v) < 10) next
  r <- cor(wide[[c1]][v], wide[[c2]][v])
  sd <- mean(sign(wide[[c1]][v]) == sign(wide[[c2]][v])) * 100
  con_list[[length(con_list)+1]] <- data.frame(
    race_1=cb[1], race_2=cb[2], n=sum(v), r=round(r,3), same_dir_pct=round(sd,1))
  cat(sprintf("  %s vs %s: r=%.3f | 同向%.1f%% (n=%d)\n", cb[1], cb[2], r, sd, sum(v)))
}

# ============================================================
# PART 6: 保存
# ============================================================
cat("\n[PART 6] 保存...\n")
saveRDS(results_df, file.path(CACHE_DIR, "exwas_results_stratified.rds"))
saveRDS(interaction_df, file.path(CACHE_DIR, "interaction_results.rds"))
fwrite(as.data.table(results_df), file.path(OUTPUT_DIR, "exwas_full_results.csv"))
fwrite(as.data.table(results_df[results_df$bonferroni_sig | results_df$fdr_sig, ]),
       file.path(OUTPUT_DIR, "exwas_significant_results.csv"))
if (nrow(interaction_df) > 0)
  fwrite(as.data.table(interaction_df), file.path(OUTPUT_DIR, "interaction_results.csv"))

# ============================================================
# PART 7: 可视化 (内置)
# ============================================================
cat("\n[PART 7] 生成图表...\n")

race_colors <- c(ALL="#999999", NHW="#4E79A7", NHB="#E15759",
                 MA="#76B7B2", OH="#F28E2B", OTH="#B07AA1")

# 添加类别
results_df <- merge(results_df,
  full_catalog[full_catalog$var_type=="exposure", c("var_name","category")],
  by.x="exposure", by.y="var_name", all.x=TRUE)
names(results_df)[names(results_df)=="category"] <- "exp_cat"
results_df <- merge(results_df,
  full_catalog[full_catalog$var_type=="phenotype", c("var_name","category")],
  by.x="phenotype", by.y="var_name", all.x=TRUE)
names(results_df)[names(results_df)=="category"] <- "phe_cat"

# Fig 1: P值分布
tryCatch({
  p1 <- ggplot(results_df[results_df$race_group %in% actual_races, ],
               aes(x = pmin(-log10(p_value), 20), fill = race_group)) +
    geom_histogram(bins = 40, alpha = 0.7, color = "white", linewidth = 0.2) +
    facet_wrap(~race_group, ncol = 2, scales = "free_y") +
    scale_fill_manual(values = race_colors) +
    labs(title = "P-value Distribution by Race", x = "-log10(P)", y = "Count") +
    theme_minimal(base_size = 11) + theme(legend.position = "none")
  ggsave(file.path(FIGURE_DIR, "fig1_pvalue_dist.png"), p1, width = 10, height = 8, dpi = 300)
  cat("  [OK] fig1\n")
}, error = function(e) cat("  [SKIP] fig1:", e$message, "\n"))

# Fig 2: 种族间beta散点
tryCatch({
  plots <- list()
  for (cb in combos) {
    c1 <- paste0("beta.", cb[1]); c2 <- paste0("beta.", cb[2])
    if (!c1 %in% names(wide) || !c2 %in% names(wide)) next
    pd <- wide[!is.na(wide[[c1]]) & !is.na(wide[[c2]]), ]
    if (nrow(pd) < 10) next
    rv <- round(cor(pd[[c1]], pd[[c2]]), 3)
    lim <- max(abs(c(pd[[c1]], pd[[c2]]))) * 1.1
    plots[[paste(cb, collapse="_")]] <-
      ggplot(pd, aes(x = .data[[c1]], y = .data[[c2]])) +
      geom_point(alpha = 0.4, size = 1.5) +
      geom_abline(slope=1, intercept=0, linetype="dashed", color="gray40") +
      coord_equal(xlim=c(-lim,lim), ylim=c(-lim,lim)) +
      labs(title=paste(cb[1],"vs",cb[2]), subtitle=sprintf("r=%.3f (n=%d)",rv,nrow(pd)),
           x=paste0("β(",cb[1],")"), y=paste0("β(",cb[2],")")) +
      theme_minimal(base_size = 10)
  }
  if (length(plots) > 0) {
    p2 <- wrap_plots(plots, ncol = min(length(plots), 3))
    ggsave(file.path(FIGURE_DIR, "fig2_beta_scatter.png"), p2,
           width = min(length(plots),3)*5, height = ceiling(length(plots)/3)*5, dpi = 300)
    cat("  [OK] fig2 (", length(plots), "panels)\n")
  }
}, error = function(e) cat("  [SKIP] fig2:", e$message, "\n"))

# Fig 3: 显著关联数
tryCatch({
  sig_ct <- as.data.frame(table(
    results_df$race_group[results_df$bonferroni_sig & results_df$race_group != "ALL"]))
  if (nrow(sig_ct) > 0) {
    names(sig_ct) <- c("race", "count")
    p3 <- ggplot(sig_ct, aes(x = reorder(race, count), y = count, fill = race)) +
      geom_col(width = 0.6) + coord_flip() +
      scale_fill_manual(values = race_colors) +
      labs(title = "Bonferroni-Significant Associations by Race", x = "", y = "Count") +
      theme_minimal(base_size = 12) + theme(legend.position = "none")
    ggsave(file.path(FIGURE_DIR, "fig3_sig_count.png"), p3, width = 8, height = 5, dpi = 300)
    cat("  [OK] fig3\n")
  }
}, error = function(e) cat("  [SKIP] fig3:", e$message, "\n"))

# Fig 4: R²分布
tryCatch({
  sig_data <- results_df[results_df$bonferroni_sig & results_df$race_group != "ALL", ]
  if (nrow(sig_data) > 5) {
    p4 <- ggplot(sig_data, aes(x = race_group, y = r2_exposure*100, fill = race_group)) +
      geom_boxplot(alpha = 0.7) + scale_fill_manual(values = race_colors) +
      scale_y_log10() +
      labs(title = "R² Distribution (Bonferroni-significant)", x = "", y = "R² (%)") +
      theme_minimal(base_size = 12) + theme(legend.position = "none")
    ggsave(file.path(FIGURE_DIR, "fig4_r2_dist.png"), p4, width = 8, height = 6, dpi = 300)
    cat("  [OK] fig4\n")
  }
}, error = function(e) cat("  [SKIP] fig4:", e$message, "\n"))

# Fig 5: 交互火山图
tryCatch({
  if (nrow(interaction_df) > 0) {
    idf <- interaction_df[!is.na(interaction_df$p_interaction) & interaction_df$p_interaction > 0, ]
    idf$nlp <- pmin(-log10(idf$p_interaction), 15)
    idf$max_b <- pmax(abs(ifelse(is.na(idf$beta_int_NHB),0,idf$beta_int_NHB)),
                       abs(ifelse(is.na(idf$beta_int_MA),0,idf$beta_int_MA)),
                       abs(ifelse(is.na(idf$beta_int_OH),0,idf$beta_int_OH)),
                       abs(ifelse(is.na(idf$beta_int_OTH),0,idf$beta_int_OTH)))
    idf$sig <- ifelse(idf$fdr_sig_int, "FDR<0.05", "NS")
    p5 <- ggplot(idf, aes(x=max_b, y=nlp, color=sig)) + geom_point(alpha=0.5, size=2) +
      scale_color_manual(values=c("FDR<0.05"="#E15759","NS"="#CCCCCC")) +
      labs(title="Exposure×Race Interaction", x="|β_interaction|", y="-log10(P)") +
      theme_minimal(base_size=12) + theme(legend.position="bottom")
    ggsave(file.path(FIGURE_DIR, "fig5_interaction.png"), p5, width=9, height=7, dpi=300)
    cat("  [OK] fig5\n")
  }
}, error = function(e) cat("  [SKIP] fig5:", e$message, "\n"))

# Fig 6: 异质性Forest plot
tryCatch({
  rv <- results_df[results_df$race_group %in% actual_races, ]
  rv <- aggregate(beta ~ exposure + phenotype, data = rv,
                  FUN = function(x) max(x) - min(x))
  names(rv)[3] <- "range_beta"
  top10 <- head(rv[order(-rv$range_beta), ], 10)
  fd <- merge(results_df[results_df$race_group %in% actual_races, ], top10[,1:2])
  fd$label <- paste0(fd$exposure, " → ", fd$phenotype)
  fd <- merge(fd, top10[,c("exposure","phenotype","range_beta")])
  fd$label <- reorder(fd$label, fd$range_beta)
  p6 <- ggplot(fd, aes(x=beta, y=label, color=race_group)) +
    geom_point(size=3, position=position_dodge(0.6)) +
    geom_errorbarh(aes(xmin=beta-1.96*se, xmax=beta+1.96*se),
                   height=0.3, position=position_dodge(0.6)) +
    geom_vline(xintercept=0, linetype="dashed") +
    scale_color_manual(values=race_colors) +
    labs(title="Top 10 Most Heterogeneous Associations", x="β", y="") +
    theme_minimal(base_size=11) + theme(legend.position="bottom")
  ggsave(file.path(FIGURE_DIR, "fig6_forest.png"), p6, width=12, height=8, dpi=300)
  cat("  [OK] fig6\n")
}, error = function(e) cat("  [SKIP] fig6:", e$message, "\n"))

# ============================================================
cat("\n╔════════════════════════════════════════════════════╗\n")
cat("║  Phase 2 v3 全部完成!                             ║\n")
cat(sprintf("║  结果: %s/output/   ║\n", PROJECT_DIR))
cat(sprintf("║  图形: %s/figures/  ║\n", PROJECT_DIR))
cat("╚════════════════════════════════════════════════════╝\n")
log_info("Phase 2 v3 完成")
