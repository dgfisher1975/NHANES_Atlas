#=============================================================================
# 主运行脚本: Phase 1 一键执行
#=============================================================================
# 使用方法:
#   1. 在RStudio中打开此文件
#   2. 将工作目录设为本脚本所在目录
#   3. 修改 00_config.R 中的 NHANES_DATA_DIR 路径
#   4. 运行 source("run_phase1.R")
#
# 或在R命令行中:
#   setwd("你的脚本目录路径")
#   source("run_phase1.R")
#=============================================================================

cat("
╔══════════════════════════════════════════════════════════════════╗
║  种族/民族分层 Exposome-Phenome Atlas                           ║
║  Phase 1: 数据准备 · 群体分层 · 样本量评估                      ║
║  一键运行脚本                                                    ║
╚══════════════════════════════════════════════════════════════════╝
\n")

start_time <- Sys.time()

# 记录所有输出
sink_file <- paste0("phase1_full_log_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt")
# sink(sink_file, split = TRUE)  # 取消注释可同时写入文件

# ---- 步骤 1: 配置与环境检查 ----
cat("=== 步骤 1/3: 配置与环境检查 ===\n")
tryCatch({
  source("00_config.R")
  cat("[OK] 配置加载成功\n\n")
}, error = function(e) {
  cat("[ERROR] 配置加载失败:", e$message, "\n")
  cat("请检查 00_config.R 中的路径设置\n")
  stop(e)
})

# ---- 步骤 2: 数据加载与编目 ----
cat("=== 步骤 2/3: 数据加载与编目 ===\n")
tryCatch({
  source("01_data_loading.R")
  cat("[OK] 数据加载与编目完成\n\n")
}, error = function(e) {
  cat("[ERROR] 数据加载失败:", e$message, "\n")
  cat("常见问题:\n")
  cat("  1. NHANES_DATA_DIR 路径不正确\n")
  cat("  2. XPT文件不在指定目录中\n")
  cat("  3. 缺少必要的R包\n")
  stop(e)
})

# ---- 步骤 3: 种族分层与样本量评估 ----
cat("=== 步骤 3/3: 种族分层与样本量评估 ===\n")
tryCatch({
  source("02_stratification_sample_size.R")
  cat("[OK] 种族分层与样本量评估完成\n\n")
}, error = function(e) {
  cat("[WARNING] 部分评估未完成:", e$message, "\n")
  cat("尝试继续...\n")
})

# ---- 步骤 4: 数据合并（可选，耗时较长） ----
cat("=== [可选] 步骤 4: 数据合并 ===\n")
cat("数据合并脚本(03_data_merge.R)耗时较长，\n")
cat("建议在确认前三步无误后单独运行:\n")
cat("  source('03_data_merge.R')\n\n")

# ---- 完成 ----
end_time <- Sys.time()
elapsed <- difftime(end_time, start_time, units = "mins")

cat("================================================================\n")
cat(sprintf("  Phase 1 核心步骤完成！耗时: %.1f 分钟\n", as.numeric(elapsed)))
cat("  \n")
cat("  输出目录结构:\n")
cat(sprintf("    项目根目录: %s\n", PROJECT_DIR))
cat(sprintf("    缓存数据:   %s/cache/\n", PROJECT_DIR))
cat(sprintf("    表格输出:   %s/tables/\n", PROJECT_DIR))
cat(sprintf("    图形输出:   %s/figures/\n", PROJECT_DIR))
cat(sprintf("    报告输出:   %s/output/\n", PROJECT_DIR))
cat("================================================================\n")

# sink()  # 如果启用了sink，取消注释
